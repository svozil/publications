# Response to the Criticism

I treated the criticism as substantially correct and revised the manuscript in
that direction.

## Main Changes

- Added an explicit explanation that a finite probability table alone is
  trivially simulable unless operational equivalences and cone-linear extension
  requirements are imposed.
- Clarified that the projector-cone LP is a cone-level benchmark and may not
  enforce response-function upper bounds unless unit effects and complements are
  present.
- Added a short cone-factorization explanation after the simplex LP.
- Added the explicit primal and dual LP certificate format in Appendix A.
- Changed numerical-only rows to use approximate status and made Table II
  visibly numerical/rationalized rather than exact-certified.
- Replaced the commented-out data availability TODO with an active
  Data/code availability section pointing to the supplementary archive.
- Tightened the GHZ/product-rule wording: product preservation is an additional
  assumption not contained in the Boolean algebra of the single collective joint
  spectral measurement.
- Added the GHZ note that only three of the four signs are independent because
  the product constraint fixes the fourth.
- Added the weak-pasting qualification for two contexts sharing an atom.
- Clarified that the completed pentagon numerical value belongs to the specific
  symmetric algebraic realization, not to the graph alone.

## Supplement

The new supplement bundle in this directory contains:

- `2026-simplex-supplement.tex`
- `simplex_ultimate_audit.py`
- `simplex_projector_cone_vector_audit.py`
- `simplex_operational_closure_vector_audit.py`
- `simplex_original_formalism_exact_cdd_v10_completed_audit.py`
- `2026-simplex.tex`

Running

```powershell
python simplex_ultimate_audit.py --outdir supplement_run
```

writes all listed result manifests and program hashes.  Running with
`--run-full` invokes the audit programs.  Running with
`--save-exact-certificates` in a fraction/GMP-capable cddlib environment emits
the rational certificate JSON files.

## Remaining Caveat

The local pycddlib build available in this workspace is float-only, so exact
rational facet regeneration cannot be demonstrated locally here.  The scripts
therefore distinguish exact-capable runs from float-only numerical runs in the
generated dependency report and manifests.
