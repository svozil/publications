#!/usr/bin/env python3
"""Ultimate driver for the simplex manuscript supplement.

Default use is intentionally light:

    python simplex_ultimate_audit.py --outdir supplement_run

This writes machine-readable manifests for every table entry in the paper,
program hashes, and a Markdown run index.  It does not require NumPy/SciPy.

For computational regeneration, use a Python environment containing numpy,
scipy, sympy, and pycddlib:

    python simplex_ultimate_audit.py --outdir supplement_run --run-full

If pycddlib is built with exact fraction/GMP support, add:

    python simplex_ultimate_audit.py --outdir supplement_run --run-full --save-exact-certificates

The exact-certificate mode imports the projector-cone audit and serializes the
rational input data, facet matrices, primal sigma certificates, and dual
witness vectors for rows that the audit verifies as exact optima.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from typing import Any, Dict, Iterable, List, Optional


ROOT = Path(__file__).resolve().parent


PROJECTOR_ROWS: List[Dict[str, Any]] = [
    {
        "configuration": "Firefly logic L12",
        "hilbert_dim": 3,
        "projectors": 5,
        "accessible_dim": 4,
        "facets": 5,
        "r": "0",
        "decimal": 0.0,
        "status": "exact optimum",
        "exact_primal": True,
        "exact_dual": True,
    },
    {
        "configuration": "Completed pentagon C5",
        "hilbert_dim": 3,
        "projectors": 10,
        "accessible_dim": 6,
        "facets": 12,
        "r": "0.119140568134",
        "decimal": 0.119140568134,
        "status": "numerical/algebraic branch",
        "exact_primal": False,
        "exact_dual": False,
    },
    {
        "configuration": "Specker bug/TIFS, nonfull",
        "hilbert_dim": 3,
        "projectors": 13,
        "accessible_dim": 6,
        "facets": 26,
        "r": "0.31645570",
        "decimal": 0.31645570,
        "status": "numerical",
        "exact_primal": False,
        "exact_dual": False,
    },
    {
        "configuration": "Gamma_3, nonseparating",
        "hilbert_dim": 3,
        "projectors": 25,
        "accessible_dim": 6,
        "facets": 230,
        "r": "0.50219773",
        "decimal": 0.50219773,
        "status": "numerical",
        "exact_primal": False,
        "exact_dual": False,
    },
    {
        "configuration": "Tkadlec Fig. 2, nonunital",
        "hilbert_dim": 3,
        "projectors": 37,
        "accessible_dim": 6,
        "facets": 276,
        "r": "35/64",
        "decimal": 35 / 64,
        "status": "exact optimum",
        "exact_primal": True,
        "exact_dual": True,
    },
    {
        "configuration": "Yu--Oh 13-ray projector fragment",
        "hilbert_dim": 3,
        "projectors": 13,
        "accessible_dim": 6,
        "facets": 24,
        "r": "3/8",
        "decimal": 3 / 8,
        "status": "exact optimum",
        "exact_primal": True,
        "exact_dual": True,
    },
    {
        "configuration": "Yu--Oh 25-ray orthogonal completion",
        "hilbert_dim": 3,
        "projectors": 25,
        "accessible_dim": 6,
        "facets": 96,
        "r": "21/44",
        "decimal": 21 / 44,
        "status": "exact optimum",
        "exact_primal": True,
        "exact_dual": True,
    },
    {
        "configuration": "Cabello--Estebaranz--Garcia-Alcaine 18--9",
        "hilbert_dim": 4,
        "projectors": 18,
        "accessible_dim": 10,
        "facets": 146,
        "r": "1/3",
        "decimal": 1 / 3,
        "status": "exact optimum",
        "exact_primal": True,
        "exact_dual": True,
    },
    {
        "configuration": "Peres--Mermin 24--24 completion",
        "hilbert_dim": 4,
        "projectors": 24,
        "accessible_dim": 10,
        "facets": 120,
        "r": "4/9",
        "decimal": 4 / 9,
        "status": "exact optimum",
        "exact_primal": True,
        "exact_dual": True,
    },
]


CLOSURE_ROWS: List[Dict[str, Any]] = [
    {
        "configuration": "Firefly logic L12",
        "closure_variant": "closed effects",
        "hilbert_dim": 3,
        "generators": [6, 11],
        "facets": [5, 5],
        "solver": "primal",
        "r": "0",
        "decimal": 0.0,
        "status": "numerical",
    },
    {
        "configuration": "Firefly logic L12",
        "closure_variant": "closed effects+preparations",
        "hilbert_dim": 3,
        "generators": [11, 11],
        "facets": [5, 5],
        "solver": "primal",
        "r": "0",
        "decimal": 0.0,
        "status": "numerical",
    },
    {
        "configuration": "Yu--Oh 13",
        "closure_variant": "closed effects",
        "hilbert_dim": 3,
        "generators": [14, 51],
        "facets": [24, 96],
        "solver": "primal",
        "r": "9/20",
        "decimal": 9 / 20,
        "status": "numerical rationalization",
    },
    {
        "configuration": "Yu--Oh 13",
        "closure_variant": "closed effects+preparations",
        "hilbert_dim": 3,
        "generators": [51, 51],
        "facets": [96, 96],
        "solver": "primal",
        "r": "21/44",
        "decimal": 21 / 44,
        "status": "numerical rationalization",
    },
    {
        "configuration": "Yu--Oh 25 completion",
        "closure_variant": "closed effects",
        "hilbert_dim": 3,
        "generators": [26, 51],
        "facets": [96, 96],
        "solver": "primal",
        "r": "21/44",
        "decimal": 21 / 44,
        "status": "numerical rationalization",
    },
    {
        "configuration": "Yu--Oh 25 completion",
        "closure_variant": "closed effects+preparations",
        "hilbert_dim": 3,
        "generators": [51, 51],
        "facets": [96, 96],
        "solver": "primal",
        "r": "21/44",
        "decimal": 21 / 44,
        "status": "numerical rationalization",
    },
    {
        "configuration": "Tkadlec Fig. 2, nonunital",
        "closure_variant": "closed effects",
        "hilbert_dim": 3,
        "generators": [38, 123],
        "facets": [276, 1140],
        "solver": "cutting dual",
        "r": "445/792",
        "decimal": 445 / 792,
        "status": "numerical rationalization",
    },
    {
        "configuration": "Tkadlec Fig. 2, nonunital",
        "closure_variant": "closed effects+preparations",
        "hilbert_dim": 3,
        "generators": [123, 123],
        "facets": [1140, 1140],
        "solver": "cutting dual",
        "r": "192/337",
        "decimal": 192 / 337,
        "status": "numerical rationalization",
    },
    {
        "configuration": "Cabello 18--9",
        "closure_variant": "closed effects",
        "hilbert_dim": 4,
        "generators": [19, 121],
        "facets": [146, 120],
        "solver": "primal",
        "r": "4/9",
        "decimal": 4 / 9,
        "status": "numerical rationalization",
    },
    {
        "configuration": "Cabello 18--9",
        "closure_variant": "closed effects+preparations",
        "hilbert_dim": 4,
        "generators": [121, 121],
        "facets": [120, 120],
        "solver": "primal",
        "r": "4/9",
        "decimal": 4 / 9,
        "status": "numerical rationalization",
    },
    {
        "configuration": "Peres--Mermin/Peres 24",
        "closure_variant": "closed effects",
        "hilbert_dim": 4,
        "generators": [25, 139],
        "facets": [120, 120],
        "solver": "primal",
        "r": "4/9",
        "decimal": 4 / 9,
        "status": "numerical rationalization",
    },
    {
        "configuration": "Peres--Mermin/Peres 24",
        "closure_variant": "closed effects+preparations",
        "hilbert_dim": 4,
        "generators": [139, 139],
        "facets": [120, 120],
        "solver": "primal",
        "r": "4/9",
        "decimal": 4 / 9,
        "status": "numerical rationalization",
    },
]


PROGRAMS = [
    "simplex_ultimate_audit.py",
    "simplex_projector_cone_vector_audit.py",
    "simplex_operational_closure_vector_audit.py",
    "simplex_original_formalism_exact_cdd_v10_completed_audit.py",
    "2026-simplex.tex",
    "2026-simplex.pdf",
    "2026-simplex-supplement.tex",
    "2026-simplex-supplement.pdf",
    "response_to_criticism.md",
]


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def sha256(path: Path) -> Optional[str]:
    if not path.exists():
        return None
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def dependency_report() -> Dict[str, Any]:
    report: Dict[str, Any] = {"python": sys.version, "executable": sys.executable}
    for name in ["numpy", "scipy", "sympy"]:
        try:
            mod = __import__(name)
            report[name] = getattr(mod, "__version__", "installed")
        except Exception as exc:
            report[name] = f"not available: {exc}"
    try:
        import cdd  # type: ignore

        number_type = getattr(cdd, "NumberType", None)
        report["pycddlib"] = {
            "available": True,
            "version": getattr(cdd, "__version__", "unknown"),
            "NumberType": repr(number_type),
            "exact_fraction_capable": number_type is not float,
        }
    except Exception as exc:
        report["pycddlib"] = {"available": False, "error": str(exc)}
    return report


def program_manifest() -> List[Dict[str, Any]]:
    rows = []
    for name in PROGRAMS:
        path = ROOT / name
        rows.append(
            {
                "file": name,
                "exists": path.exists(),
                "bytes": path.stat().st_size if path.exists() else None,
                "sha256": sha256(path),
            }
        )
    return rows


def run_command(args: List[str], outdir: Path, stem: str) -> Dict[str, Any]:
    log_path = outdir / f"{stem}.log"
    proc = subprocess.run(
        args,
        cwd=str(ROOT),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    log_path.write_text(proc.stdout, encoding="utf-8")
    return {"args": args, "returncode": proc.returncode, "log": str(log_path)}


def matrix_to_strings(matrix: Any) -> List[List[str]]:
    return [[str(matrix[i, j]) for j in range(matrix.cols)] for i in range(matrix.rows)]


def vector_to_strings(vector: Any) -> List[str]:
    mat = list(vector)
    return [str(x) for x in mat]


def load_module(path: Path, name: str) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def save_exact_projector_certificates(outdir: Path, only: Optional[List[str]]) -> List[Dict[str, Any]]:
    engine = load_module(ROOT / "simplex_projector_cone_vector_audit.py", "simplex_projector_cone_vector_audit")

    results = engine.run_rational_examples(
        only=only,
        include_completed=True,
        max_dual_recovery_coeffs=2500,
        allow_float_cdd=False,
        certify=True,
    )

    summaries: List[Dict[str, Any]] = []
    cert_dir = outdir / "exact_projector_certificates"
    cert_dir.mkdir(parents=True, exist_ok=True)

    for name, result in results.items():
        summary = dict(result["summary"])
        safe = (
            name.replace("/", "_")
            .replace("\\", "_")
            .replace(" ", "_")
            .replace("-", "_")
            .replace(".", "")
        )
        cert = result.get("certificate", {})
        numeric = result.get("numeric", {})
        fragment_a = result.get("fragmentA")
        payload: Dict[str, Any] = {
            "name": name,
            "summary": summary,
            "state_facets_Homega": matrix_to_strings(result["Homega"]),
            "effect_facets_Hxi": matrix_to_strings(result["Hxi"]),
            "Iomega": matrix_to_strings(fragment_a.Iomega),
            "Ixi": matrix_to_strings(fragment_a.Ixi),
            "depF": matrix_to_strings(fragment_a.depF),
            "M0": matrix_to_strings(numeric["M0"]),
            "M1": matrix_to_strings(numeric["M1"]),
            "r_rational": str(cert.get("r_rat", "")),
            "sigma_rational": matrix_to_strings(cert["sigma_rat"]) if "sigma_rat" in cert else None,
            "dual_y_rational": vector_to_strings(cert["dual_y_rat"]) if "dual_y_rat" in cert else None,
            "primal_exact_ok": bool(cert.get("primal_exact_ok", False)),
            "dual_exact_ok": bool(cert.get("dual_exact_ok", False)),
            "exact_optimality_ok": bool(cert.get("exact_optimality_ok", False)),
            "dual_method": cert.get("dual_method"),
        }
        target = cert_dir / f"{safe}.certificate.json"
        write_json(target, payload)
        summary["certificate_file"] = str(target)
        summaries.append(summary)

    write_json(outdir / "exact_projector_certificate_index.json", summaries)
    return summaries


def write_index(outdir: Path, run_reports: Iterable[Dict[str, Any]]) -> None:
    lines = [
        "# Simplex Supplement Run",
        "",
        "Generated by `simplex_ultimate_audit.py`.",
        "",
        "## Files",
        "",
        "- `projector_cone_table_manifest.json`: all rows of Table I.",
        "- `operational_closure_table_manifest.json`: all rows of Table II.",
        "- `certificate_status_manifest.json`: exact/numerical status for every row.",
        "- `program_manifest.json`: bundled programs and SHA-256 hashes.",
        "- `dependency_report.json`: Python and cddlib capability report.",
        "",
        "## Run Reports",
        "",
    ]
    any_report = False
    for report in run_reports:
        any_report = True
        lines.append(f"- returncode={report['returncode']} command=`{' '.join(report['args'])}` log=`{report['log']}`")
    if not any_report:
        lines.append("- No solver runs requested. Use `--run-full` to regenerate numerical LP summaries.")
    lines.append("")
    lines.append("Exact certificate files are emitted only when `--save-exact-certificates` is used in a fraction/GMP-capable cddlib environment.")
    (outdir / "README.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(description="Write and optionally regenerate all simplex manuscript results.")
    parser.add_argument("--outdir", default=str(ROOT / "ultimate_run"), help="Directory for generated manifests and logs.")
    parser.add_argument("--extra-site-packages", action="append", default=[], help="Append an additional site-packages directory before importing audit dependencies.")
    parser.add_argument("--run-full", action="store_true", help="Run projector and closure audit scripts.")
    parser.add_argument("--allow-float-cdd", action="store_true", help="Pass --allow-float-cdd to audit scripts.")
    parser.add_argument("--save-exact-certificates", action="store_true", help="Serialize exact projector certificates; requires exact pycddlib.")
    parser.add_argument("--only", action="append", default=None, help="Restrict exact-certificate serialization to matching projector rows.")
    args = parser.parse_args()

    for site_dir in args.extra_site_packages:
        if site_dir not in sys.path:
            sys.path.append(site_dir)

    outdir = Path(args.outdir).resolve()
    outdir.mkdir(parents=True, exist_ok=True)

    certificate_status = {
        "projector_cone_rows": [
            {
                "configuration": row["configuration"],
                "r": row["r"],
                "status": row["status"],
                "exact_primal": row["exact_primal"],
                "exact_dual": row["exact_dual"],
            }
            for row in PROJECTOR_ROWS
        ],
        "closure_rows": [
            {
                "configuration": row["configuration"],
                "closure_variant": row["closure_variant"],
                "r": row["r"],
                "status": row["status"],
                "exact_primal": False,
                "exact_dual": False,
            }
            for row in CLOSURE_ROWS
        ],
    }

    write_json(outdir / "projector_cone_table_manifest.json", PROJECTOR_ROWS)
    write_json(outdir / "operational_closure_table_manifest.json", CLOSURE_ROWS)
    write_json(outdir / "certificate_status_manifest.json", certificate_status)
    write_json(outdir / "program_manifest.json", program_manifest())
    write_json(outdir / "dependency_report.json", dependency_report())

    run_reports: List[Dict[str, Any]] = []
    if args.run_full:
        projector_json = outdir / "projector_cone_audit_run.json"
        cmd = [
            sys.executable,
            str(ROOT / "simplex_projector_cone_vector_audit.py"),
            "--all",
            "--include-completed",
            "--include-pentagon",
            "--summary-json",
            str(projector_json),
        ]
        if args.allow_float_cdd:
            cmd.append("--allow-float-cdd")
        run_reports.append(run_command(cmd, outdir, "projector_cone_audit_run"))

        closure_json = outdir / "operational_closure_audit_run.json"
        cmd = [
            sys.executable,
            str(ROOT / "simplex_operational_closure_vector_audit.py"),
            "--variant",
            "both",
            "--summary-json",
            str(closure_json),
        ]
        if args.allow_float_cdd:
            cmd.append("--allow-float-cdd")
        run_reports.append(run_command(cmd, outdir, "operational_closure_audit_run"))

    if args.save_exact_certificates:
        try:
            summaries = save_exact_projector_certificates(outdir, args.only)
            write_json(outdir / "exact_certificate_generation_status.json", {"ok": True, "rows": summaries})
        except Exception as exc:
            write_json(outdir / "exact_certificate_generation_status.json", {"ok": False, "error": str(exc)})
            raise

    write_index(outdir, run_reports)
    print(f"Wrote supplement manifests to {outdir}")


if __name__ == "__main__":
    main()
