"""
Operational-closure simplex audits for the explicit vector sets.

This companion script imports simplex_projector_cone_vector_audit.py for the
coordinate conventions, vector lists, accessible-fragment reduction, cone facets,
and noisy simplex LP.  It then replaces the projector-only effect set by a
vector-generated operational closure:

  * start from the listed rank-one projectors,
  * add the unit effect,
  * for each mutually orthogonal subset of listed rays, form the PVM consisting
    of those projectors plus the residual effect I - sum(P_i), when nonzero,
  * add every nonempty proper coarse graining of that PVM,
  * quotient duplicate effects by equality of their raw coordinates.

Two preparation variants are available:

  effects:
      original sharp eigenpreparations plus the maximally mixed preparation.

  effects-and-preps:
      also add normalized versions of the closed PVM event effects as
      preparations, when their trace is nonzero.

This is a vector-generated closure, not a substitute for a hand-specified
operational scenario with externally supplied context labels and equivalence
classes.  It is intended to answer: what changes when the omitted unit,
complement, coarse-graining, and operator-equality data are put back in using
the same vector geometry?
"""

from __future__ import annotations

from collections import Counter
from fractions import Fraction
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
import argparse
import itertools
import json
import sys


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

import simplex_projector_cone_vector_audit as engine


RawVec = List[Any]


def solve_stage3_dual_numeric(A: Any, Homega: Any, Hxi: Any) -> Dict[str, Any]:
    """Solve the numerical dual of the noisy simplex LP.

    The primal has one sigma variable for every pair of state/effect facets,
    which can become very large for operational closures.  The dual has only
    k_xi*k_omega free variables and one inequality per facet pair.  For qutrit
    closures this often means 36 variables instead of hundreds of thousands.
    """
    np = engine.np
    linprog = engine.linprog
    M0, M1 = engine.stage3_core_matrices(A)
    kxi, kom = M0.rows, M0.cols
    n_y = kxi * kom
    n_sigma = Hxi.rows * Homega.rows

    b = np.array(M0.reshape(n_y, 1), dtype=float).reshape(-1)
    m1 = np.array(M1.reshape(n_y, 1), dtype=float).reshape(-1)
    Hxi_f = np.array(Hxi.tolist(), dtype=float)
    Homega_f = np.array(Homega.tolist(), dtype=float)

    print(
        f"  Stage 3 dual: assembling {n_sigma + 1} inequalities "
        f"in {n_y} free variables...",
        flush=True,
    )
    A_ub = np.empty((1 + n_sigma, n_y), dtype=float)
    b_ub = np.zeros(1 + n_sigma, dtype=float)
    # r-column dual inequality: (-vec(M1)).y <= 1.
    A_ub[0, :] = -m1
    b_ub[0] = 1.0
    coeff_arr = Hxi_f[:, None, :, None] * Homega_f[None, :, None, :]
    A_ub[1:, :] = coeff_arr.reshape(n_sigma, n_y)

    print("  Stage 3 dual: solving numerical LP...", flush=True)
    res = linprog(
        -b,
        A_ub=A_ub,
        b_ub=b_ub,
        bounds=[(None, None)] * n_y,
        method="highs-ds",
    )
    if not res.success:
        res = linprog(
            -b,
            A_ub=A_ub,
            b_ub=b_ub,
            bounds=[(None, None)] * n_y,
            method="highs",
        )
    if not res.success:
        raise RuntimeError(f"Dual numerical LP failed: {res.message}")
    violation = A_ub @ res.x - b_ub
    return {
        "r_float": -float(res.fun),
        "dual_y_float": res.x,
        "dual_result": res,
        "dual_max_violation": float(np.max(violation)),
        "dual_min_slack": float(np.min(b_ub - A_ub @ res.x)),
        "M0": M0,
        "M1": M1,
    }


def _evenly_spaced_indices(n: int, count: int) -> List[int]:
    if n <= 0:
        return []
    if count >= n:
        return list(range(n))
    if count <= 1:
        return [0]
    return sorted({round(i * (n - 1) / (count - 1)) for i in range(count)})


def _pair_constraint_row(Hxi_f: Any, Homega_f: Any, a: int, b: int) -> Any:
    np = engine.np
    return np.outer(Hxi_f[a, :], Homega_f[b, :]).reshape(-1)


def solve_stage3_dual_cutting_numeric(
    A: Any,
    Homega: Any,
    Hxi: Any,
    violation_tol: float = 1e-9,
    max_iterations: int = 80,
    add_per_iteration: int = 512,
    initial_facet_sample: int = 12,
) -> Dict[str, Any]:
    """Cutting-plane version of the numerical dual solve.

    This avoids materializing all H_xi*H_omega facet-pair inequalities.  At
    every iteration the current dual matrix Y is checked by computing
    H_xi Y H_omega^T; positive entries are violated inequalities.
    """
    np = engine.np
    linprog = engine.linprog
    M0, M1 = engine.stage3_core_matrices(A)
    kxi, kom = M0.rows, M0.cols
    n_y = kxi * kom
    b_obj = np.array(M0.reshape(n_y, 1), dtype=float).reshape(-1)
    m1 = np.array(M1.reshape(n_y, 1), dtype=float).reshape(-1)
    Hxi_f = np.array(Hxi.tolist(), dtype=float)
    Homega_f = np.array(Homega.tolist(), dtype=float)
    n_xi, n_omega = Hxi_f.shape[0], Homega_f.shape[0]

    active_pairs = set()
    sample_a = _evenly_spaced_indices(n_xi, min(initial_facet_sample, n_xi))
    sample_b = _evenly_spaced_indices(n_omega, min(initial_facet_sample, n_omega))
    for a in sample_a:
        for b in sample_b:
            active_pairs.add((a, b))
    for i in range(min(n_xi, n_omega)):
        active_pairs.add((i, i))

    last_res = None
    max_violation = float("inf")
    for iteration in range(1, max_iterations + 1):
        pairs = sorted(active_pairs)
        A_ub = np.empty((1 + len(pairs), n_y), dtype=float)
        b_ub = np.zeros(1 + len(pairs), dtype=float)
        A_ub[0, :] = -m1
        b_ub[0] = 1.0
        for row_index, (a, b) in enumerate(pairs, start=1):
            A_ub[row_index, :] = _pair_constraint_row(Hxi_f, Homega_f, a, b)

        print(
            f"  Stage 3 cutting dual: iteration {iteration}, "
            f"active inequalities={len(pairs) + 1}",
            flush=True,
        )
        res = linprog(
            -b_obj,
            A_ub=A_ub,
            b_ub=b_ub,
            bounds=[(None, None)] * n_y,
            method="highs-ds",
        )
        if not res.success:
            res = linprog(
                -b_obj,
                A_ub=A_ub,
                b_ub=b_ub,
                bounds=[(None, None)] * n_y,
                method="highs",
            )
        if not res.success:
            # Add a broader deterministic seed if the restricted dual is
            # unbounded or otherwise too weak, then retry.
            grow = min(max(initial_facet_sample * (2 ** iteration), initial_facet_sample), max(n_xi, n_omega))
            for a in _evenly_spaced_indices(n_xi, min(grow, n_xi)):
                for b in _evenly_spaced_indices(n_omega, min(grow, n_omega)):
                    active_pairs.add((a, b))
            continue

        last_res = res
        Y = res.x.reshape((kxi, kom))
        violations = Hxi_f @ Y @ Homega_f.T
        max_violation = float(np.max(violations))
        print(
            f"    objective={-float(res.fun):.12g}; "
            f"max dual violation={max_violation:.3g}",
            flush=True,
        )
        if max_violation <= violation_tol:
            return {
                "r_float": -float(res.fun),
                "dual_y_float": res.x,
                "dual_result": res,
                "dual_max_violation": max_violation,
                "dual_min_slack": float(-np.max(violations)),
                "active_pair_inequalities": len(active_pairs),
                "cutting_iterations": iteration,
                "M0": M0,
                "M1": M1,
            }

        flat = violations.reshape(-1)
        k = min(add_per_iteration, flat.size)
        candidate_indices = np.argpartition(flat, -k)[-k:]
        added = 0
        for idx in candidate_indices:
            if flat[idx] <= violation_tol:
                continue
            a = int(idx // n_omega)
            b = int(idx % n_omega)
            before = len(active_pairs)
            active_pairs.add((a, b))
            if len(active_pairs) > before:
                added += 1
        if added == 0:
            # Numerical tie near tolerance; add the worst offender explicitly.
            idx = int(np.argmax(flat))
            active_pairs.add((idx // n_omega, idx % n_omega))

    print("  Stage 3 cutting dual did not converge; falling back to full dual.", flush=True)
    full = solve_stage3_dual_numeric(A, Homega, Hxi)
    if last_res is not None:
        full["cutting_last_objective"] = -float(last_res.fun)
        full["cutting_last_max_violation"] = max_violation
        full["cutting_fallback"] = True
    return full


def dot(u: Sequence[Any], v: Sequence[Any]) -> Any:
    return sum(ui * vi for ui, vi in zip(u, v))


def add_vecs(rows: Iterable[Sequence[Any]]) -> RawVec:
    rows = [list(row) for row in rows]
    if not rows:
        raise ValueError("cannot add an empty list of vectors")
    return [sum(row[j] for row in rows) for j in range(len(rows[0]))]


def sub_vec(u: Sequence[Any], v: Sequence[Any]) -> RawVec:
    return [ui - vi for ui, vi in zip(u, v)]


def scale_vec(c: Any, u: Sequence[Any]) -> RawVec:
    return [c * ui for ui in u]


def is_zero_vec(u: Sequence[Any]) -> bool:
    return all(x == 0 for x in u)


def trace_raw(u: Sequence[Any], d: int) -> Any:
    return sum(u[:d])


def identity_raw(d: int) -> RawVec:
    return [engine.sp.Rational(1)] * d + [engine.sp.Rational(0)] * (d * (d - 1) // 2)


def maximally_mixed_raw(d: int) -> RawVec:
    return scale_vec(engine.sp.Rational(1, d), identity_raw(d))


def dedup(rows: Iterable[Sequence[Any]]) -> List[RawVec]:
    seen = set()
    out: List[RawVec] = []
    for row in rows:
        key = tuple(row)
        if key not in seen:
            seen.add(key)
            out.append(list(row))
    return out


def primitive_rays(rays: Sequence[Sequence[int]]) -> List[Tuple[int, ...]]:
    seen = set()
    out: List[Tuple[int, ...]] = []
    for ray in rays:
        key = engine.primitive_integer_ray(ray)
        if key not in seen:
            seen.add(key)
            out.append(key)
    return out


def orthogonal_subsets(
    rays: Sequence[Sequence[int]],
    d: int,
    min_size: int = 1,
    max_size: Optional[int] = None,
) -> List[Tuple[int, ...]]:
    """All pairwise-orthogonal subsets up to dimension d."""
    if max_size is None:
        max_size = d
    max_size = min(max_size, d, len(rays))
    out: List[Tuple[int, ...]] = []
    for size in range(max(1, min_size), max_size + 1):
        for subset in itertools.combinations(range(len(rays)), size):
            if all(dot(rays[i], rays[j]) == 0 for i, j in itertools.combinations(subset, 2)):
                out.append(subset)
    return out


def nontrivial_coarse_grainings(outcomes: Sequence[Sequence[Any]]) -> List[RawVec]:
    """All nonempty proper sums of PVM outcomes."""
    n = len(outcomes)
    rows: List[RawVec] = []
    if n <= 1:
        return rows
    for size in range(1, n):
        for subset in itertools.combinations(range(n), size):
            rows.append(add_vecs(outcomes[i] for i in subset))
    return rows


def build_closed_fragment(
    rays_in: Sequence[Sequence[int]],
    d: int,
    prep_variant: str = "effects",
    context_min_size: int = 1,
    context_max_size: Optional[int] = None,
) -> Tuple[Any, Dict[str, Any]]:
    """Construct a rational vector-generated operational closure."""
    sp = engine.sp
    rays = primitive_rays(rays_in)
    projector_raws = [engine.projector_raw(ray) for ray in rays]
    I = identity_raw(d)
    subsets = orthogonal_subsets(rays, d, min_size=context_min_size, max_size=context_max_size)

    raw_effect_labels: List[RawVec] = []
    raw_effect_labels.extend(projector_raws)
    raw_effect_labels.append(I)

    residual_count = 0
    context_sizes = Counter()
    pvm_sizes = Counter()
    for subset in subsets:
        context_sizes[len(subset)] += 1
        outcomes = [projector_raws[i] for i in subset]
        residual = sub_vec(I, add_vecs(outcomes))
        if not is_zero_vec(residual):
            outcomes.append(residual)
            residual_count += 1
        pvm_sizes[len(outcomes)] += 1
        raw_effect_labels.extend(nontrivial_coarse_grainings(outcomes))

    raw_effects = dedup(raw_effect_labels)
    raw_states = list(projector_raws)
    raw_states.append(maximally_mixed_raw(d))

    if prep_variant == "effects-and-preps":
        for effect_raw in raw_effects:
            tr = trace_raw(effect_raw, d)
            if tr != 0:
                raw_states.append(scale_vec(sp.Rational(1, 1) / tr, effect_raw))
    elif prep_variant != "effects":
        raise ValueError("prep_variant must be 'effects' or 'effects-and-preps'")

    raw_states = dedup(raw_states)
    effects = [engine.effect_from_projector_raw(effect_raw, d) for effect_raw in raw_effects]
    fragment = engine.FragmentF(
        VomegaF=engine.matQ(raw_states),
        VxiF=engine.matQ(effects),
        unitF=engine.sp.Matrix(engine.identity_effect_raw(d)),
        depF=engine.depolarizing_map_raw(d),
        d_hilbert=d,
    )

    trace_counts = Counter(str(trace_raw(effect_raw, d)) for effect_raw in raw_effects)
    metadata = {
        "prep_variant": prep_variant,
        "hilbert_dim": d,
        "input_rays": len(rays_in),
        "projective_rays": len(rays),
        "context_min_size": context_min_size,
        "context_max_size": min(context_max_size if context_max_size is not None else d, d),
        "orthogonal_subsets": len(subsets),
        "orthogonal_subsets_by_size": dict(sorted(context_sizes.items())),
        "pvm_sizes": dict(sorted(pvm_sizes.items())),
        "residual_effects_added_before_dedup": residual_count,
        "effect_labels_before_dedup": len(raw_effect_labels),
        "effect_generators": len(raw_effects),
        "state_generators": len(raw_states),
        "effect_trace_counts": dict(sorted(trace_counts.items())),
    }
    return fragment, metadata


def run_closed_case(
    name: str,
    rays: Sequence[Sequence[int]],
    d: int,
    prep_variant: str,
    context_min_size: int,
    context_max_size: Optional[int],
    allow_float_cdd: bool,
    certify: bool,
    lp_solver: str,
    dual_threshold: int,
    max_denominator: int,
    max_dual_recovery_coeffs: int,
) -> Dict[str, Any]:
    print("\n" + "=" * 72, flush=True)
    print(f"CLOSURE {name} [{prep_variant}]", flush=True)
    fragment, metadata = build_closed_fragment(
        rays,
        d,
        prep_variant=prep_variant,
        context_min_size=context_min_size,
        context_max_size=context_max_size,
    )
    A = engine.accessible_fragment(fragment)
    print(
        f"  generators: states={fragment.VomegaF.rows}, effects={fragment.VxiF.rows}; "
        f"accessible dims=({A.VomegaA.cols},{A.VxiA.cols})",
        flush=True,
    )
    print(
        f"  orthogonal subsets={metadata['orthogonal_subsets']} "
        f"by size={metadata['orthogonal_subsets_by_size']}",
        flush=True,
    )
    Homega, homega_source = engine.cone_facets_for_audit(A.VomegaA, allow_float_cdd=allow_float_cdd)
    Hxi, hxi_source = engine.cone_facets_for_audit(A.VxiA, allow_float_cdd=allow_float_cdd)
    print(f"  facets: H_omega={Homega.rows}, H_xi={Hxi.rows} ({homega_source}/{hxi_source})", flush=True)
    n_sigma = int(Homega.rows * Hxi.rows)
    selected_solver = lp_solver
    if selected_solver == "auto":
        selected_solver = "cutting-dual" if n_sigma >= dual_threshold else "primal"
    if selected_solver == "dual":
        num = solve_stage3_dual_numeric(A, Homega, Hxi)
    elif selected_solver == "cutting-dual":
        num = solve_stage3_dual_cutting_numeric(A, Homega, Hxi)
    elif selected_solver == "primal":
        num = engine.solve_stage3_numeric(A, Homega, Hxi)
    else:
        raise ValueError("lp_solver must be 'auto', 'primal', 'dual', or 'cutting-dual'")
    r_orientation = engine.rationalize_float(num["r_float"], max_denominator)
    print(f"  numerical r = {num['r_float']:.12g}", flush=True)
    print(f"  rationalization, for orientation only = {r_orientation}", flush=True)

    exact_facet_source = homega_source == "exact-cdd" and hxi_source == "exact-cdd"
    cert: Dict[str, Any] = {
        "r_rat": r_orientation,
        "primal_exact_ok": False,
        "dual_exact_ok": False,
        "exact_optimality_ok": False,
        "certificate_skipped": "default numerical closure run",
    }
    if certify and exact_facet_source and selected_solver == "primal":
        print("  certifying exact primal and dual certificates...", flush=True)
        cert = engine.certify_from_numeric(
            A,
            Homega,
            Hxi,
            num,
            max_denominator=max_denominator,
            max_dual_recovery_coeffs=max_dual_recovery_coeffs,
        )
        print(f"  rationalized r = {cert['r_rat']}", flush=True)
        print(f"  exact primal certificate: {cert['primal_exact_ok']}", flush=True)
        print(f"  exact dual/optimality certificate: {cert['dual_exact_ok']}", flush=True)
    else:
        if not exact_facet_source:
            reason = "float cdd facets"
        elif selected_solver != "primal":
            reason = "dual numerical solve has no primal sigma certificate"
        else:
            reason = "--certify not requested"
        cert["certificate_skipped"] = reason
        print(f"  exact certificate skipped: {reason}", flush=True)

    summary = {
        "name": name,
        **metadata,
        "state_accessible_dim": int(A.VomegaA.cols),
        "effect_accessible_dim": int(A.VxiA.cols),
        "state_facets": int(Homega.rows),
        "effect_facets": int(Hxi.rows),
        "facet_product": n_sigma,
        "lp_solver": selected_solver,
        "state_facet_source": homega_source,
        "effect_facet_source": hxi_source,
        "r_float": float(num["r_float"]),
        "r_rationalized": str(cert["r_rat"]),
        "dual_max_violation": num.get("dual_max_violation"),
        "cutting_iterations": num.get("cutting_iterations"),
        "active_pair_inequalities": num.get("active_pair_inequalities"),
        "primal_exact_ok": bool(cert.get("primal_exact_ok", False)),
        "dual_exact_ok": bool(cert.get("dual_exact_ok", False)),
        "exact_optimality_ok": bool(cert.get("exact_optimality_ok", False)),
        "certificate_note": cert.get("certificate_skipped", cert.get("dual_method", "")),
    }
    return {
        "name": name,
        "fragmentF": fragment,
        "fragmentA": A,
        "Homega": Homega,
        "Hxi": Hxi,
        "numeric": num,
        "certificate": cert,
        "summary": summary,
    }


def matches_only(name: str, only: Optional[Sequence[str]]) -> bool:
    if not only:
        return True
    low = name.lower()
    return any(token.lower() in low for token in only)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run vector-generated operational-closure simplex diagnostics.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument("--list", action="store_true", help="List available rational vector sets and exit.")
    parser.add_argument("--only", action="append", default=None, help="Run only examples whose name contains this substring.")
    parser.add_argument(
        "--variant",
        choices=["effects", "effects-and-preps", "both"],
        default="both",
        help="Which closure variant to run.",
    )
    parser.add_argument("--context-min-size", type=int, default=1, help="Smallest orthogonal subset used to generate a PVM.")
    parser.add_argument("--context-max-size", type=int, default=None, help="Largest orthogonal subset used to generate a PVM; default is d.")
    parser.add_argument("--allow-float-cdd", action="store_true", help="Use numerical cdd facets if pycddlib is float-only.")
    parser.add_argument("--certify", action="store_true", help="Attempt exact certificate recovery when exact facets are available.")
    parser.add_argument(
        "--lp-solver",
        choices=["auto", "primal", "dual", "cutting-dual"],
        default="auto",
        help="Numerical LP formulation. Auto uses the cutting dual for large facet products.",
    )
    parser.add_argument(
        "--dual-threshold",
        type=int,
        default=50000,
        help="Facet-product threshold at which --lp-solver auto switches from primal to dual.",
    )
    parser.add_argument("--summary-json", default=None, help="Write a JSON list of compact run summaries to this path.")
    parser.add_argument("--max-denominator", type=int, default=10**8, help="Maximum denominator for rationalizing numerical optima.")
    parser.add_argument("--max-dual-recovery-coeffs", type=int, default=2500, help="Guard for exact dual recovery.")
    args = parser.parse_args()

    if args.list:
        for name, rays, d in engine.RATIONAL_VECTOR_EXAMPLES:
            print(f"{name}: d={d}, rays={len(rays)}")
        raise SystemExit(0)

    variants = ["effects", "effects-and-preps"] if args.variant == "both" else [args.variant]
    results: Dict[str, Dict[str, Any]] = {}
    for name, rays, d in engine.RATIONAL_VECTOR_EXAMPLES:
        if not matches_only(name, args.only):
            continue
        for variant in variants:
            key = f"{name} [{variant}]"
            results[key] = run_closed_case(
                name=name,
                rays=rays,
                d=d,
                prep_variant=variant,
                context_min_size=args.context_min_size,
                context_max_size=args.context_max_size,
                allow_float_cdd=args.allow_float_cdd,
                certify=args.certify,
                lp_solver=args.lp_solver,
                dual_threshold=args.dual_threshold,
                max_denominator=args.max_denominator,
                max_dual_recovery_coeffs=args.max_dual_recovery_coeffs,
            )

    summaries = [result["summary"] for result in results.values()]
    if args.summary_json:
        with open(args.summary_json, "w", encoding="utf-8") as f:
            json.dump(summaries, f, indent=2, sort_keys=True)
            f.write("\n")
    if summaries:
        print("\nSUMMARY")
        print(json.dumps(summaries, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
