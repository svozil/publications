"""
Exact/rational implementation skeleton for the Selby--Wolfe--Schmid--Sainz--Rossi
simplex-embedding formalism, adapted to finite ray configurations.

Core convention
---------------
Rays are real Hilbert-space vectors.  A rank-one projector |v><v|/<v|v>
is represented in the *raw real-symmetric basis*

    (rho_11, ..., rho_dd, rho_12, rho_13, ..., rho_{d-1,d}).

This basis is deliberately NOT trace-orthonormal; it is rational for integer
rays.  To keep Born probabilities as ordinary dot products, effects are
represented as G * E_raw, where

    G = diag(1,...,1, 2,...,2).

Then

    effect_vector . state_vector = Tr(E rho).

This avoids sqrt(2) factors and makes cddlib exact over Q for integer/rational
ray configurations.

Stages implemented
------------------
Stage 0: ray projectors -> GPT fragment (V_Omega^F, V_Xi^F, u^F, DepMap)
Stage 1: accessible-fragment reduction using exact rational bases I_Omega, I_Xi
Stage 2: exact cone facets with pycddlib/cddlib, when coordinates are rational
Stage 3: numerical LP solve + exact primal/dual certificate verification after rationalization

Important limitation
--------------------
pycddlib with number_type='fraction' is exact over Q only.  Configurations with
sqrt(2), sqrt(5), or trigonometric algebraic coordinates require either an
algebraic-number polyhedral backend or prior exact rational reformulation.  This
script therefore certifies rational ray configurations exactly (e.g. Yu--Oh,
Yu--Oh completion, Tkadlec nonunital, Cabello 18/9, Peres 24), while Specker
bug/Gamma_3/KCBS pentagon still need separate algebraic or numerical handling.

Version 5 keeps the pentagon branch and adds a guard against an expensive
complementary-slackness dual-recovery step for large facet products.  Without
this guard the program can appear to stop after the Yu--Oh 25 numerical optimum,
because cddlib is then asked to search a large parameter polyhedron.  The exact
primal certificate is still verified; only the optional dual-recovery fallback is
skipped by default for large cases.

Version 6 adds a cheaper exact dual-recovery route before that guard: solve the
floating-point dual, identify nearly active dual inequalities, select a small
independent active system, solve it exactly over Q, and then verify the proposed
dual certificate against all inequalities exactly.  This can avoid the large
complementary-slackness parameter polyhedron entirely.

Version 7 avoids a Cabello-scale stall in the active-set route.  It builds exact
active rows only after the numerical active candidates have been identified,
uses the numerical independence test to select a square system without an
expensive exact rank precheck, and verifies dual inequalities by direct rational
arithmetic rather than by calling simplify on every dot product.

Version 8 changes the default driver from "rerun everything" to "resume the
unfinished exact audit".  Rows already certified in previous runs are skipped by
default, and the numerical pentagon branch is opt-in.  Use --all to recover the
old comprehensive behavior.

Version 9 moves exact sigma-coefficient construction out of the numerical LP
assembly.  Cabello has 146*146 coefficient matrices of size 10*10; building all
of them as SymPy objects before even printing the numerical optimum can look
like a stall.  The Stage-3 numerical LP is now assembled directly with NumPy
outer products, and exact coefficients are constructed later, with progress
messages, only when certificate checking needs them.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
import argparse
import json
import sys

import itertools
import math

import numpy as np
import sympy as sp
from scipy.optimize import linprog

try:
    import cdd  # pycddlib
except Exception:  # pragma: no cover
    cdd = None


SCRIPT_NOTE = """\
This file summarizes the projector-cone computations for the explicit vector
sets used in the manuscript.  With a fraction/GMP-enabled pycddlib it performs
the rational facet computation and exact certificate checks inherited from the
v9 audit.  With a float-only pycddlib wheel, pass --allow-float-cdd to obtain
numerical facet/LP summaries; those rows are not exact certificates.
"""


# ---------------------------------------------------------------------------
# Exact rational utilities
# ---------------------------------------------------------------------------


def Q(x: Any) -> sp.Rational:
    """Convert Python ints/Fractions/strings/SymPy rationals to SymPy Rational."""
    if isinstance(x, sp.Rational):
        return x
    if isinstance(x, Fraction):
        return sp.Rational(x.numerator, x.denominator)
    return sp.Rational(x)


def to_fraction(x: sp.Rational) -> Fraction:
    x = sp.Rational(x)
    return Fraction(int(x.p), int(x.q))


def matQ(rows: Sequence[Sequence[Any]]) -> sp.Matrix:
    return sp.Matrix([[Q(x) for x in row] for row in rows])


def np_float(M: sp.Matrix | Sequence[Sequence[Any]]) -> np.ndarray:
    if isinstance(M, sp.MatrixBase):
        return np.array(M.tolist(), dtype=float)
    return np.array(M, dtype=float)


def rationalize_float(x: float, max_denominator: int = 10**8) -> sp.Rational:
    f = Fraction(float(x)).limit_denominator(max_denominator)
    return sp.Rational(f.numerator, f.denominator)


def rationalize_array(arr: np.ndarray, max_denominator: int = 10**8, zero_tol: float = 1e-10) -> sp.Matrix:
    rows = []
    for row in np.asarray(arr):
        out = []
        for val in row:
            val = float(val)
            if abs(val) < zero_tol:
                out.append(sp.Rational(0))
            else:
                out.append(rationalize_float(val, max_denominator))
        rows.append(out)
    return sp.Matrix(rows)


# ---------------------------------------------------------------------------
# Stage 0: quantum ray configuration -> real vector GPT fragment
# ---------------------------------------------------------------------------


def raw_dim(d: int) -> int:
    return d * (d + 1) // 2


def trace_metric_diag(d: int) -> List[sp.Rational]:
    """Diagonal G such that Tr(A B) = raw(A)^T G raw(B)."""
    return [sp.Rational(1)] * d + [sp.Rational(2)] * (d * (d - 1) // 2)


def projector_raw(v: Sequence[Any]) -> List[sp.Rational]:
    """Rank-one real projector in raw symmetric coordinates."""
    w = [Q(x) for x in v]
    n = sum(x * x for x in w)
    if n == 0:
        raise ValueError("zero ray")
    d = len(w)
    out: List[sp.Rational] = []
    for i in range(d):
        out.append(sp.factor(w[i] * w[i] / n))
    for i in range(d - 1):
        for j in range(i + 1, d):
            out.append(sp.factor(w[i] * w[j] / n))
    return out


def effect_from_projector_raw(p: Sequence[Any], d: int) -> List[sp.Rational]:
    g = trace_metric_diag(d)
    return [Q(gi) * Q(pi) for gi, pi in zip(g, p)]


def identity_effect_raw(d: int) -> List[sp.Rational]:
    """Unit effect in the effect-vector convention e=G*I_raw."""
    return [sp.Rational(1)] * d + [sp.Rational(0)] * (d * (d - 1) // 2)


def depolarizing_map_raw(d: int) -> sp.Matrix:
    """Column-vector state map rho -> Tr(rho) I/d in raw coordinates."""
    D = raw_dim(d)
    M = sp.zeros(D, D)
    for out_i in range(d):
        for in_j in range(d):
            M[out_i, in_j] = sp.Rational(1, d)
    return M


def unique_projectors_from_rays(rays: Sequence[Sequence[Any]]) -> List[List[sp.Rational]]:
    seen = set()
    out: List[List[sp.Rational]] = []
    for r in rays:
        p = projector_raw(r)
        key = tuple(p)
        if key not in seen:
            seen.add(key)
            out.append(p)
    return out


@dataclass
class FragmentF:
    VomegaF: sp.Matrix  # rows: states in full coordinates
    VxiF: sp.Matrix     # rows: effects in full coordinates
    unitF: sp.Matrix    # column full-coordinate unit effect
    depF: sp.Matrix     # full-coordinate depolarizing map on states
    d_hilbert: int


def fragment_from_rays(rays: Sequence[Sequence[Any]], d_hilbert: int) -> FragmentF:
    projs = unique_projectors_from_rays(rays)
    states = projs
    effects = [effect_from_projector_raw(p, d_hilbert) for p in projs]
    return FragmentF(
        VomegaF=matQ(states),
        VxiF=matQ(effects),
        unitF=sp.Matrix(identity_effect_raw(d_hilbert)),
        depF=depolarizing_map_raw(d_hilbert),
        d_hilbert=d_hilbert,
    )


# ---------------------------------------------------------------------------
# Stage 1: exact accessible-fragment reduction
# ---------------------------------------------------------------------------


def column_basis_for_row_span(V: sp.Matrix) -> sp.Matrix:
    """Return D x k matrix B whose columns span the row span of V."""
    cols = V.T.columnspace()
    if not cols:
        raise ValueError("empty row span")
    return sp.Matrix.hstack(*cols)


def coordinates_in_basis(V: sp.Matrix, B: sp.Matrix) -> sp.Matrix:
    """Rows y such that B*y_col = original row^T."""
    coords = []
    for i in range(V.rows):
        x = V.row(i).T
        sol = B.gauss_jordan_solve(x)[0]
        coords.append([sp.factor(s) for s in list(sol)])
    return sp.Matrix(coords)


@dataclass
class FragmentA:
    VomegaA: sp.Matrix  # rows in accessible state coords
    VxiA: sp.Matrix     # rows in accessible effect coords
    Iomega: sp.Matrix   # full coords = Iomega * accessible_state_coords
    Ixi: sp.Matrix      # full coords = Ixi * accessible_effect_coords
    unitA_xi: sp.Matrix # unit effect coordinates in effect accessible space, if contained
    depF: sp.Matrix
    d_hilbert: int


def accessible_fragment(F: FragmentF) -> FragmentA:
    Iomega = column_basis_for_row_span(F.VomegaF)
    Ixi = column_basis_for_row_span(F.VxiF)
    VomegaA = coordinates_in_basis(F.VomegaF, Iomega)
    VxiA = coordinates_in_basis(F.VxiF, Ixi)
    try:
        unitA = Ixi.gauss_jordan_solve(F.unitF)[0]
    except Exception:
        unitA = sp.Matrix([sp.nan] * Ixi.cols)
    return FragmentA(
        VomegaA=VomegaA,
        VxiA=VxiA,
        Iomega=Iomega,
        Ixi=Ixi,
        unitA_xi=unitA,
        depF=F.depF,
        d_hilbert=F.d_hilbert,
    )


# ---------------------------------------------------------------------------
# Stage 2: exact cone facets via cddlib
# ---------------------------------------------------------------------------


def _cdd_rows_to_sympy(mat: Any) -> sp.Matrix:
    if hasattr(mat, "array"):
        return sp.Matrix([[Q(x) for x in row] for row in mat.array])
    rows = []
    # pycddlib supports row_size/col_size and row indexing in common versions.
    for i in range(mat.row_size):
        row = mat.__getitem__(i)
        rows.append([Q(str(x)) for x in row])
    return sp.Matrix(rows)


def _cdd_exact_matrix(rows: Sequence[Sequence[Any]], rep_type: Any) -> Any:
    """Create a cdd Matrix over exact fractions, supporting old/new pycddlib APIs."""
    if cdd is None:
        raise ImportError("pycddlib/cdd is not installed. Install with `pip install pycddlib`.")
    frac_rows = [[to_fraction(sp.Rational(x)) for x in row] for row in rows]

    # pycddlib 2.x API, used by the original script.
    try:
        M = cdd.Matrix(frac_rows, number_type="fraction")
        M.rep_type = rep_type
        return M
    except TypeError:
        pass

    # pycddlib 3.x API.  Some Windows wheels are float-only; do not silently use
    # those for a script whose output is advertised as exact over Q.
    if hasattr(cdd, "matrix_from_array"):
        if getattr(cdd, "NumberType", None) is float:
            raise RuntimeError(
                "This pycddlib build is float-only (cdd.NumberType is float). "
                "Exact rational facets require a pycddlib/cddlib build with "
                "fraction/GMP support, or the older API accepting number_type='fraction'."
            )
        return cdd.matrix_from_array(frac_rows, rep_type=rep_type)

    raise RuntimeError("Unsupported pycddlib API: cannot construct an exact fraction matrix.")


def _cdd_polyhedron_from_matrix(M: Any) -> Any:
    try:
        return cdd.Polyhedron(M)
    except TypeError:
        if hasattr(cdd, "polyhedron_from_matrix"):
            return cdd.polyhedron_from_matrix(M)
        raise


def _cdd_inequalities(poly: Any) -> Any:
    if hasattr(poly, "get_inequalities"):
        return poly.get_inequalities()
    if hasattr(cdd, "copy_inequalities"):
        return cdd.copy_inequalities(poly)
    raise RuntimeError("Unsupported pycddlib API: cannot retrieve inequalities.")


def _cdd_generators(poly: Any) -> Any:
    if hasattr(poly, "get_generators"):
        return poly.get_generators()
    if hasattr(cdd, "copy_generators"):
        return cdd.copy_generators(poly)
    raise RuntimeError("Unsupported pycddlib API: cannot retrieve generators.")


def cone_facets_cdd(rays_rows: sp.Matrix) -> sp.Matrix:
    """Return H rows such that x in Cone(rays) iff H*x >= 0.

    cdd generator representation uses rows [0, r] for rays.  The returned
    inequalities are [b, a] meaning b + a.x >= 0.  For a cone, b should be 0.
    """
    if cdd is None:
        raise ImportError("pycddlib/cdd is not installed. Install with `pip install pycddlib`.")
    gen_rows: List[List[Fraction]] = []
    for i in range(rays_rows.rows):
        gen_rows.append([Fraction(0)] + [to_fraction(rays_rows[i, j]) for j in range(rays_rows.cols)])
    M = _cdd_exact_matrix(gen_rows, cdd.RepType.GENERATOR)
    poly = _cdd_polyhedron_from_matrix(M)
    ineq = _cdd_rows_to_sympy(_cdd_inequalities(poly))
    H_rows = []
    for i in range(ineq.rows):
        b = sp.factor(ineq[i, 0])
        a = [sp.factor(ineq[i, j]) for j in range(1, ineq.cols)]
        # For pointed cones generated by rays, b should be 0.  cdd may also
        # return redundant normalizations; keep only homogeneous facets.
        if b != 0:
            # Homogeneous cone facets should have b=0; skip non-homogeneous rows.
            # This can happen if the input was accidentally treated as vertices.
            continue
        H_rows.append(a)
    if not H_rows:
        raise RuntimeError("No homogeneous cone inequalities returned by cddlib.")
    return sp.Matrix(H_rows)


def cone_facets_float_cdd(rays_rows: sp.Matrix) -> sp.Matrix:
    """Numerical fallback for environments where pycddlib is float-only.

    The returned inequalities are suitable for a numerical LP summary, but not
    for the exact certificate verifier.
    """
    if cdd is None:
        raise ImportError("pycddlib/cdd is not installed. Install pycddlib.")
    gen_rows: List[List[float]] = []
    for i in range(rays_rows.rows):
        gen_rows.append([0.0] + [float(rays_rows[i, j]) for j in range(rays_rows.cols)])
    if hasattr(cdd, "matrix_from_array"):
        M = cdd.matrix_from_array(gen_rows, rep_type=cdd.RepType.GENERATOR)
        poly = cdd.polyhedron_from_matrix(M)
        ineq = cdd.copy_inequalities(poly)
    else:
        M = cdd.Matrix(gen_rows)
        M.rep_type = cdd.RepType.GENERATOR
        poly = cdd.Polyhedron(M)
        ineq = poly.get_inequalities()
    rows = ineq.array if hasattr(ineq, "array") else [[ineq[i, j] for j in range(ineq.col_size)] for i in range(ineq.row_size)]
    H_rows = []
    for row in rows:
        b = float(row[0])
        if abs(b) > 1e-9:
            continue
        H_rows.append([sp.Float(float(x), 30) for x in row[1:]])
    if not H_rows:
        raise RuntimeError("No homogeneous cone inequalities returned by float cddlib.")
    return sp.Matrix(H_rows)


def cone_facets_for_audit(rays_rows: sp.Matrix, allow_float_cdd: bool = False) -> Tuple[sp.Matrix, str]:
    """Return cone facets and a source label: exact-cdd or float-cdd."""
    try:
        return cone_facets_cdd(rays_rows), "exact-cdd"
    except RuntimeError as exc:
        if not allow_float_cdd or "float-only" not in str(exc):
            raise
        return cone_facets_float_cdd(rays_rows), "float-cdd"


# ---------------------------------------------------------------------------
# Stage 3: numerical LP and exact certificate verification
# ---------------------------------------------------------------------------


def stage3_matrices(A: FragmentA, Homega: sp.Matrix, Hxi: sp.Matrix) -> Tuple[sp.Matrix, sp.Matrix, List[sp.Matrix]]:
    """Return M0, M1, sigma coefficient matrices.

    Equation:
        Hxi^T sigma Homega = M0 + r M1
    where
        M0 = Ixi^T Iomega,
        M1 = Ixi^T (Dep - I) Iomega.
    This is the column-vector version of the supplement formula.  For the
    depolarizing maps used here Dep is symmetric in the raw basis, so it agrees
    with the transposed row-vector convention.
    """
    Dfull = A.depF.rows
    M0 = A.Ixi.T * A.Iomega
    M1 = A.Ixi.T * (A.depF - sp.eye(Dfull)) * A.Iomega
    coeffs: List[sp.Matrix] = []
    for a in range(Hxi.rows):
        hx = Hxi.row(a).T
        for b in range(Homega.rows):
            ho = Homega.row(b)
            coeffs.append(hx * ho)  # k_xi x k_omega
    return sp.factor(M0), sp.factor(M1), coeffs


def stage3_core_matrices(A: FragmentA) -> Tuple[sp.Matrix, sp.Matrix]:
    """Return only M0 and M1, without constructing all sigma coefficients."""
    Dfull = A.depF.rows
    M0 = A.Ixi.T * A.Iomega
    M1 = A.Ixi.T * (A.depF - sp.eye(Dfull)) * A.Iomega
    return sp.factor(M0), sp.factor(M1)


def stage3_coefficients(Homega: sp.Matrix, Hxi: sp.Matrix, progress: bool = False) -> List[sp.Matrix]:
    """Construct exact sigma coefficient matrices Hxi[a]^T Homega[b]."""
    coeffs: List[sp.Matrix] = []
    total = Hxi.rows * Homega.rows
    tick = max(1, total // 10)
    for a in range(Hxi.rows):
        hx = Hxi.row(a).T
        for b in range(Homega.rows):
            ho = Homega.row(b)
            coeffs.append(hx * ho)
            if progress and len(coeffs) % tick == 0:
                print(f"    exact coefficient matrices: {len(coeffs)}/{total}", flush=True)
    if progress and (not coeffs or len(coeffs) % tick != 0):
        print(f"    exact coefficient matrices: {len(coeffs)}/{total}", flush=True)
    return coeffs


def solve_stage3_numeric(A: FragmentA, Homega: sp.Matrix, Hxi: sp.Matrix) -> Dict[str, Any]:
    print("  Stage 3: assembling numerical LP matrices...", flush=True)
    M0, M1 = stage3_core_matrices(A)
    kxi, kom = M0.rows, M0.cols
    n_sigma = Hxi.rows * Homega.rows
    n_vars = 1 + n_sigma

    # Equality: sum sigma_j C_j - r*M1 = M0
    Aeq = np.zeros((kxi * kom, n_vars), dtype=float)
    beq = np.array(M0.reshape(kxi * kom, 1), dtype=float).reshape(-1)
    Aeq[:, 0] = -np.array(M1.reshape(kxi * kom, 1), dtype=float).reshape(-1)
    Hxi_f = np.array(Hxi.tolist(), dtype=float)
    Homega_f = np.array(Homega.tolist(), dtype=float)
    coeff_arr = Hxi_f[:, None, :, None] * Homega_f[None, :, None, :]
    Aeq[:, 1:] = coeff_arr.reshape(n_sigma, kxi * kom).T

    c = np.zeros(n_vars)
    c[0] = 1.0
    bounds = [(0.0, 1.0)] + [(0.0, None)] * n_sigma

    print(f"  Stage 3: solving LP with {kxi * kom} equalities and {n_vars} variables...", flush=True)
    res = linprog(c, A_eq=Aeq, b_eq=beq, bounds=bounds, method="highs-ds")
    if not res.success:
        # Try interior point/highs fallback.
        res = linprog(c, A_eq=Aeq, b_eq=beq, bounds=bounds, method="highs")
    if not res.success:
        raise RuntimeError(f"LP failed: {res.message}")

    r_float = float(res.x[0])
    sigma_float = res.x[1:].reshape((Hxi.rows, Homega.rows))
    return {
        "r_float": r_float,
        "sigma_float": sigma_float,
        "Aeq_float": Aeq,
        "beq_float": beq,
        "c_float": c,
        "lp_result": res,
        "M0": M0,
        "M1": M1,
        "coeffs": None,
    }


def verify_primal_exact(
    A: FragmentA,
    Homega: sp.Matrix,
    Hxi: sp.Matrix,
    r: sp.Rational,
    sigma: sp.Matrix,
) -> Tuple[bool, sp.Matrix]:
    M0, M1 = stage3_core_matrices(A)
    lhs = Hxi.T * sigma * Homega
    rhs = M0 + r * M1
    residual = sp.simplify(lhs - rhs)
    nonneg = all(x >= 0 for x in list(sigma)) and r >= 0 and r <= 1
    return bool(nonneg and residual == sp.zeros(residual.rows, residual.cols)), residual


def solve_dual_numeric(Aeq: np.ndarray, beq: np.ndarray, c: np.ndarray) -> Dict[str, Any]:
    """Solve dual max b^T y s.t. A^T y <= c with free y."""
    # scipy minimizes; minimize -b^T y subject A^T y <= c.
    n_eq = Aeq.shape[0]
    res = linprog(
        -beq,
        A_ub=Aeq.T,
        b_ub=c,
        bounds=[(None, None)] * n_eq,
        method="highs-ds",
    )
    if not res.success:
        res = linprog(-beq, A_ub=Aeq.T, b_ub=c, bounds=[(None, None)] * n_eq, method="highs")
    if not res.success:
        raise RuntimeError(f"Dual LP failed: {res.message}")
    return {"dual_y_float": res.x, "dual_obj_float": -float(res.fun), "dual_result": res}


def verify_dual_exact(M0: sp.Matrix, M1: sp.Matrix, coeffs: List[sp.Matrix], y_vec: sp.Matrix, r_star: sp.Rational) -> bool:
    """Verify exact dual certificate for primal with variables [r, sigma]>=0.

    Dual: maximize b.y subject A^T y <= c.
    Here b=vec(M0), r-column=-vec(M1), sigma columns=vec(C_j), c=(1,0,...,0).
    """
    b = list(M0.reshape(M0.rows * M0.cols, 1))
    y = list(sp.Matrix(y_vec))
    obj = sum(bi * yi for bi, yi in zip(b, y))
    if obj != r_star:
        return False
    # r column constraint: (-vec(M1)).y <= 1
    m1v = list(M1.reshape(M1.rows * M1.cols, 1))
    if -sum(mi * yi for mi, yi in zip(m1v, y)) > 1:
        return False
    # sigma constraints: vec(C_j).y <= 0
    for C in coeffs:
        cv = list(C.reshape(C.rows * C.cols, 1))
        if sum(ci * yi for ci, yi in zip(cv, y)) > 0:
            return False
    return True


def _select_independent_rows_float(
    candidates: Sequence[Tuple[List[sp.Rational], sp.Rational, np.ndarray, str]],
    n_y: int,
    rank_tol: float = 1e-10,
) -> Tuple[List[List[sp.Rational]], List[sp.Rational], List[str], int]:
    """Greedily select a numerically independent active system.

    This only proposes a rational dual.  The final certificate is accepted only
    after exact verification against every dual inequality.
    """
    rows_exact: List[List[sp.Rational]] = []
    rhs_exact: List[sp.Rational] = []
    labels: List[str] = []
    rows_float: List[np.ndarray] = []
    rank = 0
    for row_exact, rhs, row_float, label in candidates:
        trial = np.vstack(rows_float + [row_float])
        new_rank = int(np.linalg.matrix_rank(trial, tol=rank_tol))
        if new_rank > rank:
            rows_exact.append(row_exact)
            rhs_exact.append(rhs)
            labels.append(label)
            rows_float.append(row_float)
            rank = new_rank
            if rank >= n_y:
                break
    return rows_exact, rhs_exact, labels, rank


def recover_dual_from_numeric_active_set(
    M0: sp.Matrix,
    M1: sp.Matrix,
    coeffs: List[sp.Matrix],
    dual_y_float: np.ndarray,
    r_star: sp.Rational,
    active_tols: Sequence[float] = (1e-10, 1e-9, 1e-8, 1e-7, 1e-6, 1e-5, 1e-4),
    rank_tol: float = 1e-10,
    max_active_candidates_factor: int = 12,
) -> Dict[str, Any]:
    """Recover an exact dual certificate from a numerical dual active set.

    The dual variable dimension is small in these examples (36 or 100), while
    the sigma-inequality count can be thousands.  A vertex certificate needs
    only a small independent subset of active inequalities.  We identify those
    numerically, solve the selected rational system exactly, and then verify the
    full dual certificate exactly.
    """
    bvec = _flat_col(M0)
    m1vec = _flat_col(M1)
    n_y = bvec.rows
    y_float = np.asarray(dual_y_float, dtype=float).reshape(-1)
    if y_float.size != n_y:
        return {
            "ok": False,
            "method": "numeric_dual_active_set_exact_solve",
            "error": f"dual vector has length {y_float.size}, expected {n_y}",
        }

    b_float = np.array(bvec, dtype=float).reshape(-1)
    m1_float = np.array(m1vec, dtype=float).reshape(-1)
    base_candidates: List[Tuple[List[sp.Rational], sp.Rational, np.ndarray, str]] = [
        ([sp.factor(x) for x in list(bvec)], sp.Rational(r_star), b_float, "objective"),
    ]
    if sp.Rational(r_star) > 0:
        base_candidates.append((
            [sp.factor(-x) for x in list(m1vec)],
            sp.Rational(1),
            -m1_float,
            "r_bound",
        ))

    sigma_data: List[Tuple[float, int, np.ndarray]] = []
    max_violation = 0.0
    for j, C in enumerate(coeffs):
        cv = _flat_col(C)
        row_float = np.array(cv, dtype=float).reshape(-1)
        val = float(row_float @ y_float)
        max_violation = max(max_violation, val)
        sigma_data.append((abs(val), j, row_float))
    sigma_data.sort(key=lambda item: (item[0], item[1]))

    attempts: List[Dict[str, Any]] = []
    max_active_candidates = max(max_active_candidates_factor * n_y, n_y + 10)
    for tol in active_tols:
        candidates = list(base_candidates)
        active_count = 0
        truncated = False
        for abs_slack, j, row_float in sigma_data:
            if abs_slack <= tol:
                active_count += 1
                if active_count > max_active_candidates:
                    truncated = True
                    break
                cv = _flat_col(coeffs[j])
                row_exact = [sp.factor(x) for x in list(cv)]
                candidates.append((row_exact, sp.Rational(0), row_float, f"sigma[{j}]"))
            else:
                break

        rows, rhs, labels, rank = _select_independent_rows_float(candidates, n_y, rank_tol=rank_tol)
        attempt = {
            "tol": tol,
            "active_count": active_count,
            "active_truncated": truncated,
            "selected": len(rows),
            "rank": rank,
        }
        attempts.append(attempt)
        if not rows:
            continue

        E = sp.Matrix(rows)
        h = sp.Matrix(rhs)
        try:
            if E.rows == E.cols and rank == n_y:
                y = E.LUsolve(h)
            else:
                sol, par = E.gauss_jordan_solve(h)
                subs = {p: 0 for p in list(par)}
                y = sp.Matrix([sp.factor(expr.subs(subs)) for expr in sol])
        except Exception as exc:
            attempt["solve_error"] = str(exc)
            continue

        y = sp.Matrix([sp.factor(x) for x in y])
        if verify_dual_exact(M0, M1, coeffs, y, r_star):
            return {
                "ok": True,
                "method": "numeric_dual_active_set_exact_solve",
                "dual_y_rat": y,
                "active_tol": tol,
                "selected_constraints": labels,
                "selected_rank": rank,
                "active_sigma_count": active_count,
                "max_numerical_dual_violation": max_violation,
                "attempts": attempts,
            }
        attempt["verified"] = False

    return {
        "ok": False,
        "method": "numeric_dual_active_set_exact_solve",
        "error": "no active-set exact solve verified as a dual certificate",
        "max_numerical_dual_violation": max_violation,
        "attempts": attempts,
    }


def certify_from_numeric(
    A: FragmentA,
    Homega: sp.Matrix,
    Hxi: sp.Matrix,
    num: Dict[str, Any],
    max_denominator: int = 10**8,
    zero_tol: float = 1e-10,
    attempt_dual_recovery: bool = True,
    max_dual_recovery_coeffs: int = 2500,
) -> Dict[str, Any]:
    r_rat = rationalize_float(num["r_float"], max_denominator)
    sigma_rat = rationalize_array(num["sigma_float"], max_denominator, zero_tol=zero_tol)
    print("    verifying exact primal certificate...", flush=True)
    primal_ok, residual = verify_primal_exact(A, Homega, Hxi, r_rat, sigma_rat)
    if num.get("coeffs") is None:
        print("    building exact coefficient matrices for dual checks...", flush=True)
        num["coeffs"] = stage3_coefficients(Homega, Hxi, progress=True)

    dual_info: Dict[str, Any] = {}
    dual_ok = False
    dnum: Optional[Dict[str, Any]] = None

    # First try the direct numerical-dual rationalization route.
    try:
        print("    dual route 1: numerical dual rationalization", flush=True)
        dnum = solve_dual_numeric(num["Aeq_float"], num["beq_float"], num["c_float"])
        y_rat = sp.Matrix([rationalize_float(v, max_denominator) for v in dnum["dual_y_float"]])
        dual_ok = verify_dual_exact(num["M0"], num["M1"], num["coeffs"], y_rat, r_rat)
        dual_info = {"dual_y_rat": y_rat, "dual_method": "numerical_dual_rationalized", **dnum}
    except Exception as exc:
        dual_info = {"dual_error": str(exc), "dual_method": "numerical_dual_failed"}

    # If entrywise rationalization fails, solve a small exact active system
    # inferred from the numerical dual.  This is far cheaper than the old
    # parameter-polyhedron fallback for large facet products.
    if primal_ok and not dual_ok and dnum is not None and "dual_y_float" in dnum:
        print("    dual route 2: active-set exact solve from numerical dual", flush=True)
        active = recover_dual_from_numeric_active_set(
            num["M0"], num["M1"], num["coeffs"], dnum["dual_y_float"], r_rat,
        )
        if active.get("ok", False):
            dual_ok = True
            dual_info.update({
                "dual_y_rat": active["dual_y_rat"],
                "dual_method": active.get("method"),
                "dual_recovery": active,
            })
        else:
            dual_info.update({"active_set_dual_recovery": active})

    # If the direct and active-set routes fail, use complementary slackness with the exact
    # rational primal certificate to recover a dual optimum.  This can become
    # very expensive for large facet products (e.g. Yu--Oh 25 has 96*96
    # sigma variables).  Earlier versions tried cddlib on the resulting
    # parameter polyhedron unconditionally, which can make the program appear
    # to stop after printing the numerical r.  By default we therefore skip
    # the complementary-slackness recovery once the number of cone-product
    # coefficients is large; the exact primal certificate is still checked.
    if primal_ok and not dual_ok:
        n_coeffs = len(num["coeffs"])
        if (not attempt_dual_recovery) or n_coeffs > max_dual_recovery_coeffs:
            print("    dual route 3: complementary-slackness cdd fallback skipped by guard", flush=True)
            dual_info.update({
                "dual_method": "complementary_slackness_skipped_large_problem",
                "dual_recovery": {
                    "ok": False,
                    "reason": "skipped to avoid a potentially very slow cddlib parameter-polyhedron computation",
                    "n_coeffs": n_coeffs,
                    "max_dual_recovery_coeffs": max_dual_recovery_coeffs,
                },
            })
        else:
            print("    dual route 3: complementary-slackness cdd fallback", flush=True)
            cs = recover_dual_by_complementary_slackness(
                num["M0"], num["M1"], num["coeffs"], r_rat, sigma_rat,
                max_denominator=max_denominator,
            )
            if cs.get("ok", False):
                dual_ok = True
                dual_info.update({"dual_y_rat": cs["dual_y_rat"], "dual_method": cs.get("method"), "dual_recovery": cs})
            else:
                dual_info.update({"dual_recovery": cs})

    return {
        "r_rat": r_rat,
        "sigma_rat": sigma_rat,
        "primal_exact_ok": primal_ok,
        "dual_exact_ok": dual_ok,
        "exact_optimality_ok": bool(primal_ok and dual_ok),
        "residual_exact": residual,
        **dual_info,
    }




# ---------------------------------------------------------------------------
# Exact dual recovery from complementary slackness
# ---------------------------------------------------------------------------


def _flat_col(M: sp.Matrix) -> sp.Matrix:
    return sp.Matrix(M.reshape(M.rows * M.cols, 1))


def _row_from_matrix(M: sp.Matrix) -> List[sp.Rational]:
    return [sp.factor(x) for x in list(_flat_col(M))]


def _cdd_fraction(x: Any) -> Fraction:
    return to_fraction(sp.Rational(x))


def _cdd_feasible_point_from_inequalities(rows_ge: List[List[sp.Rational]]) -> Optional[sp.Matrix]:
    """Return an exact feasible point for inequalities b + a.t >= 0.

    Uses cddlib over Q.  rows_ge are [b, a1, ..., ak].  Returns a column
    vector t of length k if a vertex is found.  If cddlib is unavailable or no
    point is returned, returns None.
    """
    if cdd is None or not rows_ge:
        return None
    try:
        mat = _cdd_exact_matrix(rows_ge, cdd.RepType.INEQUALITY)
        poly = _cdd_polyhedron_from_matrix(mat)
        G = _cdd_rows_to_sympy(_cdd_generators(poly))
        # Generator rows are [1, point] for vertices and [0, ray] for rays.
        for i in range(G.rows):
            if G[i, 0] == 1:
                return sp.Matrix([sp.factor(G[i, j]) for j in range(1, G.cols)])
        return None
    except Exception:
        return None


def _scipy_feasible_point_for_parameters(rows_ge: List[List[sp.Rational]], max_denominator: int = 10**8) -> Optional[sp.Matrix]:
    """Numerical fallback for b + a.t >= 0, rationalized and returned.

    The returned point is not trusted unless final exact dual verification
    succeeds.
    """
    if not rows_ge:
        return sp.Matrix([])
    k = len(rows_ge[0]) - 1
    A_ub = []
    b_ub = []
    for row in rows_ge:
        b = row[0]
        a = row[1:]
        # b + a.t >= 0  <=>  -a.t <= b
        A_ub.append([float(-x) for x in a])
        b_ub.append(float(b))
    res = linprog(
        np.zeros(k),
        A_ub=np.array(A_ub, dtype=float),
        b_ub=np.array(b_ub, dtype=float),
        bounds=[(None, None)] * k,
        method="highs-ds",
    )
    if not res.success:
        res = linprog(
            np.zeros(k),
            A_ub=np.array(A_ub, dtype=float),
            b_ub=np.array(b_ub, dtype=float),
            bounds=[(None, None)] * k,
            method="highs",
        )
    if not res.success:
        return None
    return sp.Matrix([rationalize_float(v, max_denominator) for v in res.x])


def recover_dual_by_complementary_slackness(
    M0: sp.Matrix,
    M1: sp.Matrix,
    coeffs: List[sp.Matrix],
    r_star: sp.Rational,
    sigma_rat: sp.Matrix,
    max_denominator: int = 10**8,
) -> Dict[str, Any]:
    """Try to construct an exact dual optimum using complementary slackness.

    Primal variables are x=(r, sigma_ab) >= 0 and constraints A x = b.
    Dual variables y are free and must satisfy:

        (-vec(M1)).y <= 1,
        vec(C_j).y <= 0    for all sigma columns C_j,
        vec(M0).y = r_star.

    Complementary slackness adds equalities for positive primal variables:

        if r_star > 0: (-vec(M1)).y = 1,
        if sigma_j > 0: vec(C_j).y = 0.

    If these equalities leave parameters free, an exact rational feasible point
    in the parameter polyhedron is sought using cddlib; if cddlib cannot produce
    one, a numerical parameter search followed by exact verification is tried.
    """
    bvec = _flat_col(M0)
    m1vec = _flat_col(M1)
    n_y = bvec.rows

    # Equality rows L.y = rhs.
    eq_rows: List[List[sp.Rational]] = []
    eq_rhs: List[sp.Rational] = []

    # Objective equality: b.y = r_star.
    eq_rows.append([sp.factor(x) for x in list(bvec)])
    eq_rhs.append(sp.Rational(r_star))

    # r-column complementary slackness if r > 0: (-M1).y = 1.
    if sp.Rational(r_star) > 0:
        eq_rows.append([sp.factor(-x) for x in list(m1vec)])
        eq_rhs.append(sp.Rational(1))

    # Positive sigma entries: C_j.y = 0.
    flat_sigma = list(sigma_rat.reshape(sigma_rat.rows * sigma_rat.cols, 1))
    active = [j for j, x in enumerate(flat_sigma) if sp.Rational(x) > 0]
    for j in active:
        cv = _flat_col(coeffs[j])
        eq_rows.append([sp.factor(x) for x in list(cv)])
        eq_rhs.append(sp.Rational(0))

    E = sp.Matrix(eq_rows)
    h = sp.Matrix(eq_rhs)

    try:
        sol_tuple, params = sp.linsolve((E, h), [sp.Symbol(f"y{i}") for i in range(n_y)]).args[0], []
    except Exception:
        # More robust route: use gauss_jordan_solve to get parametric solution.
        try:
            sol, par = E.gauss_jordan_solve(h)
            params = list(par)
            sol_vec = sp.Matrix(sol)
        except Exception as exc:
            return {"ok": False, "method": "complementary_slackness", "error": f"linear solve failed: {exc}"}
    else:
        sol_vec = sp.Matrix(sol_tuple)
        params = sorted(list(sol_vec.free_symbols), key=lambda z: str(z))

    # If linsolve path above had no symbols list, infer parameters.
    if not isinstance(sol_vec, sp.MatrixBase):
        sol_vec = sp.Matrix(sol_vec)
    params = sorted(list(sol_vec.free_symbols), key=lambda z: str(z))

    if len(params) == 0:
        y = sp.Matrix([sp.factor(x) for x in sol_vec])
        ok = verify_dual_exact(M0, M1, coeffs, y, r_star)
        return {"ok": ok, "method": "complementary_slackness_unique", "dual_y_rat": y, "active_sigma": len(active), "free_parameters": 0}

    # Express y = y0 + N t with params as t.
    y0 = sp.Matrix([sp.factor(expr.subs({p: 0 for p in params})) for expr in sol_vec])
    Ncols = []
    for p in params:
        col = sp.Matrix([sp.factor(sp.diff(expr, p)) for expr in sol_vec])
        Ncols.append(col)
    Nmat = sp.Matrix.hstack(*Ncols) if Ncols else sp.zeros(n_y, 0)

    # Build parameter inequalities b + a.t >= 0.
    rows_ge: List[List[sp.Rational]] = []

    # r dual inequality: (-M1).y <= 1 -> 1 + M1.y >= 0.
    L = m1vec
    const = sp.factor(1 + (L.T * y0)[0])
    coeff = [sp.factor((L.T * Nmat.col(j))[0]) for j in range(Nmat.cols)]
    rows_ge.append([const] + coeff)

    # sigma inequalities: C_j.y <= 0 -> -C_j.y >= 0.
    for C in coeffs:
        cv = _flat_col(C)
        const = sp.factor(-(cv.T * y0)[0])
        coeff = [sp.factor(-(cv.T * Nmat.col(j))[0]) for j in range(Nmat.cols)]
        rows_ge.append([const] + coeff)

    t = _cdd_feasible_point_from_inequalities(rows_ge)
    method = "complementary_slackness_cdd_parameters"
    if t is None:
        t = _scipy_feasible_point_for_parameters(rows_ge, max_denominator=max_denominator)
        method = "complementary_slackness_scipy_parameters"
    if t is None:
        return {"ok": False, "method": "complementary_slackness", "error": "no feasible parameter point found", "active_sigma": len(active), "free_parameters": len(params)}

    y = sp.Matrix([sp.factor(x) for x in (y0 + Nmat * t)])
    ok = verify_dual_exact(M0, M1, coeffs, y, r_star)
    return {"ok": ok, "method": method, "dual_y_rat": y, "active_sigma": len(active), "free_parameters": len(params)}


# ---------------------------------------------------------------------------
# Configurations with rational ray coordinates
# ---------------------------------------------------------------------------


def primitive_integer_ray(v: Sequence[int]) -> Tuple[int, ...]:
    nums = [int(x) for x in v]
    g = 0
    for x in nums:
        g = math.gcd(g, abs(x))
    if g == 0:
        raise ValueError("zero ray")
    nums = [x // g for x in nums]
    for x in nums:
        if x != 0:
            if x < 0:
                nums = [-y for y in nums]
            break
    return tuple(nums)


def orthogonal_completion_3d(rays: Sequence[Sequence[int]]) -> List[Tuple[int, int, int]]:
    base = [primitive_integer_ray(r) for r in rays]
    out = set(base)
    for u, v in itertools.combinations(base, 2):
        if sum(ui * vi for ui, vi in zip(u, v)) == 0:
            c = (
                u[1] * v[2] - u[2] * v[1],
                u[2] * v[0] - u[0] * v[2],
                u[0] * v[1] - u[1] * v[0],
            )
            out.add(primitive_integer_ray(c))
    return sorted(out)


fireflyL12 = [
    (1, 0, 0),
    (0, 1, 0),
    (0, 0, 1),
    (0, 1, 1),
    (0, 1, -1),
]

yuOh13 = [
    (1, 0, 0), (0, 1, 0), (0, 0, 1),
    (0, 1, 1), (0, 1, -1), (1, 0, 1), (1, 0, -1),
    (1, 1, 0), (1, -1, 0),
    (1, 1, 1), (1, 1, -1), (1, -1, 1), (-1, 1, 1),
]

yuOh25 = orthogonal_completion_3d(yuOh13)

# Tkadlec Fig. 2 nonunital: integer coordinates from the Mathematica program.
tkadlecFig2Nonunital = [
    (1, 0, 0), (0, 1, 0), (0, 0, 1),
    (1, 1, 0), (-1, 1, 0), (1, 0, 1), (1, 0, -1),
    (0, 1, 1), (0, 1, -1),
    (1, 1, 1), (-1, 1, 1), (1, -1, 1), (1, 1, -1),
    (2, 0, 1), (2, 0, -1), (1, 0, 2), (-1, 0, 2),
    (2, 1, 1), (2, -1, 1), (-2, 1, 1), (2, 1, -1),
    (1, 1, 2), (1, -1, 2), (1, 1, -2), (-1, 1, 2),
    (2, 1, 0), (2, -1, 0), (-1, 2, 0), (1, 2, 0),
    (0, 2, 1), (0, 2, -1), (0, -1, 2), (0, 1, 2),
    (1, 2, 1), (-1, 2, 1), (1, -2, 1), (1, 2, -1),
]

# Cabello--Estebaranz--Garcia-Alcaine 18/9 subset, chosen as the
# same projectors used in the earlier Mathematica program.  Signs are
# irrelevant projectively.  The previous Python draft accidentally duplicated
# (0,1,1,0) and omitted (0,1,0,0), which reduced this to 17 projectors.
cabello18 = [
    (1, 0, 0, 0),
    (0, 0, 1, -1), (0, 0, 1, 1),
    (0, 1, 0, 0), (0, 1, -1, 0),
    (0, 0, 0, 1), (0, 1, 1, 0),
    (-1, 1, 1, 1), (1, 1, 1, -1),
    (1, 0, 0, 1), (0, 1, 0, -1),
    (1, 1, -1, 1), (1, 0, 1, 0),
    (1, 1, 1, 1), (1, 0, -1, 0),
    (1, -1, 1, -1), (1, -1, 0, 0),
    (1, 1, -1, -1),
]

peresMermin24 = [
    (0, 0, 0, 1), (0, 0, -1, 1), (0, 0, 1, 0), (0, 0, 1, 1),
    (0, 1, -1, 0), (0, -1, 0, 1), (0, 1, 0, 0), (0, 1, 0, 1),
    (0, 1, 1, 0), (-1, -1, -1, 1), (1, -1, -1, 1), (-1, 1, 0, 0),
    (-1, 1, -1, 1), (1, -1, 1, 1), (-1, 0, 1, 0), (1, 0, 0, -1),
    (1, 0, 0, 0), (1, 0, 0, 1), (1, 0, 1, 0), (-1, -1, 1, 1),
    (1, 1, -1, 1), (1, 1, 0, 0), (-1, 1, 1, 1), (1, 1, 1, 1),
]


RATIONAL_VECTOR_EXAMPLES: List[Tuple[str, Sequence[Sequence[int]], int]] = [
    ("Firefly L12", fireflyL12, 3),
    ("Yu--Oh 13", yuOh13, 3),
    ("Yu--Oh 25 completion", yuOh25, 3),
    ("Tkadlec Fig. 2 nonunital", tkadlecFig2Nonunital, 3),
    ("Cabello 18/9", cabello18, 4),
    ("Peres--Mermin/Peres 24", peresMermin24, 4),
]


# ---------------------------------------------------------------------------
# Driver
# ---------------------------------------------------------------------------


def run_exact_pipeline(
    name: str,
    rays: Sequence[Sequence[int]],
    d: int,
    max_denominator: int = 10**8,
    max_dual_recovery_coeffs: int = 2500,
    allow_float_cdd: bool = False,
    certify: bool = True,
) -> Dict[str, Any]:
    print("\n" + "=" * 72, flush=True)
    print(f"TESTING {name}", flush=True)
    F = fragment_from_rays(rays, d)
    A = accessible_fragment(F)
    print(f"  projectors: states={F.VomegaF.rows}, effects={F.VxiF.rows}", flush=True)
    print(f"  full dimension={F.VomegaF.cols}, accessible dims: omega={A.VomegaA.cols}, xi={A.VxiA.cols}", flush=True)
    Homega, homega_source = cone_facets_for_audit(A.VomegaA, allow_float_cdd=allow_float_cdd)
    Hxi, hxi_source = cone_facets_for_audit(A.VxiA, allow_float_cdd=allow_float_cdd)
    print(f"  facets: H_omega={Homega.rows}, H_xi={Hxi.rows} ({homega_source}/{hxi_source})", flush=True)
    num = solve_stage3_numeric(A, Homega, Hxi)
    print(f"  numerical r = {num['r_float']:.12g}", flush=True)
    exact_facet_source = homega_source == "exact-cdd" and hxi_source == "exact-cdd"
    if certify and exact_facet_source:
        print("  certifying exact primal and dual certificates...", flush=True)
        cert = certify_from_numeric(A, Homega, Hxi, num, max_denominator=max_denominator, max_dual_recovery_coeffs=max_dual_recovery_coeffs)
        print(f"  rationalized r = {cert['r_rat']}", flush=True)
        print(f"  exact primal certificate: {cert['primal_exact_ok']}", flush=True)
        print(f"  exact dual/optimality certificate: {cert['dual_exact_ok']}", flush=True)
        if cert.get("dual_method") is not None:
            print(f"  dual method: {cert.get('dual_method')}", flush=True)
        elif cert.get("dual_recovery") is not None:
            print(f"  dual recovery status: {cert.get('dual_recovery')}", flush=True)
    else:
        r_orientation = rationalize_float(num["r_float"], max_denominator)
        reason = "float cdd facets" if not exact_facet_source else "--no-certify"
        print(f"  rationalization, for orientation only = {r_orientation}", flush=True)
        print(f"  exact certificate skipped: {reason}", flush=True)
        cert = {
            "r_rat": r_orientation,
            "primal_exact_ok": False,
            "dual_exact_ok": False,
            "exact_optimality_ok": False,
            "certificate_skipped": reason,
        }
    summary = {
        "name": name,
        "hilbert_dim": d,
        "projectors": int(F.VomegaF.rows),
        "full_dimension": int(F.VomegaF.cols),
        "state_accessible_dim": int(A.VomegaA.cols),
        "effect_accessible_dim": int(A.VxiA.cols),
        "state_facets": int(Homega.rows),
        "effect_facets": int(Hxi.rows),
        "state_facet_source": homega_source,
        "effect_facet_source": hxi_source,
        "r_float": float(num["r_float"]),
        "r_rationalized": str(cert["r_rat"]),
        "primal_exact_ok": bool(cert.get("primal_exact_ok", False)),
        "dual_exact_ok": bool(cert.get("dual_exact_ok", False)),
        "exact_optimality_ok": bool(cert.get("exact_optimality_ok", False)),
    }
    return {
        "name": name,
        "fragmentF": F,
        "fragmentA": A,
        "Homega": Homega,
        "Hxi": Hxi,
        "numeric": num,
        "certificate": cert,
        "summary": summary,
    }


def _matches_only_filter(name: str, only: Optional[Sequence[str]]) -> bool:
    if not only:
        return True
    low = name.lower()
    return any(token.lower() in low for token in only)


COMPLETED_EXACT_NAMES = {
    "Firefly L12",
    "Yu--Oh 13",
    "Yu--Oh 25 completion",
    "Tkadlec Fig. 2 nonunital",
}


def run_rational_examples(
    only: Optional[Sequence[str]] = None,
    include_completed: bool = False,
    max_dual_recovery_coeffs: int = 2500,
    allow_float_cdd: bool = False,
    certify: bool = True,
) -> Dict[str, Dict[str, Any]]:
    out = {}
    for name, rays, d in RATIONAL_VECTOR_EXAMPLES:
        if not _matches_only_filter(name, only):
            continue
        if only is None and not include_completed and name in COMPLETED_EXACT_NAMES:
            print(f"SKIPPING {name}: exact primal+dual certificate already obtained in previous run", flush=True)
            continue
        out[name] = run_exact_pipeline(
            name, rays, d,
            max_dual_recovery_coeffs=max_dual_recovery_coeffs,
            allow_float_cdd=allow_float_cdd,
            certify=certify,
        )
    return out




# ---------------------------------------------------------------------------
# Numerical/algebraic branch for configurations outside Q, notably KCBS C5
# ---------------------------------------------------------------------------


def projector_raw_float(v: Sequence[float]) -> np.ndarray:
    w = np.array(v, dtype=float)
    n = float(np.dot(w, w))
    if n == 0:
        raise ValueError("zero ray")
    d = len(w)
    out: List[float] = []
    for i in range(d):
        out.append(w[i] * w[i] / n)
    for i in range(d - 1):
        for j in range(i + 1, d):
            out.append(w[i] * w[j] / n)
    return np.array(out, dtype=float)


def trace_metric_diag_float(d: int) -> np.ndarray:
    return np.array([1.0] * d + [2.0] * (d * (d - 1) // 2), dtype=float)


def depolarizing_map_float(d: int) -> np.ndarray:
    D = raw_dim(d)
    M = np.zeros((D, D), dtype=float)
    for out_i in range(d):
        for in_j in range(d):
            M[out_i, in_j] = 1.0 / d
    return M


def fragment_from_rays_float(rays: Sequence[Sequence[float]], d_hilbert: int, tol: float = 1e-10) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    projs: List[np.ndarray] = []
    for r in rays:
        p = projector_raw_float(r)
        if not any(np.linalg.norm(p - q) < tol for q in projs):
            projs.append(p)
    states = np.vstack(projs)
    effects = np.vstack([trace_metric_diag_float(d_hilbert) * p for p in projs])
    return states, effects, depolarizing_map_float(d_hilbert)


def rowspace_basis_float(V: np.ndarray, tol: float = 1e-11) -> Tuple[np.ndarray, np.ndarray]:
    U, S, Vh = np.linalg.svd(V, full_matrices=False)
    if S.size == 0:
        raise ValueError("empty row span")
    rank = int(np.sum(S > tol * S[0]))
    B = Vh[:rank, :].T  # full coordinates = B * accessible coordinates
    VA = V @ B          # orthonormal-coordinate rows
    return B, VA


def cone_facets_numeric_from_rays(rays_rows: np.ndarray, tol: float = 1e-8) -> np.ndarray:
    """Facet enumeration for small floating-point cones.

    Returns H rows such that H.x >= 0.  This is intended only for small
    algebraic/numerical cases such as the completed pentagon.  It is not a
    replacement for exact cddlib over Q.
    """
    R = np.array(rays_rows, dtype=float)
    m, k = R.shape
    facets: List[np.ndarray] = []
    for idx in itertools.combinations(range(m), k - 1):
        M = R[list(idx), :]
        if np.linalg.matrix_rank(M, tol=1e-9) < k - 1:
            continue
        _, _, Vh = np.linalg.svd(M)
        n = Vh[-1, :]
        dots = R @ n
        if np.all(dots >= -tol) or np.all(dots <= tol):
            if np.any(dots < -tol):
                n = -n
            n = n / np.linalg.norm(n)
            # canonical sign for duplicate detection
            for x in n:
                if abs(x) > tol:
                    if x < 0:
                        n = -n
                    break
            if not any(abs(float(np.dot(n, h))) > 1 - 1e-6 for h in facets):
                # orient so all generators are nonnegative
                if np.min(R @ n) < -tol:
                    n = -n
                facets.append(n)
    if not facets:
        raise RuntimeError("No numerical cone facets found")
    return np.vstack(facets)


def solve_stage3_numeric_arrays(Iomega: np.ndarray, Ixi: np.ndarray, depF: np.ndarray, Homega: np.ndarray, Hxi: np.ndarray) -> Dict[str, Any]:
    M0 = Ixi.T @ Iomega
    M1 = Ixi.T @ (depF - np.eye(depF.shape[0])) @ Iomega
    kxi, kom = M0.shape
    coeffs = [np.outer(Hxi[a, :], Homega[b, :]) for a in range(Hxi.shape[0]) for b in range(Homega.shape[0])]
    n_sigma = len(coeffs)
    Aeq = np.zeros((kxi * kom, 1 + n_sigma), dtype=float)
    beq = M0.reshape(-1)
    Aeq[:, 0] = -M1.reshape(-1)
    for j, C in enumerate(coeffs):
        Aeq[:, 1 + j] = C.reshape(-1)
    cvec = np.zeros(1 + n_sigma, dtype=float)
    cvec[0] = 1.0
    res = linprog(cvec, A_eq=Aeq, b_eq=beq, bounds=[(0.0, 1.0)] + [(0.0, None)] * n_sigma, method="highs-ds")
    if not res.success:
        res = linprog(cvec, A_eq=Aeq, b_eq=beq, bounds=[(0.0, 1.0)] + [(0.0, None)] * n_sigma, method="highs")
    if not res.success:
        raise RuntimeError(f"Numerical LP failed: {res.message}")
    residual = Aeq @ res.x - beq
    return {
        "r_float": float(res.x[0]),
        "sigma_float": res.x[1:].reshape((Hxi.shape[0], Homega.shape[0])),
        "max_residual": float(np.max(np.abs(residual))),
        "active_sigma": int(np.sum(res.x[1:] > 1e-8)),
        "lp_result": res,
    }


def kcbs_completed_pentagon_rays_float() -> List[Tuple[float, float, float]]:
    """Five KCBS rays plus five orthogonal completers for the Greechie pentagon."""
    c = math.cos(math.pi / 5.0)
    h = math.sqrt(c)
    outer: List[np.ndarray] = []
    for k in range(5):
        theta = 4.0 * math.pi * k / 5.0
        outer.append(np.array([math.cos(theta), math.sin(theta), h], dtype=float))
    completers = [np.cross(outer[i], outer[(i + 1) % 5]) for i in range(5)]
    return [tuple(x) for x in outer + completers]


def run_pentagon_numerical() -> Dict[str, Any]:
    print("\n" + "=" * 72)
    print("TESTING completed KCBS/Greechie pentagon C5")
    print("  arithmetic: floating-point algebraic/numerical branch, not exact over Q")
    rays = kcbs_completed_pentagon_rays_float()
    VomegaF, VxiF, depF = fragment_from_rays_float(rays, 3)
    Iomega, VomegaA = rowspace_basis_float(VomegaF)
    Ixi, VxiA = rowspace_basis_float(VxiF)
    print(f"  projectors: states={VomegaF.shape[0]}, effects={VxiF.shape[0]}")
    print(f"  full dimension={VomegaF.shape[1]}, accessible dims: omega={VomegaA.shape[1]}, xi={VxiA.shape[1]}")
    Homega = cone_facets_numeric_from_rays(VomegaA)
    Hxi = cone_facets_numeric_from_rays(VxiA)
    print(f"  facets: H_omega={Homega.shape[0]}, H_xi={Hxi.shape[0]}")
    num = solve_stage3_numeric_arrays(Iomega, Ixi, depF, Homega, Hxi)
    print(f"  numerical r = {num['r_float']:.12g}")
    print(f"  rationalization, for orientation only = {rationalize_float(num['r_float'], 10**6)}")
    print(f"  max residual = {num['max_residual']:.3g}")
    print(f"  active sigma entries = {num['active_sigma']}")
    print("  exact primal certificate: False  (algebraic-field support not implemented)")
    print("  exact dual/optimality certificate: False")
    summary = {
        "name": "completed KCBS/Greechie pentagon C5",
        "hilbert_dim": 3,
        "projectors": int(VomegaF.shape[0]),
        "full_dimension": int(VomegaF.shape[1]),
        "state_accessible_dim": int(VomegaA.shape[1]),
        "effect_accessible_dim": int(VxiA.shape[1]),
        "state_facets": int(Homega.shape[0]),
        "effect_facets": int(Hxi.shape[0]),
        "state_facet_source": "numeric",
        "effect_facet_source": "numeric",
        "r_float": float(num["r_float"]),
        "r_rationalized": str(rationalize_float(num["r_float"], 10**6)),
        "max_residual": float(num["max_residual"]),
        "active_sigma": int(num["active_sigma"]),
        "primal_exact_ok": False,
        "dual_exact_ok": False,
        "exact_optimality_ok": False,
    }
    return {
        "name": "completed KCBS/Greechie pentagon C5",
        "VomegaF": VomegaF,
        "VxiF": VxiF,
        "Iomega": Iomega,
        "Ixi": Ixi,
        "VomegaA": VomegaA,
        "VxiA": VxiA,
        "Homega": Homega,
        "Hxi": Hxi,
        "numeric": num,
        "summary": summary,
    }


def run_all_examples_with_pentagon(
    only: Optional[Sequence[str]] = None,
    include_completed: bool = False,
    include_pentagon: bool = False,
    max_dual_recovery_coeffs: int = 2500,
    allow_float_cdd: bool = False,
    certify: bool = True,
) -> Dict[str, Dict[str, Any]]:
    out = run_rational_examples(
        only=only,
        include_completed=include_completed,
        max_dual_recovery_coeffs=max_dual_recovery_coeffs,
        allow_float_cdd=allow_float_cdd,
        certify=certify,
    )
    should_run_pentagon = include_pentagon or (only is not None and _matches_only_filter("completed KCBS/Greechie pentagon C5", only))
    if should_run_pentagon:
        out["completed KCBS/Greechie pentagon C5"] = run_pentagon_numerical()
    elif only is None:
        print("SKIPPING completed KCBS/Greechie pentagon C5: numerical/algebraic branch is opt-in", flush=True)
    return out


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Run projector-cone simplex-embedding diagnostics for the explicit vector sets.",
        epilog=SCRIPT_NOTE,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--list", action="store_true", help="List available named vector sets and exit.")
    parser.add_argument(
        "--only",
        action="append",
        default=None,
        help="Run only examples whose name contains this substring. May be repeated.",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Run all rows: rational vector rows plus the floating-point pentagon branch.",
    )
    parser.add_argument(
        "--include-completed",
        action="store_true",
        help="Rerun rational rows that the v9 audit had already certified.",
    )
    parser.add_argument(
        "--include-pentagon",
        action="store_true",
        help="Run the floating-point KCBS/Greechie pentagon branch.",
    )
    parser.add_argument(
        "--allow-float-cdd",
        action="store_true",
        help="If pycddlib is float-only, use numerical cdd facets and skip exact certificates.",
    )
    parser.add_argument(
        "--no-certify",
        action="store_true",
        help="Solve the numerical LP and rationalize the optimum, but skip exact certificate recovery.",
    )
    parser.add_argument(
        "--summary-json",
        default=None,
        help="Write a JSON list of compact run summaries to this path.",
    )
    parser.add_argument(
        "--max-dual-recovery-coeffs",
        type=int,
        default=2500,
        help="Maximum number of sigma coefficients for the old cdd complementary-slackness fallback.",
    )
    args = parser.parse_args()

    if args.list:
        print("Rational vector examples:")
        for name, rays, d in RATIONAL_VECTOR_EXAMPLES:
            print(f"  {name}: d={d}, rays={len(rays)}")
        print("Floating/algebraic branch:")
        print("  completed KCBS/Greechie pentagon C5: d=3, rays=10")
        raise SystemExit(0)

    if cdd is None and not (args.include_pentagon or args.all):
        raise SystemExit("pycddlib is required for the rational examples: pip install pycddlib")

    include_completed = bool(args.all or args.include_completed)
    include_pentagon = bool(args.all or args.include_pentagon)
    results = run_all_examples_with_pentagon(
        only=args.only,
        include_completed=include_completed,
        include_pentagon=include_pentagon,
        max_dual_recovery_coeffs=args.max_dual_recovery_coeffs,
        allow_float_cdd=args.allow_float_cdd,
        certify=not args.no_certify,
    )
    summaries = [result.get("summary", {"name": name}) for name, result in results.items()]
    if args.summary_json:
        with open(args.summary_json, "w", encoding="utf-8") as f:
            json.dump(summaries, f, indent=2, sort_keys=True)
            f.write("\n")
    if summaries:
        print("\nSUMMARY")
        print(json.dumps(summaries, indent=2, sort_keys=True))
