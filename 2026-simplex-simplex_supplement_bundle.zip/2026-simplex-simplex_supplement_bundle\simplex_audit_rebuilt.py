#!/usr/bin/env python3
"""Self-contained, source-driven simplex-cone audit for finite real ray systems.

The program constructs every supported ray set from cited seed data, validates the ray
geometry *before* an LP is built, and writes all inputs and outputs to one
directory.  Its default action performs validation, every projector-cone audit,
both operational closures, and the completed-pentagon audit.  Completed task
files are reused when their input fingerprints match; use --force to recompute.
No value is reported as exact unless its primal and dual certificates are
checked with exact rational arithmetic.

Supported, source-checked configurations
-----------------------------------------
* Firefly L12.
* Yu--Oh 13 rays and its 25-ray orthogonal completion.
* Tkadlec Fig. 1a: the 13-ray Specker-bug/TIFS configuration.
* Tkadlec Fig. 1b: the 25 displayed rays are orthogonally completed to the
  27-ray, 17-triad Gamma_3 nonseparating configuration.
* Tkadlec Fig. 2: the 25 marked rays are orthogonally completed to 37 rays and
  26 triads.
* Cabello--Estebaranz--Garcia-Alcaine 18--9.
* The real 24-ray completion obtained from the Peres--Mermin square.
* The algebraic completed KCBS pentagon (numerical-only audit).

Primary coordinate resources are recorded in every configuration report.
Tkadlec, Int. J. Theor. Phys. 37, 203--209 (1998), Fig. 1 supplies the
coordinate-labelled Specker-bug and Gamma_3 diagrams.  Cabello's 1996 thesis,
Fig. 2.5 and printed p. 44, gives a parametric B-11 coordinatization and its
B-13 extension.  Tkadlec Fig. 2 supplies the nonunital construction.

Dependencies for --projector/--closures:
    numpy, scipy, sympy, pycddlib with exact fraction/GMP support.

Examples
--------
    python simplex_audit_rebuilt.py --outdir audit
    python simplex_audit_rebuilt.py --validate --outdir audit
    python simplex_audit_rebuilt.py --only Gamma_3 --outdir audit
    python simplex_audit_rebuilt.py --outdir audit --force
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import platform
import sys
from collections import Counter
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple


# ---------------------------------------------------------------------------
# Exact elementary vector geometry (no hidden external data)
# ---------------------------------------------------------------------------

IntRay = Tuple[int, ...]


@dataclass(frozen=True)
class Quadratic:
    """Exact scalar a + b*sqrt(2), used for Tkadlec Fig. 1."""

    a: Fraction = Fraction(0)
    b: Fraction = Fraction(0)

    def __init__(self, a: Any = 0, b: Any = 0) -> None:
        object.__setattr__(self, "a", Fraction(a))
        object.__setattr__(self, "b", Fraction(b))

    @staticmethod
    def coerce(value: Any) -> "Quadratic":
        return value if isinstance(value, Quadratic) else Quadratic(value)

    def __add__(self, other: Any) -> "Quadratic":
        other = self.coerce(other)
        return Quadratic(self.a + other.a, self.b + other.b)

    __radd__ = __add__

    def __neg__(self) -> "Quadratic":
        return Quadratic(-self.a, -self.b)

    def __sub__(self, other: Any) -> "Quadratic":
        return self + (-self.coerce(other))

    def __rsub__(self, other: Any) -> "Quadratic":
        return self.coerce(other) - self

    def __mul__(self, other: Any) -> "Quadratic":
        other = self.coerce(other)
        return Quadratic(self.a * other.a + 2 * self.b * other.b,
                         self.a * other.b + self.b * other.a)

    __rmul__ = __mul__

    def __truediv__(self, other: Any) -> "Quadratic":
        other = self.coerce(other)
        denominator = other.a * other.a - 2 * other.b * other.b
        if denominator == 0:
            raise ZeroDivisionError("division by zero in Q(sqrt(2))")
        numerator = self * Quadratic(other.a, -other.b)
        return Quadratic(numerator.a / denominator, numerator.b / denominator)

    def __bool__(self) -> bool:
        return bool(self.a or self.b)

    def __eq__(self, other: Any) -> bool:
        try:
            other = self.coerce(other)
        except (TypeError, ValueError):
            return False
        return self.a == other.a and self.b == other.b

    def __hash__(self) -> int:
        return hash(self.a) if not self.b else hash((self.a, self.b, "sqrt(2)"))

    def __float__(self) -> float:
        return float(self.a) + float(self.b) * math.sqrt(2.0)

    def __str__(self) -> str:
        if not self.b:
            return str(self.a)
        if not self.a:
            if self.b == 1:
                return "sqrt(2)"
            if self.b == -1:
                return "-sqrt(2)"
            return f"{self.b}*sqrt(2)"
        sign = "+" if self.b > 0 else "-"
        magnitude = abs(self.b)
        radical = "sqrt(2)" if magnitude == 1 else f"{magnitude}*sqrt(2)"
        return f"{self.a}{sign}{radical}"


Ray = Tuple[Any, ...]
SQRT2 = Quadratic(0, 1)


def dot(u: Sequence[Any], v: Sequence[Any]) -> Any:
    return sum(a * b for a, b in zip(u, v))


def primitive_ray(ray: Sequence[int]) -> IntRay:
    values = [int(x) for x in ray]
    divisor = 0
    for value in values:
        divisor = math.gcd(divisor, abs(value))
    if divisor == 0:
        raise ValueError("zero vector is not a ray")
    values = [value // divisor for value in values]
    for value in values:
        if value:
            if value < 0:
                values = [-x for x in values]
            break
    return tuple(values)


def canonical_ray(ray: Sequence[Any]) -> Ray:
    if all(isinstance(value, int) for value in ray):
        return primitive_ray(ray)
    values = [Quadratic.coerce(value) for value in ray]
    pivot = next((value for value in values if value), None)
    if pivot is None:
        raise ValueError("zero vector is not a ray")
    return tuple(value / pivot for value in values)


def cross3(u: Sequence[Any], v: Sequence[Any]) -> Ray:
    return canonical_ray((
        u[1] * v[2] - u[2] * v[1],
        u[2] * v[0] - u[0] * v[2],
        u[0] * v[1] - u[1] * v[0],
    ))


def unique_rays(rays: Iterable[Sequence[Any]]) -> List[Ray]:
    seen = set()
    out: List[Ray] = []
    for ray in rays:
        key = canonical_ray(ray)
        if key not in seen:
            seen.add(key)
            out.append(key)
    return out


def orthogonal_completion_3d(seed_rays: Sequence[Sequence[Any]]) -> List[Ray]:
    """Complete every orthogonal seed pair by its unique projective cross ray."""
    seed = unique_rays(seed_rays)
    completed = set(seed)
    for u, v in itertools.combinations(seed, 2):
        if dot(u, v) == 0:
            completed.add(cross3(u, v))
    return sorted(completed, key=lambda ray: tuple(str(value) for value in ray))


def orthogonal_contexts(rays: Sequence[Ray], d: int) -> List[Tuple[int, ...]]:
    return [
        indices
        for indices in itertools.combinations(range(len(rays)), d)
        if all(dot(rays[i], rays[j]) == 0 for i, j in itertools.combinations(indices, 2))
    ]


def ray_label(ray: Sequence[Any]) -> str:
    return "(" + ",".join(str(x) for x in ray) + ")"


def serialize_scalar(value: Any) -> Any:
    if isinstance(value, Quadratic):
        return {"field": "Q(sqrt(2))", "a": str(value.a), "b": str(value.b), "expression": str(value)}
    return value


def serialize_ray(ray: Sequence[Any]) -> List[Any]:
    return [serialize_scalar(value) for value in ray]


def enumerate_two_valued_states(n_rays: int, contexts: Sequence[Tuple[int, ...]]) -> List[Tuple[int, ...]]:
    """Exact-one valuation enumerator for a finite context hypergraph.

    This is a propagating backtracker, not a floating-point or SAT-library
    calculation.  It is used only for the modest configurations below.
    """
    states: List[Tuple[int, ...]] = []

    def propagate(values: List[Optional[int]]) -> Optional[List[Optional[int]]]:
        values = values[:]
        changed = True
        while changed:
            changed = False
            for context in contexts:
                ones = [i for i in context if values[i] == 1]
                unknown = [i for i in context if values[i] is None]
                if len(ones) > 1 or (not ones and not unknown):
                    return None
                if ones:
                    for i in unknown:
                        values[i] = 0
                        changed = True
                elif len(unknown) == 1:
                    values[unknown[0]] = 1
                    changed = True
        return values

    def search(values: List[Optional[int]]) -> None:
        values = propagate(values)
        if values is None:
            return
        unresolved = [c for c in contexts if not any(values[i] == 1 for i in c)]
        if not unresolved:
            # Every vertex in the checked closed configurations occurs in a
            # context.  Any remaining free variables may be chosen as zero.
            states.append(tuple(0 if value is None else value for value in values))
            return
        context = min(unresolved, key=lambda c: sum(values[i] is None for i in c))
        for chosen in context:
            if values[chosen] is not None:
                continue
            branch = values[:]
            branch[chosen] = 1
            for index in context:
                if index != chosen:
                    branch[index] = 0
            search(branch)

    search([None] * n_rays)
    return states


# ---------------------------------------------------------------------------
# Documented vector seeds and construction rules
# ---------------------------------------------------------------------------

FIREFLY_L12: List[IntRay] = [
    (1, 0, 0), (0, 1, 0), (0, 0, 1), (0, 1, 1), (0, 1, -1),
]

YU_OH_13: List[IntRay] = [
    (1, 0, 0), (0, 1, 0), (0, 0, 1),
    (0, 1, 1), (0, 1, -1), (1, 0, 1), (1, 0, -1),
    (1, 1, 0), (1, -1, 0),
    (1, 1, 1), (1, 1, -1), (1, -1, 1), (-1, 1, 1),
]

# Tkadlec Fig. 1a, coordinate labels interpreted with
# 12(-1) = Span(1, sqrt(2), -1).  The same TIFS family is parametrized
# independently in Cabello's thesis, Fig. 2.5 (B-11) and its B-13 extension.
TKADLEC_FIG1A_SPECKER_BUG_13: List[Ray] = [
    (1, SQRT2, 1), (1, 0, -1), (-1, SQRT2, -1),
    (1, SQRT2, -1), (1, 0, 1), (-1, SQRT2, 1),
    (SQRT2, -1, 0), (SQRT2, 1, 0), (0, 1, 0),
    (-1, -SQRT2, 3), (1, SQRT2, 3),
    (-1, SQRT2, 3), (1, -SQRT2, 3),
]

# Coordinate-labelled rays displayed by Tkadlec Fig. 1b.  Orthogonal
# completion adds the two undrawn lines and produces the stated 27-line,
# 17-triad suborthoposet.
TKADLEC_FIG1B_GAMMA3_DISPLAYED: List[Ray] = [
    *TKADLEC_FIG1A_SPECKER_BUG_13,
    (0, 0, 1), (SQRT2, 1, 1), (0, 1, -1),
    (SQRT2, -1, -1), (SQRT2, 1, -1), (0, 1, 1),
    (-SQRT2, 1, -1), (SQRT2, 1, 0), (1, 0, 0),
    (SQRT2, 1, -3), (SQRT2, 1, 3),
    (SQRT2, -1, 3), (SQRT2, -1, -3),
]

# The 25 rays explicitly marked in Tkadlec's Fig. 2.  The full 37-ray
# suborthoposet must be generated by orthogonal completion of this list.
TKADLEC_FIG2_MARKED_25: List[IntRay] = [
    (1, 0, 0), (0, 1, 0), (0, 0, 1),
    (1, 1, 0), (-1, 1, 0), (1, 0, 1), (1, 0, -1),
    (0, 1, 1), (0, 1, -1),
    (1, 1, 1), (-1, 1, 1), (1, -1, 1), (1, 1, -1),
    (2, 0, 1), (2, 0, -1), (1, 0, 2), (-1, 0, 2),
    (2, 1, 1), (2, -1, 1), (-2, 1, 1), (2, 1, -1),
    (1, 1, 2), (1, -1, 2), (1, 1, -2), (-1, 1, 2),
]

CABELLO_18_9: List[IntRay] = [
    (1, 0, 0, 0),
    (0, 0, 1, -1), (0, 0, 1, 1),
    (0, 1, 0, 0), (0, 1, -1, 0),
    (0, 0, 0, 1), (0, 1, 1, 0),
    (-1, 1, 1, 1), (1, 1, 1, -1),
    (1, 0, 0, 1), (0, 1, 0, -1),
    (1, 1, -1, 1), (1, 0, 1, 0),
    (1, 1, 1, 1), (1, 0, -1, 0),
    (1, -1, 1, -1), (1, -1, 0, 0), (1, 1, -1, -1),
]

# Exact expansion of the Peres--Mermin construction below.  It permits
# --validate to run with the Python standard library alone; if sympy is
# installed, peres_mermin_24() regenerates and cross-checks this list.
PERES_MERMIN_24_FALLBACK: List[IntRay] = [
    (0, 0, 0, 1), (0, 0, -1, 1), (0, 0, 1, 0), (0, 0, 1, 1),
    (0, 1, -1, 0), (0, -1, 0, 1), (0, 1, 0, 0), (0, 1, 0, 1),
    (0, 1, 1, 0), (-1, -1, -1, 1), (1, -1, -1, 1), (-1, 1, 0, 0),
    (-1, 1, -1, 1), (1, -1, 1, 1), (-1, 0, 1, 0), (1, 0, 0, -1),
    (1, 0, 0, 0), (1, 0, 0, 1), (1, 0, 1, 0), (-1, -1, 1, 1),
    (1, 1, -1, 1), (1, 1, 0, 0), (-1, 1, 1, 1), (1, 1, 1, 1),
]


def peres_mermin_24() -> List[IntRay]:
    """Derive the 24 real rays from the six Peres--Mermin contexts.

    Each context is a commuting triple of two-qubit observables.  Simultaneous
    eigenspaces are computed exactly; the union is then projectivized.  This
    avoids importing an opaque, hand-copied 24-vector table.
    """
    try:
        import sympy as sp
    except ImportError:
        # The fallback is an exact expansion of this same construction, rather
        # than an unlabelled external data file.  Its 24-ray/24-context and KS
        # properties are still checked by validate_configuration().
        return unique_rays(PERES_MERMIN_24_FALLBACK)

    I2 = sp.eye(2)
    X = sp.Matrix([[0, 1], [1, 0]])
    Z = sp.Matrix([[1, 0], [0, -1]])
    # sigma_y tensor sigma_y is real in the computational basis.
    YY = sp.Matrix([[0, 0, 0, -1], [0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0]])
    kron = sp.kronecker_product
    square = [
        [kron(Z, I2), kron(I2, Z), kron(Z, Z)],
        [kron(I2, X), kron(X, I2), kron(X, X)],
        [kron(Z, X), kron(X, Z), YY],
    ]
    contexts = square + [[square[r][c] for r in range(3)] for c in range(3)]
    rays: List[IntRay] = []
    for context in contexts:
        A, B = context[0], context[1]
        for a, b in itertools.product((-1, 1), repeat=2):
            null = (A - a * sp.eye(4)).col_join(B - b * sp.eye(4)).nullspace()
            if len(null) != 1:
                raise RuntimeError("Peres--Mermin joint eigenspace was not one dimensional")
            vector = null[0]
            denoms = [sp.denom(x) for x in vector]
            multiple = int(sp.ilcm(*[int(x) for x in denoms]))
            rays.append(primitive_ray([int(multiple * x) for x in vector]))
    rays = unique_rays(rays)
    if len(rays) != 24:
        raise RuntimeError(f"Peres--Mermin construction produced {len(rays)}, expected 24 rays")
    if set(rays) != set(unique_rays(PERES_MERMIN_24_FALLBACK)):
        raise RuntimeError("Peres--Mermin symbolic construction disagrees with the embedded exact expansion")
    return rays


@dataclass(frozen=True)
class Configuration:
    name: str
    dimension: int
    rays: Tuple[Ray, ...]
    source: str
    construction: str
    expected_rays: int
    expected_contexts: Optional[int]
    arithmetic: str = "rational"
    valuation_check: bool = False
    expected_valuations: Optional[int] = None
    expected_never_true: Optional[int] = None
    distinguished_nonfull_pair: Optional[Tuple[Ray, Ray]] = None
    distinguished_equal_pair: Optional[Tuple[Ray, Ray]] = None


def configurations() -> List[Configuration]:
    yo25 = orthogonal_completion_3d(YU_OH_13)
    bug13 = unique_rays(TKADLEC_FIG1A_SPECKER_BUG_13)
    gamma27 = orthogonal_completion_3d(TKADLEC_FIG1B_GAMMA3_DISPLAYED)
    tk37 = orthogonal_completion_3d(TKADLEC_FIG2_MARKED_25)
    pm24 = peres_mermin_24()
    return [
        Configuration("Firefly L12", 3, tuple(unique_rays(FIREFLY_L12)),
                      "D. W. Cohen, An Introduction to Hilbert Space and Quantum Logic, Springer (1989), "
                      "DOI 10.1007/978-1-4613-8841-8",
                      "explicit five-ray firefly realization", 5, 2),
        Configuration("Yu--Oh 13", 3, tuple(unique_rays(YU_OH_13)),
                      "S. Yu and C. H. Oh, Phys. Rev. Lett. 108, 030402 (2012), "
                      "DOI 10.1103/PhysRevLett.108.030402",
                      "published 13-ray seed", 13, 4),
        Configuration("Yu--Oh 25 completion", 3, tuple(yo25),
                      "S. Yu and C. H. Oh, Phys. Rev. Lett. 108, 030402 (2012), "
                      "DOI 10.1103/PhysRevLett.108.030402",
                      "cross-product completion of every orthogonal pair in the 13-ray seed", 25, 16),
        Configuration("Tkadlec Fig. 1a Specker bug TIFS", 3, tuple(bug13),
                      "J. Tkadlec, Greechie Diagrams of Small Quantum Logics with Small State Spaces, "
                      "Int. J. Theor. Phys. 37, 203--209 (1998), Fig. 1a, DOI 10.1023/A:1026646229896; "
                      "A. Cabello Quintero, Pruebas algebraicas de imposibilidad de variables ocultas en mecanica cuantica, "
                      "PhD thesis, Universidad Complutense de Madrid (1996), Fig. 2.5 and printed p. 44",
                      "coordinate-labelled 13-line realization; Cabello supplies the parametric B-11/B-13 family",
                      13, 7, arithmetic="quadratic-rational-pairing",
                      valuation_check=True, expected_valuations=14, expected_never_true=0,
                      distinguished_nonfull_pair=((SQRT2, -1, 0), (SQRT2, 1, 0))),
        Configuration("Tkadlec Fig. 1b Gamma_3 nonseparating", 3, tuple(gamma27),
                      "J. Tkadlec, Greechie Diagrams of Small Quantum Logics with Small State Spaces, "
                      "Int. J. Theor. Phys. 37, 203--209 (1998), Fig. 1b, DOI 10.1023/A:1026646229896",
                      "orthogonal completion of the coordinate-labelled displayed rays",
                      27, 17, arithmetic="quadratic-numerical",
                      valuation_check=True, expected_valuations=24, expected_never_true=0,
                      distinguished_equal_pair=((SQRT2, -1, 0), (-1, SQRT2, 0))),
        Configuration("Tkadlec Fig. 2 nonunital", 3, tuple(tk37),
                      "J. Tkadlec, Greechie Diagrams of Small Quantum Logics with Small State Spaces, "
                      "Int. J. Theor. Phys. 37, 203--209 (1998), Fig. 2, DOI 10.1023/A:1026646229896",
                      "orthogonal completion of the 25 rays marked in Fig. 2", 37, 26,
                      valuation_check=True, expected_valuations=8, expected_never_true=8),
        Configuration("Cabello 18--9", 4, tuple(unique_rays(CABELLO_18_9)),
                      "A. Cabello, J. M. Estebaranz, and G. Garcia-Alcaine, Phys. Lett. A 212, 183--187 (1996), "
                      "DOI 10.1016/0375-9601(96)00134-X",
                      "published real 18-ray coordinatization", 18, 9,
                      valuation_check=True, expected_valuations=0, expected_never_true=18),
        Configuration("Peres--Mermin 24", 4, tuple(pm24),
                      "D. N. Mermin, Phys. Rev. Lett. 65, 3373--3377 (1990), DOI 10.1103/PhysRevLett.65.3373; "
                      "A. Peres, J. Phys. A 24, L175--L178 (1991), DOI 10.1088/0305-4470/24/4/003",
                      "exact simultaneous diagonalization of the six Peres--Mermin contexts", 24, 24,
                      valuation_check=True, expected_valuations=0, expected_never_true=24),
    ]


def completed_pentagon_rays() -> List[Tuple[float, float, float]]:
    c = math.cos(math.pi / 5.0)
    h = math.sqrt(c)
    outer = [(math.cos(4.0 * math.pi * k / 5.0), math.sin(4.0 * math.pi * k / 5.0), h) for k in range(5)]
    def cross_float(u: Sequence[float], v: Sequence[float]) -> Tuple[float, float, float]:
        return (u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0])
    return outer + [cross_float(outer[i], outer[(i + 1) % 5]) for i in range(5)]


def peres_mermin_operator_check(rays: Sequence[IntRay]) -> Dict[str, Any]:
    """Check that every embedded PM ray is a joint eigenray of one PM context."""
    def kron(a: List[List[int]], b: List[List[int]]) -> List[List[int]]:
        return [[a[i][k] * b[j][ell] for k in range(2) for ell in range(2)] for i in range(2) for j in range(2)]

    def matvec(matrix: List[List[int]], vector: IntRay) -> IntRay:
        return tuple(sum(matrix[i][j] * vector[j] for j in range(4)) for i in range(4))

    def is_eigenray(matrix: List[List[int]], vector: IntRay) -> bool:
        image = matvec(matrix, vector)
        return image == vector or image == tuple(-x for x in vector)

    ident = [[1, 0], [0, 1]]
    x = [[0, 1], [1, 0]]
    z = [[1, 0], [0, -1]]
    yy = [[0, 0, 0, -1], [0, 0, 1, 0], [0, 1, 0, 0], [-1, 0, 0, 0]]
    square = [
        [kron(z, ident), kron(ident, z), kron(z, z)],
        [kron(ident, x), kron(x, ident), kron(x, x)],
        [kron(z, x), kron(x, z), yy],
    ]
    contexts = square + [[square[row][column] for row in range(3)] for column in range(3)]
    memberships = [sum(all(is_eigenray(operator, ray) for operator in context) for context in contexts) for ray in rays]
    return {"joint_eigencontext_memberships": memberships, "all_rays_in_exactly_one_PM_context": all(count == 1 for count in memberships)}


# ---------------------------------------------------------------------------
# Geometry report: always emitted before an LP is attempted
# ---------------------------------------------------------------------------

def validate_configuration(config: Configuration) -> Dict[str, Any]:
    rays = list(config.rays)
    contexts = orthogonal_contexts(rays, config.dimension)
    duplicate_free = len(unique_rays(rays)) == len(rays)
    context_degrees = Counter(index for context in contexts for index in context)
    result: Dict[str, Any] = {
        "name": config.name,
        "dimension": config.dimension,
        "source": config.source,
        "construction": config.construction,
        "arithmetic": config.arithmetic,
        "rays": [serialize_ray(ray) for ray in rays],
        "ray_labels": [ray_label(ray) for ray in rays],
        "contexts": [list(context) for context in contexts],
        "context_rays": [[serialize_ray(rays[i]) for i in context] for context in contexts],
        "projectively_unique": duplicate_free,
        "ray_count": len(rays),
        "expected_ray_count": config.expected_rays,
        "context_count": len(contexts),
        "expected_context_count": config.expected_contexts,
        "context_degree_histogram": dict(sorted(Counter(context_degrees.values()).items())),
        "all_contexts_orthonormal": all(
            all(dot(rays[i], rays[j]) == 0 for i, j in itertools.combinations(context, 2))
            for context in contexts
        ),
    }
    if config.valuation_check:
        valuations = enumerate_two_valued_states(len(rays), contexts)
        never_true = [i for i in range(len(rays)) if not any(state[i] for state in valuations)]
        result.update({
            "two_valued_state_count": len(valuations),
            "two_valued_states": [list(state) for state in valuations],
            "never_true_indices": never_true,
            "never_true_rays": [serialize_ray(rays[i]) for i in never_true],
            "expected_two_valued_state_count": config.expected_valuations,
            "expected_never_true_count": config.expected_never_true,
        })
        if config.distinguished_nonfull_pair is not None:
            left = rays.index(canonical_ray(config.distinguished_nonfull_pair[0]))
            right = rays.index(canonical_ray(config.distinguished_nonfull_pair[1]))
            result["distinguished_nonfull_check"] = {
                "indices": [left, right],
                "rays": [serialize_ray(rays[left]), serialize_ray(rays[right])],
                "nonorthogonal": dot(rays[left], rays[right]) != 0,
                "no_valuation_assigns_both_one": not any(state[left] and state[right] for state in valuations),
            }
        if config.distinguished_equal_pair is not None:
            left = rays.index(canonical_ray(config.distinguished_equal_pair[0]))
            right = rays.index(canonical_ray(config.distinguished_equal_pair[1]))
            result["distinguished_nonseparating_check"] = {
                "indices": [left, right],
                "rays": [serialize_ray(rays[left]), serialize_ray(rays[right])],
                "distinct": left != right,
                "equal_in_every_valuation": all(state[left] == state[right] for state in valuations),
            }
    if config.name == "Peres--Mermin 24":
        result["operator_origin_check"] = peres_mermin_operator_check(rays)
    result["validation_passed"] = (
        duplicate_free
        and len(rays) == config.expected_rays
        and (config.expected_contexts is None or len(contexts) == config.expected_contexts)
        and result["all_contexts_orthonormal"]
        and (not config.valuation_check or len(result["two_valued_states"]) == config.expected_valuations)
        and (not config.valuation_check or len(result["never_true_indices"]) == config.expected_never_true)
        and (config.distinguished_nonfull_pair is None
             or (result["distinguished_nonfull_check"]["nonorthogonal"]
                 and result["distinguished_nonfull_check"]["no_valuation_assigns_both_one"]))
        and (config.distinguished_equal_pair is None
             or (result["distinguished_nonseparating_check"]["distinct"]
                 and result["distinguished_nonseparating_check"]["equal_in_every_valuation"]))
        and (config.name != "Peres--Mermin 24" or result["operator_origin_check"]["all_rays_in_exactly_one_PM_context"])
    )
    return result


# ---------------------------------------------------------------------------
# Exact rational projector-cone calculation
# ---------------------------------------------------------------------------

def require_audit_dependencies() -> Tuple[Any, Any, Any, Any, Any, Any]:
    try:
        import numpy as np
        import sympy as sp
        from scipy.optimize import linprog
        from scipy.spatial import ConvexHull
        import cdd
    except ImportError as exc:
        raise RuntimeError(
            "Audit mode requires numpy, scipy, sympy, and pycddlib. "
            "Validation mode needs only sympy for the Peres--Mermin construction."
        ) from exc
    return np, sp, linprog, ConvexHull, cdd, Fraction


def Q(value: Any, sp: Any) -> Any:
    if isinstance(value, Fraction):
        return sp.Rational(value.numerator, value.denominator)
    if isinstance(value, Quadratic):
        return (sp.Rational(value.a.numerator, value.a.denominator)
                + sp.Rational(value.b.numerator, value.b.denominator) * sp.sqrt(2))
    if hasattr(value, "is_Rational"):
        return value
    return sp.Rational(value)


def raw_dimension(d: int) -> int:
    return d * (d + 1) // 2


def raw_projector(ray: Sequence[Any], sp: Any) -> List[Any]:
    vector = [Q(x, sp) for x in ray]
    norm = sum(x * x for x in vector)
    out = [x * x / norm for x in vector]
    out.extend(vector[i] * vector[j] / norm for i in range(len(vector) - 1) for j in range(i + 1, len(vector)))
    return [sp.factor(x) for x in out]


def trace_metric(d: int, sp: Any) -> List[Any]:
    return [sp.Rational(1)] * d + [sp.Rational(2)] * (d * (d - 1) // 2)


def dual_effect(raw: Sequence[Any], d: int, sp: Any) -> List[Any]:
    return [sp.factor(g * x) for g, x in zip(trace_metric(d, sp), raw)]


def depolarizing_map(d: int, sp: Any) -> Any:
    size = raw_dimension(d)
    matrix = sp.zeros(size, size)
    for out_index in range(d):
        for in_index in range(d):
            matrix[out_index, in_index] = sp.Rational(1, d)
    return matrix


@dataclass
class AccessibleFragment:
    state_generators: Any
    effect_generators: Any
    state_basis: Any
    effect_basis: Any
    state_coordinates: Any
    effect_coordinates: Any
    depolarizing: Any
    d: int


def column_basis_for_row_span(matrix: Any) -> Any:
    columns = matrix.T.columnspace()
    if not columns:
        raise ValueError("empty generator list")
    return matrix.__class__.hstack(*columns)


def coordinates_in_basis(rows: Any, basis: Any, sp: Any) -> Any:
    coordinates = []
    for i in range(rows.rows):
        solution = basis.gauss_jordan_solve(rows.row(i).T)[0]
        coordinates.append(list(solution))
    return sp.Matrix(coordinates)


def accessible_fragment(state_rows: Sequence[Sequence[Any]], effect_rows: Sequence[Sequence[Any]], d: int, sp: Any) -> AccessibleFragment:
    states = sp.Matrix(state_rows)
    effects = sp.Matrix(effect_rows)
    state_basis = column_basis_for_row_span(states)
    effect_basis = column_basis_for_row_span(effects)
    return AccessibleFragment(
        state_generators=states,
        effect_generators=effects,
        state_basis=state_basis,
        effect_basis=effect_basis,
        state_coordinates=coordinates_in_basis(states, state_basis, sp),
        effect_coordinates=coordinates_in_basis(effects, effect_basis, sp),
        depolarizing=depolarizing_map(d, sp),
        d=d,
    )


def raw_trace(row: Sequence[Any], d: int, sp: Any) -> Any:
    return sp.factor(sum(row[:d]))


def born_pairing_matrix(effect_rows_raw: Sequence[Sequence[Any]], state_rows_raw: Sequence[Sequence[Any]], d: int, sp: Any) -> Any:
    metric = trace_metric(d, sp)
    return sp.Matrix([
        [sp.factor(sum(metric[k] * effect[k] * state[k] for k in range(len(metric))))
         for state in state_rows_raw]
        for effect in effect_rows_raw
    ])


@dataclass
class PairingFragment:
    state_coordinates: Any
    effect_coordinates: Any
    depolarizing: Any
    pairing: Any
    state_normalizations: Any
    effect_traces: Any
    d: int


def exact_pairing_fragment(state_rows_raw: Sequence[Sequence[Any]], effect_rows_raw: Sequence[Sequence[Any]], d: int, sp: Any) -> PairingFragment:
    """Build rational operational coordinates from an exact Born table.

    This directly quotients operational null directions.  It also permits the
    Specker-bug coordinates in Q(sqrt(2)) to be audited exactly because their
    complete Born table is rational.
    """
    pairing = born_pairing_matrix(effect_rows_raw, state_rows_raw, d, sp)
    nonrational = [value for value in pairing if value.is_Rational is not True]
    if nonrational:
        raise ValueError("Born table is not rational; use the numerical algebraic branch")
    _, pivot_columns = pairing.rref()
    effect_coordinates = sp.Matrix.hstack(*[pairing[:, column] for column in pivot_columns])
    state_columns = []
    for column in range(pairing.cols):
        state_columns.append(effect_coordinates.gauss_jordan_solve(pairing[:, column])[0])
    state_coordinates = sp.Matrix.hstack(*state_columns).T
    if effect_coordinates * state_coordinates.T != pairing:
        raise RuntimeError("rational rank factorization failed")
    state_normalizations = sp.Matrix([raw_trace(row, d, sp) for row in state_rows_raw])
    effect_traces = sp.Matrix([raw_trace(row, d, sp) for row in effect_rows_raw])
    normalization_functional = state_coordinates.gauss_jordan_solve(state_normalizations)[0]
    mixed_state = effect_coordinates.gauss_jordan_solve(effect_traces / d)[0]
    depolarizing = sp.factor(mixed_state * normalization_functional.T)
    return PairingFragment(state_coordinates, effect_coordinates, depolarizing, pairing,
                           state_normalizations, effect_traces, d)


def cdd_rows(matrix: Any, sp: Any) -> Any:
    if hasattr(matrix, "array"):
        return sp.Matrix([[Q(x, sp) for x in row] for row in matrix.array])
    return sp.Matrix([[Q(str(matrix[i][j]), sp) for j in range(matrix.col_size)] for i in range(matrix.row_size)])


def exact_cdd_matrix(rows: Sequence[Sequence[Any]], rep_type: Any, cdd: Any, sp: Any) -> Any:
    fraction_rows = [[Fraction(int(Q(x, sp).p), int(Q(x, sp).q)) for x in row] for row in rows]
    try:
        matrix = cdd.Matrix(fraction_rows, number_type="fraction")
        matrix.rep_type = rep_type
        return matrix
    except TypeError:
        pass
    if hasattr(cdd, "matrix_from_array"):
        if getattr(cdd, "NumberType", None) is float:
            raise RuntimeError("pycddlib is float-only; exact rational facet enumeration is unavailable")
        return cdd.matrix_from_array(fraction_rows, rep_type=rep_type)
    raise RuntimeError("unsupported pycddlib API")


def cdd_polyhedron(matrix: Any, cdd: Any) -> Any:
    if hasattr(cdd, "polyhedron_from_matrix"):
        return cdd.polyhedron_from_matrix(matrix)
    return cdd.Polyhedron(matrix)


def cdd_inequalities(polyhedron: Any, cdd: Any) -> Any:
    if hasattr(cdd, "copy_inequalities"):
        return cdd.copy_inequalities(polyhedron)
    return polyhedron.get_inequalities()


def cone_facets(generator_rows: Any, cdd: Any, sp: Any) -> Any:
    rows = [[Fraction(0)] + [Fraction(int(generator_rows[i, j].p), int(generator_rows[i, j].q)) for j in range(generator_rows.cols)] for i in range(generator_rows.rows)]
    matrix = exact_cdd_matrix(rows, cdd.RepType.GENERATOR, cdd, sp)
    inequalities = cdd_rows(cdd_inequalities(cdd_polyhedron(matrix, cdd), cdd), sp)
    facets = [list(inequalities.row(i))[1:] for i in range(inequalities.rows) if inequalities[i, 0] == 0]
    if not facets:
        raise RuntimeError("cddlib returned no homogeneous cone facets")
    return sp.Matrix(facets)


def stage_matrices(fragment: AccessibleFragment, sp: Any) -> Tuple[Any, Any]:
    full_dimension = fragment.depolarizing.rows
    m0 = fragment.effect_basis.T * fragment.state_basis
    m1 = fragment.effect_basis.T * (fragment.depolarizing - sp.eye(full_dimension)) * fragment.state_basis
    return sp.factor(m0), sp.factor(m1)


def solve_primal_lp(m0: Any, m1: Any, state_facets: Any, effect_facets: Any, np: Any, linprog: Any) -> Dict[str, Any]:
    rows, cols = m0.rows, m0.cols
    n_sigma = state_facets.rows * effect_facets.rows
    Aeq = np.zeros((rows * cols, 1 + n_sigma), dtype=float)
    Aeq[:, 0] = -np.array(m1.reshape(rows * cols, 1), dtype=float).reshape(-1)
    e = np.array(effect_facets.tolist(), dtype=float)
    s = np.array(state_facets.tolist(), dtype=float)
    Aeq[:, 1:] = (e[:, None, :, None] * s[None, :, None, :]).reshape(n_sigma, rows * cols).T
    b = np.array(m0.reshape(rows * cols, 1), dtype=float).reshape(-1)
    objective = np.zeros(1 + n_sigma)
    objective[0] = 1.0
    result = linprog(objective, A_eq=Aeq, b_eq=b, bounds=[(0.0, 1.0)] + [(0.0, None)] * n_sigma, method="highs-ds")
    if not result.success:
        result = linprog(objective, A_eq=Aeq, b_eq=b, bounds=[(0.0, 1.0)] + [(0.0, None)] * n_sigma, method="highs")
    if not result.success:
        raise RuntimeError(f"primal LP failed: {result.message}")
    return {
        "r_float": float(result.x[0]),
        "sigma_float": result.x[1:].reshape((effect_facets.rows, state_facets.rows)),
        "Aeq": Aeq,
        "b": b,
        "objective": objective,
        "residual": float(np.max(np.abs(Aeq @ result.x - b))),
    }


def rationalize(value: float, sp: Any, maximum_denominator: int = 10**8) -> Any:
    fraction = Fraction(float(value)).limit_denominator(maximum_denominator)
    return sp.Rational(fraction.numerator, fraction.denominator)


def rationalize_matrix(values: Any, sp: Any, maximum_denominator: int = 10**8, zero_tolerance: float = 1e-10) -> Any:
    return sp.Matrix([[sp.Rational(0) if abs(float(x)) <= zero_tolerance else rationalize(float(x), sp, maximum_denominator) for x in row] for row in values])


def exact_primal_check(m0: Any, m1: Any, state_facets: Any, effect_facets: Any, r: Any, sigma: Any, sp: Any) -> Tuple[bool, Any]:
    residual = sp.simplify(effect_facets.T * sigma * state_facets - (m0 + r * m1))
    okay = r >= 0 and r <= 1 and all(value >= 0 for value in sigma) and residual == sp.zeros(residual.rows, residual.cols)
    return bool(okay), residual


def exact_dual_check(m0: Any, m1: Any, state_facets: Any, effect_facets: Any, y: Any, r: Any, sp: Any) -> bool:
    vector0 = list(m0.reshape(m0.rows * m0.cols, 1))
    vector1 = list(m1.reshape(m1.rows * m1.cols, 1))
    entries = list(y)
    if sum(a * b for a, b in zip(vector0, entries)) != r:
        return False
    if -sum(a * b for a, b in zip(vector1, entries)) > 1:
        return False
    for effect_row in range(effect_facets.rows):
        for state_row in range(state_facets.rows):
            coefficient = effect_facets.row(effect_row).T * state_facets.row(state_row)
            if sum(a * b for a, b in zip(list(coefficient.reshape(coefficient.rows * coefficient.cols, 1)), entries)) > 0:
                return False
    return True


def recover_exact_dual_from_active_set(m0: Any, m1: Any, state_facets: Any, effect_facets: Any, y_float: Any, r: Any, np: Any, sp: Any) -> Optional[Any]:
    """Propose an exact dual from active numerical inequalities, then verify all.

    Numerical activity is used only to select equations.  Acceptance is solely
    by exact_dual_check against every facet-pair inequality.
    """
    n_y = m0.rows * m0.cols
    b_exact = list(m0.reshape(n_y, 1))
    m1_exact = list(m1.reshape(n_y, 1))
    b_float = np.asarray([float(x) for x in b_exact])
    m1_float = np.asarray([float(x) for x in m1_exact])
    Y = np.asarray(y_float, dtype=float).reshape((m0.rows, m0.cols))
    E_float = np.asarray(effect_facets.tolist(), dtype=float)
    S_float = np.asarray(state_facets.tolist(), dtype=float)
    slacks = E_float @ Y @ S_float.T

    def select(candidates: List[Tuple[List[Any], Any, Any]], target_rank: int) -> Tuple[List[List[Any]], List[Any], int]:
        exact_rows: List[List[Any]] = []
        rhs: List[Any] = []
        floats: List[Any] = []
        rank = 0
        for exact_row, value, float_row in candidates:
            trial = np.vstack(floats + [float_row])
            new_rank = int(np.linalg.matrix_rank(trial, tol=1e-10))
            if new_rank > rank:
                exact_rows.append(exact_row)
                rhs.append(value)
                floats.append(float_row)
                rank = new_rank
                if rank == target_rank:
                    break
        return exact_rows, rhs, rank

    base: List[Tuple[List[Any], Any, Any]] = [(b_exact, sp.Rational(r), b_float)]
    if r > 0:
        base.append(([-x for x in m1_exact], sp.Rational(1), -m1_float))
    order = np.argsort(np.abs(slacks), axis=None)
    for tolerance in (1e-10, 1e-9, 1e-8, 1e-7, 1e-6, 1e-5, 1e-4):
        candidates = list(base)
        limit = 12 * n_y
        included = 0
        for flat_index in order:
            i, j = np.unravel_index(int(flat_index), slacks.shape)
            if abs(float(slacks[i, j])) > tolerance or included >= limit:
                break
            exact_matrix = effect_facets.row(i).T * state_facets.row(j)
            exact_row = list(exact_matrix.reshape(n_y, 1))
            candidates.append((exact_row, sp.Rational(0), np.outer(E_float[i], S_float[j]).reshape(-1)))
            included += 1
        rows, rhs, rank = select(candidates, n_y)
        if rank != n_y:
            continue
        try:
            solution = sp.Matrix(rows).LUsolve(sp.Matrix(rhs))
        except Exception:
            continue
        solution = sp.Matrix([sp.factor(x) for x in solution])
        if exact_dual_check(m0, m1, state_facets, effect_facets, solution, r, sp):
            return solution
    return None


def attempt_certificate(m0: Any, m1: Any, state_facets: Any, effect_facets: Any, numeric: Dict[str, Any], np: Any, linprog: Any, sp: Any) -> Dict[str, Any]:
    r = rationalize(numeric["r_float"], sp)
    sigma = rationalize_matrix(numeric["sigma_float"], sp)
    primal_ok, primal_residual = exact_primal_check(m0, m1, state_facets, effect_facets, r, sigma, sp)
    # A direct rationalization of the numerical dual is intentionally the only
    # route here.  If it does not verify, the result remains numerical rather
    # than being upgraded through an opaque heuristic recovery.
    dual_ok = False
    y_rational = None
    dual_method = None
    try:
        dual = linprog(-numeric["b"], A_ub=numeric["Aeq"].T, b_ub=numeric["objective"], bounds=[(None, None)] * len(numeric["b"]), method="highs-ds")
        if dual.success:
            y_rational = sp.Matrix([rationalize(value, sp) for value in dual.x])
            dual_ok = exact_dual_check(m0, m1, state_facets, effect_facets, y_rational, r, sp)
            dual_method = "entrywise rationalization" if dual_ok else None
            if primal_ok and not dual_ok:
                y_rational = recover_exact_dual_from_active_set(m0, m1, state_facets, effect_facets, dual.x, r, np, sp)
                dual_ok = y_rational is not None
                dual_method = "active-set exact solve with full exact verification" if dual_ok else None
    except Exception:
        pass
    return {
        "r_rational": str(r),
        "primal_exact": primal_ok,
        "dual_exact": dual_ok,
        "dual_method": dual_method,
        "exact_optimum": bool(primal_ok and dual_ok),
        "primal_residual": matrix_strings(primal_residual),
        "sigma": matrix_strings(sigma) if primal_ok else None,
        "dual_y": vector_strings(y_rational) if dual_ok else None,
    }


def matrix_strings(matrix: Any) -> List[List[str]]:
    return [[str(matrix[i, j]) for j in range(matrix.cols)] for i in range(matrix.rows)]


def vector_strings(vector: Any) -> Optional[List[str]]:
    if vector is None:
        return None
    return [str(value) for value in vector]


def projector_audit(config: Configuration, output: Path, np: Any, sp: Any, linprog: Any, cdd: Any) -> Dict[str, Any]:
    state_rows = [raw_projector(ray, sp) for ray in config.rays]
    effect_rows = [dual_effect(row, config.dimension, sp) for row in state_rows]
    fragment = accessible_fragment(state_rows, effect_rows, config.dimension, sp)
    state_facets = cone_facets(fragment.state_coordinates, cdd, sp)
    effect_facets = cone_facets(fragment.effect_coordinates, cdd, sp)
    m0, m1 = stage_matrices(fragment, sp)
    numeric = solve_primal_lp(m0, m1, state_facets, effect_facets, np, linprog)
    certificate = attempt_certificate(m0, m1, state_facets, effect_facets, numeric, np, linprog, sp)
    report = {
        "name": config.name,
        "kind": "projector-cone",
        "source": config.source,
        "construction": config.construction,
        "arithmetic": config.arithmetic,
        "coordinate_convention": "states use raw symmetric coordinates; effects use dual coordinates G e, so the pairing is I_E^T I_Omega.",
        "state_generators": matrix_strings(fragment.state_generators),
        "effect_generators_dual": matrix_strings(fragment.effect_generators),
        "state_basis": matrix_strings(fragment.state_basis),
        "effect_basis_dual": matrix_strings(fragment.effect_basis),
        "state_facets": matrix_strings(state_facets),
        "effect_facets": matrix_strings(effect_facets),
        "m0": matrix_strings(m0),
        "m1": matrix_strings(m1),
        "state_accessible_dimension": fragment.state_coordinates.cols,
        "effect_accessible_dimension": fragment.effect_coordinates.cols,
        "state_facet_count": state_facets.rows,
        "effect_facet_count": effect_facets.rows,
        "r_float": numeric["r_float"],
        "lp_residual": numeric["residual"],
        "sigma_float": numeric["sigma_float"].tolist(),
        "certificate": certificate,
    }
    write_json(output / "projector" / safe_name(config.name) / "audit.json", report)
    return report


def exact_pairing_projector_audit(config: Configuration, output: Path, np: Any, sp: Any, linprog: Any, cdd: Any) -> Dict[str, Any]:
    state_rows = [raw_projector(ray, sp) for ray in config.rays]
    fragment = exact_pairing_fragment(state_rows, state_rows, config.dimension, sp)
    state_facets = cone_facets(fragment.state_coordinates, cdd, sp)
    effect_facets = cone_facets(fragment.effect_coordinates, cdd, sp)
    size = fragment.pairing.rank()
    m0 = sp.eye(size)
    m1 = sp.factor(fragment.depolarizing - m0)
    numeric = solve_primal_lp(m0, m1, state_facets, effect_facets, np, linprog)
    certificate = attempt_certificate(m0, m1, state_facets, effect_facets, numeric, np, linprog, sp)
    report = {
        "name": config.name,
        "kind": "projector-cone",
        "source": config.source,
        "construction": config.construction,
        "arithmetic": config.arithmetic,
        "coordinate_convention": "exact rational rank factorization of the source-derived Born table",
        "rays": [serialize_ray(ray) for ray in config.rays],
        "state_generators_raw": matrix_strings(sp.Matrix(state_rows)),
        "born_pairing": matrix_strings(fragment.pairing),
        "state_coordinates": matrix_strings(fragment.state_coordinates),
        "effect_coordinates": matrix_strings(fragment.effect_coordinates),
        "depolarizing": matrix_strings(fragment.depolarizing),
        "state_facets": matrix_strings(state_facets),
        "effect_facets": matrix_strings(effect_facets),
        "m0": matrix_strings(m0),
        "m1": matrix_strings(m1),
        "state_accessible_dimension": fragment.state_coordinates.cols,
        "effect_accessible_dimension": fragment.effect_coordinates.cols,
        "state_facet_count": state_facets.rows,
        "effect_facet_count": effect_facets.rows,
        "r_float": numeric["r_float"],
        "lp_residual": numeric["residual"],
        "sigma_float": numeric["sigma_float"].tolist(),
        "certificate": certificate,
    }
    write_json(output / "projector" / safe_name(config.name) / "audit.json", report)
    return report


# ---------------------------------------------------------------------------
# Optional vector-generated operational closure
# ---------------------------------------------------------------------------

def add_rows(rows: Iterable[Sequence[Any]], sp: Any) -> List[Any]:
    rows = [list(row) for row in rows]
    return [sp.factor(sum(row[i] for row in rows)) for i in range(len(rows[0]))]


def raw_identity(d: int, sp: Any) -> List[Any]:
    return [sp.Rational(1)] * d + [sp.Rational(0)] * (d * (d - 1) // 2)


def deduplicate_rows(rows: Iterable[Sequence[Any]]) -> List[List[Any]]:
    seen = set()
    out = []
    for row in rows:
        item = list(row)
        key = tuple(item)
        if key not in seen:
            seen.add(key)
            out.append(item)
    return out


def all_orthogonal_subsets(rays: Sequence[Ray], d: int) -> List[Tuple[int, ...]]:
    return [subset for size in range(1, d + 1) for subset in itertools.combinations(range(len(rays)), size) if all(dot(rays[i], rays[j]) == 0 for i, j in itertools.combinations(subset, 2))]


def closure_fragment(config: Configuration, variant: str, sp: Any) -> Tuple[List[List[Any]], List[List[Any]], Dict[str, Any]]:
    projectors = [raw_projector(ray, sp) for ray in config.rays]
    identity = raw_identity(config.dimension, sp)
    effect_labels: List[List[Any]] = list(projectors) + [identity]
    subsets = all_orthogonal_subsets(config.rays, config.dimension)
    for subset in subsets:
        outcomes = [projectors[i] for i in subset]
        residual = [sp.factor(identity[i] - sum(row[i] for row in outcomes)) for i in range(len(identity))]
        if any(value != 0 for value in residual):
            outcomes.append(residual)
        for size in range(1, len(outcomes)):
            for chosen in itertools.combinations(outcomes, size):
                effect_labels.append(add_rows(chosen, sp))
    effects_raw = deduplicate_rows(effect_labels)
    states_raw: List[List[Any]] = list(projectors) + [[sp.Rational(1, config.dimension) if i < config.dimension else sp.Rational(0) for i in range(len(identity))]]
    if variant == "effects-and-preps":
        for effect in effects_raw:
            trace = sum(effect[:config.dimension])
            if trace:
                states_raw.append([sp.factor(value / trace) for value in effect])
    states_raw = deduplicate_rows(states_raw)
    return states_raw, effects_raw, {
        "variant": variant,
        "orthogonal_subsets": len(subsets),
        "effect_generators": len(effects_raw),
        "state_generators": len(states_raw),
    }


def solve_dual_cutting(m0: Any, m1: Any, state_facets: Any, effect_facets: Any, np: Any, linprog: Any, tolerance: float = 1e-9) -> Dict[str, Any]:
    if hasattr(m0, "rows"):
        rows, cols = m0.rows, m0.cols
        b = np.array(m0.reshape(rows * cols, 1), dtype=float).reshape(-1)
        m1v = np.array(m1.reshape(rows * cols, 1), dtype=float).reshape(-1)
    else:
        rows, cols = m0.shape
        b = np.asarray(m0, dtype=float).reshape(-1)
        m1v = np.asarray(m1, dtype=float).reshape(-1)
    E = np.asarray(effect_facets.tolist() if hasattr(effect_facets, "tolist") else effect_facets, dtype=float)
    S = np.asarray(state_facets.tolist() if hasattr(state_facets, "tolist") else state_facets, dtype=float)
    def evenly_spaced(count: int, requested: int) -> List[int]:
        if requested >= count:
            return list(range(count))
        if requested <= 1:
            return [0]
        return sorted({round(i * (count - 1) / (requested - 1)) for i in range(requested)})

    initial = 12
    active = {
        (i, j)
        for i in evenly_spaced(E.shape[0], min(initial, E.shape[0]))
        for j in evenly_spaced(S.shape[0], min(initial, S.shape[0]))
    }
    for i in range(min(E.shape[0], S.shape[0])):
        active.add((i, i))
    for iteration in range(1, 81):
        inequalities = np.empty((1 + len(active), rows * cols))
        bounds = np.zeros(1 + len(active))
        inequalities[0] = -m1v
        bounds[0] = 1.0
        for target, (i, j) in enumerate(sorted(active), 1):
            inequalities[target] = np.outer(E[i], S[j]).reshape(-1)
        result = linprog(-b, A_ub=inequalities, b_ub=bounds, bounds=[(None, None)] * (rows * cols), method="highs-ds")
        if not result.success:
            # A restricted dual is often unbounded before enough facet-pair
            # inequalities have been activated.  This is an expected cutting-
            # plane state, not evidence that the full dual is unbounded.
            grow = min(initial * (2 ** iteration), max(E.shape[0], S.shape[0]))
            before = len(active)
            for i in evenly_spaced(E.shape[0], min(grow, E.shape[0])):
                for j in evenly_spaced(S.shape[0], min(grow, S.shape[0])):
                    active.add((i, j))
            if len(active) == before:
                raise RuntimeError(
                    f"cutting dual remained {result.message.lower()} after all deterministic seed constraints were added"
                )
            continue
        y = result.x.reshape((rows, cols))
        violations = E @ y @ S.T
        maximum = float(violations.max())
        if maximum <= tolerance:
            return {"r_float": -float(result.fun), "dual_y_float": result.x.tolist(), "iterations": iteration, "max_dual_violation": maximum, "active_constraints": len(active)}
        flat = violations.reshape(-1)
        for index in np.argpartition(flat, -min(512, flat.size))[-min(512, flat.size):]:
            if flat[index] > tolerance:
                active.add((int(index // S.shape[0]), int(index % S.shape[0])))
    raise RuntimeError("cutting dual did not reach its requested tolerance")


def closure_audit(config: Configuration, variant: str, output: Path, np: Any, sp: Any, linprog: Any, cdd: Any) -> Dict[str, Any]:
    states_raw, effects_raw, metadata = closure_fragment(config, variant, sp)
    effects_dual = [dual_effect(effect, config.dimension, sp) for effect in effects_raw]
    fragment = accessible_fragment(states_raw, effects_dual, config.dimension, sp)
    state_facets = cone_facets(fragment.state_coordinates, cdd, sp)
    effect_facets = cone_facets(fragment.effect_coordinates, cdd, sp)
    m0, m1 = stage_matrices(fragment, sp)
    facet_product = state_facets.rows * effect_facets.rows
    if facet_product <= 50000:
        numeric = solve_primal_lp(m0, m1, state_facets, effect_facets, np, linprog)
        solver = "primal"
        residual = numeric["residual"]
    else:
        numeric = solve_dual_cutting(m0, m1, state_facets, effect_facets, np, linprog)
        solver = "cutting-dual"
        residual = numeric["max_dual_violation"]
    report = {
        "name": config.name,
        "kind": "vector-generated closure",
        "source": config.source,
        "construction": config.construction,
        "arithmetic": config.arithmetic,
        **metadata,
        "solver": solver,
        "state_accessible_dimension": fragment.state_coordinates.cols,
        "effect_accessible_dimension": fragment.effect_coordinates.cols,
        "state_generators_raw": matrix_strings(fragment.state_generators),
        "effect_generators_dual": matrix_strings(fragment.effect_generators),
        "state_basis": matrix_strings(fragment.state_basis),
        "effect_basis_dual": matrix_strings(fragment.effect_basis),
        "state_facets": matrix_strings(state_facets),
        "effect_facets": matrix_strings(effect_facets),
        "m0": matrix_strings(m0),
        "m1": matrix_strings(m1),
        "state_facet_count": state_facets.rows,
        "effect_facet_count": effect_facets.rows,
        "facet_product": facet_product,
        "r_float": numeric["r_float"],
        "numerical_residual_or_dual_violation": residual,
        "sigma_float": numeric.get("sigma_float").tolist() if numeric.get("sigma_float") is not None else None,
        "dual_y_float": numeric.get("dual_y_float"),
        "certificate_status": "numerical only; no exact claim is made for closure rows",
    }
    write_json(output / "closures" / safe_name(config.name) / f"{variant}.json", report)
    return report


def exact_pairing_closure_audit(config: Configuration, variant: str, output: Path, np: Any, sp: Any, linprog: Any, cdd: Any) -> Dict[str, Any]:
    states_raw, effects_raw, metadata = closure_fragment(config, variant, sp)
    fragment = exact_pairing_fragment(states_raw, effects_raw, config.dimension, sp)
    state_facets = cone_facets(fragment.state_coordinates, cdd, sp)
    effect_facets = cone_facets(fragment.effect_coordinates, cdd, sp)
    size = fragment.pairing.rank()
    m0 = sp.eye(size)
    m1 = sp.factor(fragment.depolarizing - m0)
    facet_product = state_facets.rows * effect_facets.rows
    if facet_product <= 50000:
        numeric = solve_primal_lp(m0, m1, state_facets, effect_facets, np, linprog)
        solver = "primal"
        residual = numeric["residual"]
    else:
        numeric = solve_dual_cutting(m0, m1, state_facets, effect_facets, np, linprog)
        solver = "cutting-dual"
        residual = numeric["max_dual_violation"]
    report = {
        "name": config.name,
        "kind": "vector-generated closure",
        "source": config.source,
        "construction": config.construction,
        "arithmetic": config.arithmetic,
        **metadata,
        "coordinate_convention": "exact rational rank factorization of the source-derived Born table",
        "solver": solver,
        "state_generators_raw": matrix_strings(sp.Matrix(states_raw)),
        "effect_generators_raw": matrix_strings(sp.Matrix(effects_raw)),
        "born_pairing": matrix_strings(fragment.pairing),
        "state_coordinates": matrix_strings(fragment.state_coordinates),
        "effect_coordinates": matrix_strings(fragment.effect_coordinates),
        "state_facets": matrix_strings(state_facets),
        "effect_facets": matrix_strings(effect_facets),
        "state_accessible_dimension": fragment.state_coordinates.cols,
        "effect_accessible_dimension": fragment.effect_coordinates.cols,
        "state_facet_count": state_facets.rows,
        "effect_facet_count": effect_facets.rows,
        "facet_product": facet_product,
        "r_float": numeric["r_float"],
        "numerical_residual_or_dual_violation": residual,
        "sigma_float": numeric.get("sigma_float").tolist() if numeric.get("sigma_float") is not None else None,
        "dual_y_float": numeric.get("dual_y_float"),
        "certificate_status": "numerical closure optimum; generators and facets are exact rational data",
    }
    write_json(output / "closures" / safe_name(config.name) / f"{variant}.json", report)
    return report


def numeric_source_closure_audit(config: Configuration, variant: str, output: Path, np: Any, sp: Any, linprog: Any, ConvexHull: Any) -> Dict[str, Any]:
    states_raw, effects_raw, metadata = closure_fragment(config, variant, sp)
    pairing_exact = born_pairing_matrix(effects_raw, states_raw, config.dimension, sp)
    pairing = np.asarray([[float(sp.N(pairing_exact[i, j], 17)) for j in range(pairing_exact.cols)]
                          for i in range(pairing_exact.rows)])
    state_traces = np.asarray([float(sp.N(raw_trace(row, config.dimension, sp), 17)) for row in states_raw])
    effect_traces = np.asarray([float(sp.N(raw_trace(row, config.dimension, sp), 17)) for row in effects_raw])
    fragment = numeric_operational_factorization(pairing, state_traces, effect_traces, config.dimension, np)
    state_facets = numeric_cone_facets_hull(fragment["states"], state_traces, np, ConvexHull)
    effect_facets = numeric_cone_facets_hull(fragment["effects"], effect_traces, np, ConvexHull)
    m0 = np.eye(fragment["rank"])
    m1 = fragment["depolarizing"] - m0
    facet_product = state_facets.shape[0] * effect_facets.shape[0]
    if facet_product <= 50000:
        numeric = solve_primal_lp_numeric(m0, m1, state_facets, effect_facets, np, linprog)
        solver = "primal"
        residual = numeric["residual"]
    else:
        numeric = solve_dual_cutting(m0, m1, state_facets, effect_facets, np, linprog)
        solver = "cutting-dual"
        residual = numeric["max_dual_violation"]
    report = {
        "name": config.name,
        "kind": "vector-generated closure",
        "source": config.source,
        "construction": config.construction,
        "arithmetic": config.arithmetic,
        **metadata,
        "coordinate_convention": "numerical rank factorization of the exact Q(sqrt(2)) Born table",
        "solver": solver,
        "born_pairing_exact_strings": matrix_strings(pairing_exact),
        "operational_rank": fragment["rank"],
        "factorization_residual": fragment["factorization_residual"],
        "state_coordinates": fragment["states"].tolist(),
        "effect_coordinates": fragment["effects"].tolist(),
        "state_facets": state_facets.tolist(),
        "effect_facets": effect_facets.tolist(),
        "state_facet_count": int(state_facets.shape[0]),
        "effect_facet_count": int(effect_facets.shape[0]),
        "facet_product": int(facet_product),
        "r_float": numeric["r_float"],
        "numerical_residual_or_dual_violation": residual,
        "sigma_float": numeric.get("sigma_float").tolist() if numeric.get("sigma_float") is not None else None,
        "dual_y_float": numeric.get("dual_y_float"),
        "certificate_status": "numerical algebraic closure calculation",
    }
    write_json(output / "closures" / safe_name(config.name) / f"{variant}.json", report)
    return report


# ---------------------------------------------------------------------------
# Algebraic KCBS pentagon: deliberately numerical and isolated
# ---------------------------------------------------------------------------

def pentagon_report() -> Dict[str, Any]:
    rays = completed_pentagon_rays()
    def dot_float(u: Sequence[float], v: Sequence[float]) -> float:
        return sum(a * b for a, b in zip(u, v))
    contexts = [(i, 5 + i, (i + 1) % 5) for i in range(5)]
    return {
        "name": "Completed KCBS pentagon",
        "source": "A. A. Klyachko et al., Phys. Rev. Lett. 101, 020403 (2008), DOI 10.1103/PhysRevLett.101.020403; "
                  "R. Wright, The state of the pentagon, in Mathematical Foundations of Quantum Theory (1978), "
                  "DOI 10.1016/B978-0-12-473250-6.50015-7",
        "status": "vectors validated; --projector additionally runs a numerical-only LP",
        "reason": "The coordinates contain sqrt(cos(pi/5)); an exact algebraic-number facet backend is required for a certified threshold.",
        "rays_float": [list(ray) for ray in rays],
        "contexts": [list(context) for context in contexts],
        "maximum_context_dot_product": max(abs(dot_float(rays[i], rays[j])) for context in contexts for i, j in itertools.combinations(context, 2)),
    }


def numeric_raw_projector(ray: Sequence[float], np: Any) -> Any:
    vector = np.asarray(ray, dtype=float)
    norm = float(vector @ vector)
    raw = [vector[i] * vector[i] / norm for i in range(len(vector))]
    raw.extend(vector[i] * vector[j] / norm for i in range(len(vector) - 1) for j in range(i + 1, len(vector)))
    return np.asarray(raw, dtype=float)


def numeric_cone_facets(rows: Any, np: Any, tolerance: float = 1e-8) -> Any:
    """Enumerate facets of the small, six-dimensional KCBS cone numerically."""
    generators = np.asarray(rows, dtype=float)
    count, dimension = generators.shape
    facets: List[Any] = []
    for indices in itertools.combinations(range(count), dimension - 1):
        face = generators[list(indices), :]
        if np.linalg.matrix_rank(face, tol=1e-9) < dimension - 1:
            continue
        normal = np.linalg.svd(face)[2][-1, :]
        products = generators @ normal
        if not (np.all(products >= -tolerance) or np.all(products <= tolerance)):
            continue
        if np.any(products < -tolerance):
            normal = -normal
        normal = normal / np.linalg.norm(normal)
        if not any(abs(float(normal @ present)) > 1 - 1e-6 for present in facets):
            facets.append(normal)
    if not facets:
        raise RuntimeError("numeric KCBS facet enumeration returned no facets")
    return np.vstack(facets)


def numeric_operational_factorization(pairing: Any, state_normalizations: Any, effect_traces: Any, d: int, np: Any) -> Dict[str, Any]:
    """Rank-factor a numerical Born table and construct depolarization."""
    matrix = np.asarray(pairing, dtype=float)
    u, singular, vt = np.linalg.svd(matrix, full_matrices=False)
    tolerance = max(matrix.shape) * np.finfo(float).eps * singular[0] * 100
    rank = int(np.sum(singular > tolerance))
    roots = np.sqrt(singular[:rank])
    effects = u[:, :rank] * roots
    states = vt[:rank, :].T * roots
    if np.max(np.abs(effects @ states.T - matrix)) > 1e-9:
        raise RuntimeError("numerical Born-table rank factorization failed")
    normalization_functional = np.linalg.lstsq(states, np.asarray(state_normalizations, dtype=float), rcond=None)[0]
    mixed_state = np.linalg.lstsq(effects, np.asarray(effect_traces, dtype=float) / d, rcond=None)[0]
    if np.max(np.abs(states @ normalization_functional - state_normalizations)) > 1e-8:
        raise RuntimeError("state normalization is inconsistent with operational coordinates")
    if np.max(np.abs(effects @ mixed_state - np.asarray(effect_traces, dtype=float) / d)) > 1e-8:
        raise RuntimeError("maximally mixed state is inconsistent with operational coordinates")
    return {
        "states": states,
        "effects": effects,
        "depolarizing": np.outer(mixed_state, normalization_functional),
        "rank": rank,
        "factorization_residual": float(np.max(np.abs(effects @ states.T - matrix))),
    }


def numeric_cone_facets_hull(generators: Any, normalizations: Any, np: Any, ConvexHull: Any, tolerance: float = 2e-8) -> Any:
    """Enumerate cone facets by slicing with a positive normalization plane."""
    generators = np.asarray(generators, dtype=float)
    normalizations = np.asarray(normalizations, dtype=float)
    if np.any(normalizations <= tolerance):
        raise ValueError("cone-slice normalizations must be strictly positive")
    normalization_functional = np.linalg.lstsq(generators, normalizations, rcond=None)[0]
    if np.max(np.abs(generators @ normalization_functional - normalizations)) > 1e-7:
        raise RuntimeError("positive cone slice could not be reconstructed")
    points = generators / normalizations[:, None]
    unique = []
    for point in points:
        if not any(np.linalg.norm(point - present) <= tolerance for present in unique):
            unique.append(point)
    points = np.asarray(unique)
    origin = points[0]
    _, singular, vt = np.linalg.svd(points - origin, full_matrices=False)
    affine_dimension = int(np.sum(singular > tolerance))
    if affine_dimension != generators.shape[1] - 1:
        raise RuntimeError(f"cone slice has affine dimension {affine_dimension}, expected {generators.shape[1] - 1}")
    basis = vt[:affine_dimension].T
    coordinates = (points - origin) @ basis
    hull = ConvexHull(coordinates, qhull_options="Qx")
    facets = []
    for equation in hull.equations:
        normal = equation[:-1]
        offset = equation[-1]
        ambient = basis @ normal
        constant = offset - float(origin @ ambient)
        facet = -(ambient + constant * normalization_functional)
        products = generators @ facet
        if np.min(products) < -1e-6:
            facet = -facet
            products = -products
        if np.min(products) < -1e-6:
            raise RuntimeError("oriented hull facet cuts a cone generator")
        facet /= np.linalg.norm(facet)
        if not any(abs(float(facet @ present)) > 1 - 1e-7 for present in facets):
            facets.append(facet)
    if not facets:
        raise RuntimeError("numerical cone-slice hull returned no facets")
    return np.vstack(facets)


def numeric_source_projector_audit(config: Configuration, output: Path, np: Any, sp: Any, linprog: Any, ConvexHull: Any) -> Dict[str, Any]:
    state_rows = [raw_projector(ray, sp) for ray in config.rays]
    pairing_exact = born_pairing_matrix(state_rows, state_rows, config.dimension, sp)
    pairing = np.asarray([[float(sp.N(pairing_exact[i, j], 17)) for j in range(pairing_exact.cols)]
                          for i in range(pairing_exact.rows)])
    traces = np.ones(len(state_rows))
    fragment = numeric_operational_factorization(pairing, traces, traces, config.dimension, np)
    state_facets = numeric_cone_facets_hull(fragment["states"], traces, np, ConvexHull)
    effect_facets = numeric_cone_facets_hull(fragment["effects"], traces, np, ConvexHull)
    m0 = np.eye(fragment["rank"])
    m1 = fragment["depolarizing"] - m0
    facet_product = state_facets.shape[0] * effect_facets.shape[0]
    if facet_product <= 50000:
        numeric = solve_primal_lp_numeric(m0, m1, state_facets, effect_facets, np, linprog)
        solver = "primal"
        residual = numeric["residual"]
    else:
        numeric = solve_dual_cutting(m0, m1, state_facets, effect_facets, np, linprog)
        solver = "cutting-dual"
        residual = numeric["max_dual_violation"]
    report = {
        "name": config.name,
        "kind": "projector-cone",
        "source": config.source,
        "construction": config.construction,
        "arithmetic": config.arithmetic,
        "certificate_status": "numerical algebraic calculation",
        "rays": [serialize_ray(ray) for ray in config.rays],
        "born_pairing_exact_strings": matrix_strings(pairing_exact),
        "operational_rank": fragment["rank"],
        "factorization_residual": fragment["factorization_residual"],
        "state_coordinates": fragment["states"].tolist(),
        "effect_coordinates": fragment["effects"].tolist(),
        "state_facets": state_facets.tolist(),
        "effect_facets": effect_facets.tolist(),
        "state_facet_count": int(state_facets.shape[0]),
        "effect_facet_count": int(effect_facets.shape[0]),
        "facet_product": int(facet_product),
        "solver": solver,
        "r_float": numeric["r_float"],
        "numerical_residual_or_dual_violation": residual,
        "sigma_float": numeric.get("sigma_float").tolist() if numeric.get("sigma_float") is not None else None,
        "dual_y_float": numeric.get("dual_y_float"),
    }
    write_json(output / "projector" / safe_name(config.name) / "audit.json", report)
    return report


def numeric_pentagon_audit(output: Path, np: Any, linprog: Any) -> Dict[str, Any]:
    rays = completed_pentagon_rays()
    states = np.vstack([numeric_raw_projector(ray, np) for ray in rays])
    metric = np.asarray([1.0, 1.0, 1.0, 2.0, 2.0, 2.0])
    effects = states * metric
    state_svd = np.linalg.svd(states, full_matrices=False)
    effect_svd = np.linalg.svd(effects, full_matrices=False)
    state_basis = state_svd[2].T[:, :6]
    effect_basis = effect_svd[2].T[:, :6]
    state_facets = numeric_cone_facets(states @ state_basis, np)
    effect_facets = numeric_cone_facets(effects @ effect_basis, np)
    depolarizing = np.zeros((6, 6))
    depolarizing[:3, :3] = 1.0 / 3.0
    m0 = effect_basis.T @ state_basis
    m1 = effect_basis.T @ (depolarizing - np.eye(6)) @ state_basis
    numeric = solve_primal_lp_numeric(m0, m1, state_facets, effect_facets, np, linprog)
    report = {
        "name": "Completed KCBS pentagon",
        "source": pentagon_report()["source"],
        "status": "numerical only; no algebraic exact certificate is claimed",
        "rays_float": [list(ray) for ray in rays],
        "state_basis": state_basis.tolist(),
        "effect_basis_dual": effect_basis.tolist(),
        "state_facets": state_facets.tolist(),
        "effect_facets": effect_facets.tolist(),
        "m0": m0.tolist(),
        "m1": m1.tolist(),
        "r_float": numeric["r_float"],
        "lp_residual": numeric["residual"],
        "sigma_float": numeric["sigma_float"].tolist(),
    }
    write_json(output / "pentagon" / "audit.json", report)
    return report


def solve_primal_lp_numeric(m0: Any, m1: Any, state_facets: Any, effect_facets: Any, np: Any, linprog: Any) -> Dict[str, Any]:
    rows, cols = m0.shape
    n_sigma = state_facets.shape[0] * effect_facets.shape[0]
    Aeq = np.zeros((rows * cols, 1 + n_sigma))
    Aeq[:, 0] = -m1.reshape(-1)
    Aeq[:, 1:] = (effect_facets[:, None, :, None] * state_facets[None, :, None, :]).reshape(n_sigma, rows * cols).T
    b = m0.reshape(-1)
    objective = np.zeros(1 + n_sigma)
    objective[0] = 1.0
    result = linprog(objective, A_eq=Aeq, b_eq=b, bounds=[(0.0, 1.0)] + [(0.0, None)] * n_sigma, method="highs-ds")
    if not result.success:
        raise RuntimeError(f"numerical primal LP failed: {result.message}")
    return {"r_float": float(result.x[0]), "sigma_float": result.x[1:].reshape((effect_facets.shape[0], state_facets.shape[0])), "residual": float(np.max(np.abs(Aeq @ result.x - b)))}


# ---------------------------------------------------------------------------
# Report writing and command line
# ---------------------------------------------------------------------------

def safe_name(name: str) -> str:
    return "".join(character if character.isalnum() else "_" for character in name).strip("_")


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def runtime_report() -> Dict[str, Any]:
    source = Path(__file__).resolve()
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    return {
        "python": sys.version,
        "platform": platform.platform(),
        "program_path": str(source),
        "program_sha256": digest,
        "exact_scalar_type": "fractions.Fraction / Quadratic Q(sqrt(2)) / sympy.Rational",
    }


AUDIT_SCHEMA_VERSION = 3


def task_fingerprint(config: Optional[Configuration], stage: str, variant: Optional[str] = None) -> str:
    payload: Dict[str, Any] = {
        "audit_schema_version": AUDIT_SCHEMA_VERSION,
        "stage": stage,
        "variant": variant,
    }
    if config is not None:
        payload["configuration"] = {
            "name": config.name,
            "dimension": config.dimension,
            "rays": [serialize_ray(ray) for ray in config.rays],
            "source": config.source,
            "construction": config.construction,
            "arithmetic": config.arithmetic,
        }
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def read_checkpoint(path: Path, fingerprint: str, force: bool) -> Optional[Dict[str, Any]]:
    if force or not path.exists():
        return None
    try:
        report = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return report if report.get("task_fingerprint") == fingerprint else None


def finish_checkpoint(path: Path, fingerprint: str, report: Dict[str, Any]) -> Dict[str, Any]:
    report["task_fingerprint"] = fingerprint
    report["audit_schema_version"] = AUDIT_SCHEMA_VERSION
    write_json(path, report)
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--outdir", default="simplex_audit_output", help="directory for every generated report")
    parser.add_argument("--validate", action="store_true", help="write and verify all ray/context/valuation data")
    parser.add_argument("--projector", action="store_true", help="run projector-cone LP audits for all selected configurations")
    parser.add_argument("--closures", action="store_true", help="also run the two vector-generated closure variants")
    parser.add_argument("--only", action="append", default=[], help="run only configurations whose name contains this text")
    parser.add_argument("--force", action="store_true", help="recompute task files even when their input fingerprints match")
    args = parser.parse_args()
    if not (args.validate or args.projector or args.closures):
        args.validate = True
        args.projector = True
        args.closures = True

    output = Path(args.outdir).resolve()
    output.mkdir(parents=True, exist_ok=True)
    selected_configurations = configurations()
    pentagon_selected = not args.only or any(token.lower() in "completed kcbs pentagon" for token in args.only)
    if args.only:
        selected_configurations = [config for config in selected_configurations if any(token.lower() in config.name.lower() for token in args.only)]
    if not selected_configurations and not pentagon_selected:
        raise SystemExit("--only did not match a configuration")
    validations = [validate_configuration(config) for config in selected_configurations]
    report: Dict[str, Any] = {
        "program": "simplex_audit_rebuilt.py",
        "purpose": "self-contained source-checked simplex-cone audit",
        "audit_schema_version": AUDIT_SCHEMA_VERSION,
        "runtime": runtime_report(),
        "validation": validations,
        "pentagon": pentagon_report(),
        "cache_policy": "reuse a task only when its SHA-256 input fingerprint and audit schema version match; --force disables reuse",
    }
    write_json(output / "vectors.json", report)
    if not all(row["validation_passed"] for row in validations):
        raise RuntimeError("vector validation failed; refusing to run an LP")

    if args.projector or args.closures:
        np, sp, linprog, ConvexHull, cdd, _ = require_audit_dependencies()
        projector_reports = []
        closure_reports = []
        run_errors: List[Dict[str, str]] = []
        cache_events: List[Dict[str, str]] = []
        report["projector_audits"] = projector_reports
        report["closure_audits"] = closure_reports
        report["run_errors"] = run_errors
        report["cache_events"] = cache_events
        if args.projector:
            for config in selected_configurations:
                checkpoint = output / "projector" / safe_name(config.name) / "audit.json"
                fingerprint = task_fingerprint(config, "projector")
                cached = read_checkpoint(checkpoint, fingerprint, args.force)
                if cached is not None:
                    print(f"REUSE PROJECTOR {config.name}", flush=True)
                    projector_reports.append(cached)
                    cache_events.append({"stage": "projector", "configuration": config.name, "action": "reused"})
                    continue
                print(f"PROJECTOR {config.name}", flush=True)
                try:
                    if config.arithmetic == "quadratic-rational-pairing":
                        result = exact_pairing_projector_audit(config, output, np, sp, linprog, cdd)
                    elif config.arithmetic == "quadratic-numerical":
                        result = numeric_source_projector_audit(config, output, np, sp, linprog, ConvexHull)
                    else:
                        result = projector_audit(config, output, np, sp, linprog, cdd)
                    projector_reports.append(finish_checkpoint(checkpoint, fingerprint, result))
                    cache_events.append({"stage": "projector", "configuration": config.name, "action": "computed"})
                except Exception as exc:
                    run_errors.append({"stage": "projector", "configuration": config.name, "error": str(exc)})
                write_json(output / "audit_report.json", report)
            if pentagon_selected:
                pentagon_checkpoint = output / "pentagon" / "audit.json"
                pentagon_fingerprint = task_fingerprint(None, "projector-pentagon")
                cached_pentagon = read_checkpoint(pentagon_checkpoint, pentagon_fingerprint, args.force)
                if cached_pentagon is not None:
                    print("REUSE PROJECTOR Completed KCBS pentagon [numerical]", flush=True)
                    report["pentagon_audit"] = cached_pentagon
                    cache_events.append({"stage": "projector", "configuration": "Completed KCBS pentagon", "action": "reused"})
                else:
                    try:
                        print("PROJECTOR Completed KCBS pentagon [numerical]", flush=True)
                        result = numeric_pentagon_audit(output, np, linprog)
                        report["pentagon_audit"] = finish_checkpoint(pentagon_checkpoint, pentagon_fingerprint, result)
                        cache_events.append({"stage": "projector", "configuration": "Completed KCBS pentagon", "action": "computed"})
                    except Exception as exc:
                        run_errors.append({"stage": "projector", "configuration": "Completed KCBS pentagon", "error": str(exc)})
            write_json(output / "audit_report.json", report)
        if args.closures:
            for config in selected_configurations:
                for variant in ("effects", "effects-and-preps"):
                    checkpoint = output / "closures" / safe_name(config.name) / f"{variant}.json"
                    fingerprint = task_fingerprint(config, "closure", variant)
                    cached = read_checkpoint(checkpoint, fingerprint, args.force)
                    if cached is not None:
                        print(f"REUSE CLOSURE {config.name} [{variant}]", flush=True)
                        closure_reports.append(cached)
                        cache_events.append({"stage": "closure", "configuration": config.name, "variant": variant, "action": "reused"})
                        continue
                    print(f"CLOSURE {config.name} [{variant}]", flush=True)
                    try:
                        if config.arithmetic == "quadratic-rational-pairing":
                            result = exact_pairing_closure_audit(config, variant, output, np, sp, linprog, cdd)
                        elif config.arithmetic == "quadratic-numerical":
                            result = numeric_source_closure_audit(config, variant, output, np, sp, linprog, ConvexHull)
                        else:
                            result = closure_audit(config, variant, output, np, sp, linprog, cdd)
                        closure_reports.append(finish_checkpoint(checkpoint, fingerprint, result))
                        cache_events.append({"stage": "closure", "configuration": config.name, "variant": variant, "action": "computed"})
                    except Exception as exc:
                        run_errors.append({"stage": "closure", "configuration": config.name, "variant": variant, "error": str(exc)})
                    write_json(output / "audit_report.json", report)

        if run_errors:
            print(json.dumps({"run_errors": run_errors}, indent=2), file=sys.stderr)
            raise SystemExit(2)

    print(f"Wrote validation and audit data to {output}")


if __name__ == "__main__":
    main()
