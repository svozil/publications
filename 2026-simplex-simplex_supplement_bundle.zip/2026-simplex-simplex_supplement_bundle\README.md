# Simplex audit supplement bundle

This archive is the reproducibility package for *Which Classicality? Incidence, Simplex, and Product-Rule Tests in Finite Quantum Logics*.

## Complete run

From this directory, run:

```text
python simplex_audit_rebuilt.py --outdir audit_v3
```

The default command validates every coordinate source, computes every projector-cone result, computes the effects and effects-plus-preparations closures, and evaluates the completed KCBS pentagon. It writes machine-readable reports under `audit_v3/`.

The required third-party Python packages are NumPy, SciPy, SymPy, and pycddlib (with cddlib). The recorded run used CPython 3.11.9 on 64-bit Windows. Its program SHA-256 is:

```text
d2298aeaab2d47a42e94e9077ece208df8042ddf6603d6fd0252d8fc184e1596
```

## Checkpoint reuse

Each task has an input fingerprint. A report is reused only when its fingerprint matches the current inputs. Use `--force` to recompute every task. Useful selections include:

```text
python simplex_audit_rebuilt.py --validate --outdir audit_v3
python simplex_audit_rebuilt.py --projector --outdir audit_v3
python simplex_audit_rebuilt.py --closures --outdir audit_v3
python simplex_audit_rebuilt.py --projector --closures --only Specker --outdir audit_v3
```

Run `python simplex_audit_rebuilt.py --help` for the complete command-line interface.

## Contents

- `simplex_audit_rebuilt.py`: single source-driven audit program.
- `audit_v3/audit_report.json`: consolidated runtime, validation, projector, closure, pentagon, and cache report.
- `audit_v3/vectors.json`: coordinate representatives, labels, contexts, sources, and validation checks.
- `audit_v3/projector/`: per-configuration reports and available exact certificates.
- `audit_v3/closures/`: both operational-closure reports for every applicable configuration.
- `audit_v3/pentagon/`: completed-pentagon numerical report.
- `2026-simplex-supplement.tex` and `.pdf`: supplementary text and compiled document.
- `2026-simplex-vector-catalog.tex`: explicit enumeration of every vector and context printed by the supplement.
- `SHA256SUMS.txt`: SHA-256 digest and relative path for every payload file.

## Status convention

An entry is labelled **exact** only when the report contains an exact feasible certificate and an exact matching lower-bound certificate. Entries labelled **numerical** retain the solver value and the reported feasibility or dual-violation residual. The consolidated report records an empty `run_errors` array for the packaged run.
