"""Two-valued state enumeration after Josef Tkadlec's 2states.pas (2009).

This module ports the block-order state-generation algorithm, not the original
heuristic tests of element separation and order determination. Complete blocks
sum to one; proper subblocks sum to at most one. There are no fixed array limits.
The original supplied full Python translation is audited separately.

CLI: python tkadlec_states.py INPUT.txt [-o OUTPUT.json]
Input uses Tkadlec's text format. Output goes to stdout unless -o is supplied;
the input is never overwritten. Explicit vertices absent from all blocks are
enumerated freely, rather than silently fixed to zero as in the legacy code.
"""
import argparse
import itertools
import json
from pathlib import Path

def vertex_key(v):
    text=str(v)
    return (0,int(text)) if text.lstrip('-').isdigit() else (1,text)

def enumerate_states(blocks, subblocks=(), vertices=None):
    blocks=[tuple(e) for e in blocks];subblocks=[tuple(e) for e in subblocks]
    edges=blocks+subblocks
    if any(not e or len(set(e))!=len(e) for e in edges):
        raise ValueError('Every (sub)block must be nonempty and contain distinct vertices.')
    covered=set().union(*map(set,edges)) if edges else set()
    V=sorted(covered if vertices is None else set(vertices),key=vertex_key)
    if not covered.issubset(V):raise ValueError('Block contains an undeclared vertex.')
    used=set();ordered=[]
    for e in edges:
        old=tuple(v for v in e if v in used)
        new=tuple(v for v in e if v not in used)
        ordered.append((old,new))
        used.update(e)
    isolated=[v for v in V if v not in used]
    assignment={};result=[]
    def visit(index):
        if index==len(edges):
            for bits in itertools.product((0,1),repeat=len(isolated)):
                assignment.update(zip(isolated,bits))
                result.append(tuple(assignment[v] for v in V))
            return
        old,new=ordered[index]
        total=sum(assignment[v] for v in old)
        if total>1:return
        for v in new:assignment[v]=0
        if total==0:
            for v in new:
                assignment[v]=1;visit(index+1);assignment[v]=0
            if index>=len(blocks):visit(index+1)
        else:visit(index+1)
    visit(0)
    return V,sorted(result)

def enumerate_independently(blocks,subblocks=(),vertices=None):
    """Independent variable-first solver with propagation, for cross-checking."""
    blocks=[tuple(e) for e in blocks];subs=[tuple(e) for e in subblocks]
    edges=blocks+subs
    V=sorted(set().union(*map(set,edges)) if vertices is None else set(vertices),key=vertex_key)
    result=[]
    def visit(a):
        a=a.copy()
        while True:
            changed=False
            for i,e in enumerate(edges):
                total=sum(a.get(v,0) for v in e);unknown=[v for v in e if v not in a]
                if total>1 or (i<len(blocks) and not unknown and total!=1):return
                value=0 if total==1 else 1 if i<len(blocks) and len(unknown)==1 else None
                if value is not None:
                    for v in unknown:a[v]=value;changed=True
            if not changed:break
        missing=[v for v in V if v not in a]
        if not missing:result.append(tuple(a[v] for v in V));return
        v=max(missing,key=lambda v:sum(v in e for e in edges))
        for bit in (0,1):visit(a|{v:bit})
    visit({})
    return V,sorted(result)

def read_legacy(path):
    lines=Path(path).read_text(encoding='utf-8-sig').splitlines()
    if len(lines)<4:raise ValueError('Missing legacy header.')
    n,nb,nc=[int(lines[i].split()[0]) for i in range(1,4)]
    if n<1 or nb<0 or nc<0:raise ValueError('Invalid legacy dimensions.')
    edges=[]
    for line in lines[4:4+nb+nc]:
        values=line.split();k=int(values[0]);edge=tuple(map(int,values[1:k+1]))
        if len(edge)!=k or not set(edge).issubset(range(1,n+1)):
            raise ValueError('Invalid block line.')
        edges.append(edge)
    if len(edges)!=nb+nc:raise ValueError('Missing block lines.')
    return lines[0],list(range(1,n+1)),edges[:nb],edges[nb:]

def write_legacy(path,name,V,blocks,states=None):
    mapping={v:i+1 for i,v in enumerate(V)}
    lines=[name,f'{len(V)} atoms',f'{len(blocks)} blocks','0 proper subblocks']
    lines.extend(str(len(e))+' '+' '.join(str(mapping[v]) for v in e) for e in blocks)
    if states is not None:
        lines.append(f'{len(states)} 2-valued evaluations of atoms:')
        lines.extend(' '.join(map(str,row)) for row in states)
    Path(path).write_text('\n'.join(lines)+'\n',encoding='utf-8')

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input');parser.add_argument('-o','--output')
    args=parser.parse_args()
    name,V,blocks,subs=read_legacy(args.input)
    V,rows=enumerate_states(blocks,subs,V)
    text=json.dumps(dict(description=name,vertices=V,states=rows),indent=2)+'\n'
    if args.output:
        if Path(args.output).resolve()==Path(args.input).resolve():
            raise ValueError('Choose an output path different from the input.')
        Path(args.output).write_text(text,encoding='utf-8')
    else:print(text,end='')
