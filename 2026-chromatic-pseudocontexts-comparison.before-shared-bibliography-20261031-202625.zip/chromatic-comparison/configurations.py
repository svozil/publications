"""Exact ray/context inventories for the manuscript's 19 configurations.

Integer and Gaussian-integer coordinates are transcribed from the manuscript
and its cited companion tables. Algebraic coordinates use the printed formulas.
All vertex labels are strings; there is no implicit relabeling of the rays.
"""
from dataclasses import dataclass
import sympy as s

@dataclass
class Configuration:
    key: str
    name: str
    dimension: int
    contexts: list
    rays: dict
    expected: tuple  # normalized colorings, extendable states, all states
    source: str

    def __post_init__(self):
        self.contexts=[tuple(map(str,e)) for e in self.contexts]
        self.rays={str(k):s.Matrix(v) for k,v in self.rays.items()}
        used=set().union(*map(set,self.contexts))
        self.rays={k:v for k,v in self.rays.items() if k in used}
        assert used==set(self.rays),(self.key,'missing rays',used-set(self.rays))
        assert all(len(e)==len(set(e))==self.dimension for e in self.contexts)

def bug_edges(x,y,base):
    def v(k):return base+k
    return [(v(1),v(2),v(3)),(v(7),v(8),v(9)),(v(2),v(8),v(5)),
            (v(3),y,v(14)),(v(7),y,v(15)),(v(9),x,v(23)),(v(1),x,v(19))]

def bug_rays(x,y,f1,f2,base):
    r={2:f1,8:f2,5:f1.cross(f2),1:f1.cross(x),3:f1.cross(y),
       9:f2.cross(x),7:f2.cross(y)}
    r.update({14:y.cross(r[3]),15:y.cross(r[7]),19:x.cross(r[1]),23:x.cross(r[9])})
    # Ray scale is immaterial; expansion keeps the algebraic formulas compact.
    return {base+k:v.applyfunc(s.expand) for k,v in r.items()}

def rational_base(alpha,beta):
    r={1:s.Matrix([0,1,alpha]),2:s.Matrix([1,0,0]),3:s.Matrix([0,alpha,-1]),
       5:s.Matrix([0,0,1]),7:s.Matrix([1,0,beta]),8:s.Matrix([0,1,0]),
       9:s.Matrix([beta,0,-1]),10:s.Matrix([1,-alpha*beta,beta]),
       11:s.Matrix([alpha*beta,-1,-alpha])}
    r[4]=r[10].cross(r[11]);r[14]=r[11].cross(r[3]);r[15]=r[7].cross(r[11])
    r[19]=r[1].cross(r[10]);r[23]=r[10].cross(r[9])
    r[18]=r[4].cross(r[10]);r[24]=r[11].cross(r[4])
    return r

def configurations():
    out=[]
    def add(key,name,d,edges,rays,expected,source):
        out.append(Configuration(key,name,d,edges,rays,expected,source))
    M={1:(5,3,-4),2:(5,-7,1),3:(1,1,2),4:(1,1,-1),5:(1,-1,0),
       6:(5,-16,13),7:(5,4,3),8:(-2,1,2),9:(1,0,1),10:(1,4,-1),
       11:(-5,18,1),12:(5,2,-11),13:(4,1,2),14:(-1,2,1),15:(1,2,-3)}
    Em=[(1,2,3),(3,4,5),(6,7,8),(8,9,10),(11,12,13),(13,14,15),(2,7,12),(4,9,14)]
    add('M15','M_{15,8}',3,Em,M,(16,24,24),'Manuscript eq:M15-vectors')

    C=(49-5*s.sqrt(69))/26;rt=s.sqrt(C);rn=s.sqrt(1+C)
    eta=(5+12*s.I)/13;zeta=(14+6*s.sqrt(69)+s.I*(4*s.sqrt(69)-21))/65
    mu=[-1,eta,1,-eta,-1,eta,1,-eta]
    tau=[1,zeta,-s.I,-s.I*zeta,-1,-zeta,s.I,s.I*zeta]
    octr={f'v{j}':s.Matrix([1,rt*mu[j],rn*tau[j]]) for j in range(8)}
    for j in range(8):
        octr[f'e{j}']=octr[f'v{j}'].cross(octr[f'v{(j+1)%8}']).conjugate()
    octr.update(a1=s.Matrix([rt,1,0]),a2=s.Matrix([rt,-1,0]),
                b1=s.Matrix([rt,eta,0]),b2=s.Matrix([rt,-eta,0]))
    Eo=[(f'e{(j-1)%8}',f'v{j}',f'e{j}') for j in range(8)]
    Eo += [('v0','a1','v4'),('v2','a2','v6'),('v1','b2','v5'),('v3','b1','v7')]
    add('Oct20',r'\mathsf H_{20}',3,Eo,octr,(12,26,26),
        'Complex-only companion eq:C-definition--eq:h20-corners')

    yo={1:(0,1,1),2:(1,0,0),3:(0,1,-1),4:(1,1,0),5:(0,0,1),6:(1,-1,0),
        7:(1,0,1),8:(0,1,0),9:(1,0,-1),10:(1,-1,1),11:(1,-1,-1),12:(1,1,1),
        13:(1,1,-1),14:(2,1,1),15:(1,2,-1),16:(1,-2,1),17:(1,1,-2),
        18:(1,-1,-2),19:(2,1,-1),20:(2,-1,1),21:(1,-2,-1),22:(1,1,2),
        23:(1,2,1),24:(1,-1,2),25:(2,-1,-1)}
    Eb=bug_edges(10,11,0)
    Eh17=[(1,2,3),(7,8,9),(4,5,6),(2,8,5),(3,11,14),(7,11,15),
           (4,11,24),(9,10,23),(1,10,19),(4,10,18)]
    Ed=[e for e in Eh17 if set(e)!={1,10,19}]
    Ei=[e for e in Eh17 if set(e)!={4,5,6}]
    deformed=dict(yo)
    deformed.update({1:(0,1,2),3:(0,2,-1),4:(1,2,0),6:(2,-1,0),
                     10:(2,-1,2),11:(2,-1,-2),14:(5,2,4),15:(1,4,-1),
                     18:(4,-2,-5),23:(1,4,1),24:(4,-2,5),
                     26:(2,-41,18),27:(200,-82,-209),28:(241,82,160)})
    ivec=dict(yo)
    ivec.update({4:(4,5,3),7:(1,0,2),9:(2,0,-1),10:(1,-2,2),11:(2,-1,-1),
                 14:(1,1,1),15:(2,5,-1),18:(16,-5,-13),19:(4,1,-1),
                 23:(2,5,4),24:(1,-5,7)})
    add('B13','B_{13,7}',3,Eb,yo,(6,12,14),'Manuscript tab:yo-vectors')
    add('D16','D_{16,9}',3,Ed,deformed,(7,14,21),'2026-color-20p-supp.tex tab:vec-3c')
    add('I16','I_{16,9}',3,Ei,ivec,(6,12,22),'2026-color-20p-supp.tex tab:vec-3d')
    add('H17','H_{17,10}',3,Eh17,yo,(4,10,18),'Manuscript tab:yo-vectors')
    add('T19','T_{19,11}',3,Ed+[(14,26,27),(18,26,28)],deformed,(7,14,25),
        'Manuscript tab:yo-vectors; companion tab:vec-3e')
    Eh21=Eh17+[(6,13,22),(1,13,20),(7,13,21)]
    Eh20=[e for e in Eh21 if set(e)!={6,13,22}]
    h20={1:(0,1,2),2:(1,0,0),3:(0,2,-1),4:(1,1,0),5:(0,0,1),6:(1,-1,0),
         7:(2,0,1),8:(0,1,0),9:(1,0,-2),10:(2,-2,1),11:(1,-1,-2),13:(1,4,-2),
         14:(5,1,2),15:(1,5,-2),18:(1,-1,-4),19:(5,4,-2),20:(-10,2,-1),
         21:(-4,5,8),23:(4,5,2),24:(1,-1,1)}
    add('H20','H_{20,12}',3,Eh20,h20,(4,10,25),'Manuscript tab:yo-vectors caption, cross-product completions')
    add('H21','H_{21,13}',3,Eh21,yo,(2,6,21),'Manuscript tab:yo-vectors')

    al=s.Rational(9,32);be=s.Rational(24,11)
    rg=rational_base(al,be)
    n=rg[4]/s.Rational(45305,15488)
    skew=s.Matrix([[0,-n[2],n[1]],[n[2],0,-n[0]],[-n[1],n[0],0]])
    R=n*n.T-skew
    for k in [1,2,3,5,7,8,9,14,15,19,23]:rg[100+k]=R*rg[k]
    Eg=Ei+bug_edges(18,24,100)
    add('G27','G_{27,16}',3,Eg,rg,(36,54,82),'Manuscript eq:roof-base-rays and rational quarter-turn')
    rg=dict(rg);rg[26]=rg[14].cross(rg[18]);rg[27]=rg[26].cross(rg[14]);rg[28]=rg[26].cross(rg[18])
    u=rg[27]/s.sqrt(rg[27].dot(rg[27]));v=rg[28]/s.sqrt(rg[28].dot(rg[28]))
    if s.N(u.dot(v))<0:v=-v
    e1=u+v;e2=u-v;e3=u.cross(v)
    ratio=s.simplify(e1.dot(e1)/e2.dot(e2))
    f1=(e1/s.sqrt(e1.dot(e1))+s.sqrt(2-ratio)*e2/s.sqrt(e2.dot(e2))+s.sqrt(ratio-1)*e3/s.sqrt(e3.dot(e3)))
    f2=(e1/s.sqrt(e1.dot(e1))-s.sqrt(2-ratio)*e2/s.sqrt(e2.dot(e2))-s.sqrt(ratio-1)*e3/s.sqrt(e3.dot(e3)))
    rg.update(bug_rays(rg[27],rg[28],f1,f2,200))
    Eg41=Eg+[(14,27,26),(18,28,26)]+bug_edges(27,28,200)
    add('G41_25','G_{41,25}',3,Eg41,rg,(216,216,396),'Manuscript rational base and eq:roof-bug-rays')

    rs={k:s.Matrix(v) for k,v in yo.items()}
    rs.update(bug_rays(rs[18],rs[24],s.Matrix([1,1,s.sqrt(2)]),s.Matrix([1,1,-s.sqrt(2)]),100))
    rs.update({26:s.Matrix([-1,5,-3]),27:s.Matrix([8,-5,-11]),28:s.Matrix([-13,-5,-4])})
    aa=s.sqrt(35)*s.Matrix([3,0,-1]);bb=s.sqrt(15)*s.Matrix([1,2,3])+2*rs[26]
    rs.update(bug_rays(rs[27],rs[28],aa+bb,aa-bb,200))
    add('G41_26','G_{41,26}',3,Eg41+[(4,5,105)],rs,(48,63,107),
        'Manuscript eq:G41-vectors and eq:roof-third-triad; internal label 105')

    r53={'a':s.Matrix([1,-1,1]),'b':s.Matrix([1,-1,-1]),'c':s.Matrix([1,1,0])}
    xs=[(2,1,-1),(0,1,1),(1,0,0),(0,1,-1),(2,1,1),(1,2,-1),
        (1,0,1),(0,1,0),(1,0,-1),(1,2,1),(0,0,1)]
    r53.update({f'x{i}':s.Matrix(v) for i,v in enumerate(xs,1)})
    n=r53['c']/s.sqrt(2);K=s.Matrix([[0,-n[2],n[1]],[n[2],0,-n[0]],[-n[1],n[0],0]])
    R=n*n.T+K
    r53.update({"b'":R*r53['a'],"a'":R*r53['b']})
    r53.update({f'y{i}':R*r53[f'x{i}'] for i in range(1,12)})
    def bug53(a,b,p):
        def x(i):return p+str(i)
        return [(a,x(1),x(2)),(x(2),x(3),x(4)),(x(4),x(5),b),(b,x(6),x(7)),
                (x(7),x(8),x(9)),(x(9),x(10),a),(x(3),x(8),x(11))]
    E53=bug53('a','b','x')+bug53("b'","a'",'y')+[('a','c',"b'"),('b','c',"a'"),('c','x11','y11')]
    F=s.Matrix.hstack(r53['a']/s.sqrt(3),s.Matrix([1,-1,-2])/s.sqrt(6),n)
    E=s.Matrix.hstack(n,s.Matrix([0,0,1]),s.Matrix([1,-1,0])/s.sqrt(2))
    L=s.Matrix([[9,2,6],[2,9,-6],[-6,6,7]])/11
    Q=L*E*F.T
    ren={v:('c' if v=='a' else 'u' if v=="a'" else 't_'+v) for v in r53}
    r53.update({ren[v]:(Q*r).applyfunc(s.expand) for v,r in list(r53.items()) if v!='a'})
    E53 += [tuple(ren[v] for v in e) for e in list(E53)]
    add('H53','H_{53,34}',3,E53,r53,(128,128,224),'Manuscript eq:H53-initial-rays--eq:H53-pasting-rotation')

    I=s.I
    grid={1:(1,0,0),2:(0,1,0),3:(0,0,1),4:(-1+I,2,2),5:(2,-1+I,2),6:(2,2,-1+I),
          7:(-1-2*I,2,2),8:(2,-1-2*I,2),9:(2,2,-1-2*I),10:(0,1,-1),11:(-1,0,1),
          12:(1,-1,0),13:(0,1,1),14:(1,0,1),15:(1,1,0),16:(2-2*I,1,1),
          17:(1,2-2*I,1),18:(1,1,2-2*I),19:(4,1-2*I,1-2*I),
          20:(1-2*I,4,1-2*I),21:(1-2*I,1-2*I,4),22:(1,1,1),
          23:(2,-1,-1),24:(-1,2,-1),25:(-1,-1,2)}
    Er=[(1,2,3),(4,5,6),(7,8,9)]+[(3*a+k+1,10+k,13+3*a+k) for a in range(3) for k in range(3)]
    add('R21','R_{21,12}',3,Er,grid,(32,48,54),'Latin-context-matrix companion eq:R25-gaussian-vectors')
    add('R25','R_{25,15}',3,Er+[(22,10+k,23+k) for k in range(3)],grid,(24,48,81),
        'Latin-context-matrix companion eq:R25-gaussian-vectors')
    for key,name,base,edges,expected in [('B14','B_{14,7}^{(4)}',yo,Eb,(6,13,15)),('D17','D_{17,9}^{(4)}',deformed,Ed,(7,15,22))]:
        rays={k:tuple(v)+(0,) for k,v in base.items()};rays[0]=(0,0,0,1)
        add(key,name,4,[(0,)+e for e in edges],rays,expected,'Common-apex lift, apex label 0')
    four={1:(1,0,0,0),2:(0,1,0,0),3:(0,0,1,0),4:(0,0,0,1),5:(0,1,-1,-1),
          6:(4,-5,-11,6),7:(1,-4,0,-4),8:(4,1,1,0),9:(1,-5,1,0),10:(2,-1,-7,0),
          11:(0,0,1,-1),12:(0,2,1,1),13:(1,0,4,4),14:(8,0,-1,-1),15:(4,2,0,-1),
          16:(4,-5,0,6),17:(5,-9,7,2),18:(2,113,77,234),19:(16,-33,-2,-2),
          20:(4,2,-21,20),21:(22,12,-11,-11),22:(129,44,153,153)}
    E4=[(1,2,4,3),(5,8,7,6),(4,9,10,8),(11,1,12,5),(11,14,13,2),
        (15,3,16,7),(15,17,18,6),(11,21,22,19),(13,20,15,19)]
    four18=dict(four);four18.update({13:(1,0,1,1),14:(2,0,-1,-1)})
    add('L18','L_{18,7}^{(4)}',4,E4[:7],four18,(144,68,68),'Companion tab:vec-4d; distinct rays 13,14 from L22')
    add('L22','L_{22,9}^{(4)}',4,E4,four,(216,92,158),'Manuscript eq:L22-vectors')
    assert len(out)==19
    return out

if __name__=='__main__':
    for cfg in configurations():
        print(cfg.key,len(cfg.rays),len(cfg.contexts),cfg.expected,flush=True)
