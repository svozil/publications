"""Independent exact-facet and 80-digit spectral verification of saved results."""
import itertools
import json
from pathlib import Path
import mpmath as mp
import numpy as np
import sympy as sp
from configurations import configurations
from comparison_core import primitive,exact_polytope

def exhaustive_facets(points):
    dim=len(points[0]);difference=sp.Matrix([[p[i]-points[0][i] for i in range(dim)] for p in points])
    _,columns=difference.rref();rank=len(columns)
    result=set()
    if rank==0:return result
    if rank==1:
        j=columns[0]
        for sign in (-1,1):
            a=tuple(sign if i==j else 0 for i in range(dim))
            result.add((a,max(sum(x*y for x,y in zip(a,p)) for p in points)))
        return result
    projected=[tuple(p[j] for j in columns) for p in points]
    for inds in itertools.combinations(range(len(points)),rank):
        M=sp.Matrix([list(projected[i])+[1] for i in inds])
        null=M.nullspace()
        if len(null)!=1:continue
        plane=primitive(null[0]);a=plane[:-1];b=-plane[-1]
        values=[sum(x*y for x,y in zip(a,p)) for p in projected]
        if max(values)!=b:
            if min(values)!=b:continue
            a=tuple(-x for x in a);b=-b
        full=[0]*dim
        for j,col in enumerate(columns):full[col]=a[j]
        result.add((tuple(full),int(b)))
    return result

def mprojectors(cfg,V):
    result=[]
    for label in V:
        vector=[]
        for value in cfg.rays[label]:
            re,im=value.evalf(95).as_real_imag()
            vector.append(mp.mpc(str(re),str(im)))
        norm=mp.sqrt(sum(abs(x)**2 for x in vector));vector=[x/norm for x in vector]
        result.append(mp.matrix([[x*mp.conj(y) for y in vector] for x in vector]))
    return result

def main():
    mp.mp.dps=80
    root=Path(__file__).parent/'results'
    polyhedra={};report={'classical_polytopes':0,'configurations':{},'precision_digits':80}
    # Independent enumeration of every possible supporting hyperplane, without
    # relying on Qhull, proves completeness of the stored facet lists.
    for cfg in configurations():
        data=json.loads((root/(cfg.key+'.json')).read_text(encoding='utf-8'))
        for record in data['relations']:
            for weighted in record['weighted']:
                for field in ['coefficients_all','coefficients_extendable']:
                    points=tuple(map(tuple,weighted[field]));polyhedra[points]=True
    for points in polyhedra:
        expected=exhaustive_facets(points)
        proposed=exact_polytope(points)
        actual={(tuple(f['a']),f['b']) for f in proposed['facets']}
        assert expected==actual,('facet incompleteness',points,expected-actual,actual-expected)
        report['classical_polytopes']+=1
    print('Exact independent facet enumeration agrees for',len(polyhedra),'polytopes.',flush=True)
    for cfg in configurations():
        data=json.loads((root/(cfg.key+'.json')).read_text(encoding='utf-8'))
        V=data['vertices'];index={v:i for i,v in enumerate(V)}
        constraints={};unitchecks=[]
        def key(terms,coefficients):
            total={}
            for (v,sign),c in zip(terms,coefficients):total[index[v]]=total.get(index[v],0)+sign*c
            return tuple(sorted((i,c) for i,c in total.items() if c))
        for r in data['relations']:
            unitchecks.append((key(r['terms'],[1]*len(r['terms'])),r['unit_all']))
            for w in r['weighted']:
                for family in ['all','extendable']:
                    for t in w['comparison_'+family]['tests']:
                        coefficients=[t['c'][j] for j in w['color_pattern']]
                        k=key(r['terms'],coefficients)
                        constraints.setdefault(k,[]).append(t)
        P=mprojectors(cfg,V);cache={};maxerror=mp.mpf(0);nconstraints=0;smallest=mp.inf
        def spectrum(k):
            if k not in cache:
                O=mp.zeros(cfg.dimension)
                for i,c in k:O+=c*P[i]
                values=list(mp.eighe(O,eigvals_only=True))
                cache[k]=(values[0],values[-1])
            return cache[k]
        for k,tests in constraints.items():
            low,high=spectrum(k)
            for test in tests:
                nconstraints+=1
                gap=high-test['b']
                maxerror=max(maxerror,abs(high-test['quantum_max']),abs(low-test['quantum_min']))
                assert abs(high-test['quantum_max'])<mp.mpf('1e-11'),(cfg.key,'spectral mismatch')
                assert (gap>mp.mpf('1e-40'))==test['violating'],(cfg.key,'separation classification',k,str(gap),test)
                if gap>mp.mpf('1e-40'):smallest=min(smallest,gap)
        for k,unit in unitchecks:
            low,high=spectrum(k)
            assert abs(low-unit['quantum_min'])<mp.mpf('1e-11') and abs(high-unit['quantum_max'])<mp.mpf('1e-11')
            maxerror=max(maxerror,abs(high-unit['quantum_max']),abs(low-unit['quantum_min']))
        report['configurations'][cfg.key]=dict(unique_operators=len(cache),facet_equality_tests=nconstraints,
                    unit_expressions=len(unitchecks),max_float64_error=float(maxerror),
                    smallest_reported_positive_gap=None if smallest==mp.inf else str(smallest))
        print('80-digit spectra verified:',cfg.key,len(cache),'operators;',nconstraints,'comparisons',flush=True)
    destination=root/'high-precision-verification.json'
    destination.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print('ALL EXACT CLASSICAL FACETS AND HIGH-PRECISION SPECTRAL COMPARISONS PASSED.',flush=True)

if __name__=='__main__':main()
