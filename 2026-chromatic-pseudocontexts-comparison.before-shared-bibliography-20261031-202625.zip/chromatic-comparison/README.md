# Classical and quantum bounds for chromatic pseudocontexts

Read **COMPARISON.md** for the results for all 19 configurations. The complete
classical states, color patterns, exact parameter envelopes, quantum comparisons,
and witnesses are in `results/`. The revised article prints representative
intervals and exhaustive comparison counts.

## Run

The calculations were run with Python 3.11 and the versions in requirements.txt.

```
python -m pip install -r requirements.txt
python audit_translation.py
python run_comparison.py
python verify_results.py
python build_report.py
```

All commands work from another current directory as well when given the full
script path. Results are written beside these scripts. No source manuscript or
reference program is overwritten.

For an individual expression:

```
python evaluate.py H53 --vertices a b u --weights 1 1 1
python evaluate.py H21 --list
python evaluate.py H53 --vertices a b u --weights 0 1 2 --symbolic
```

The parameter order is printed as `color_pattern`. It is the canonical order of
first appearance of used colors in the signed terms, rather than necessarily the
anchor's global palette order. `coloring_references` maps each canonical used
color back to each corresponding normalized global coloring. Palette
permutations and unused palette values are thereby covered without duplication.

## Verified state enumerator

`tkadlec_states.py` is a small, standalone state-enumeration module using only the
Python standard library. It implements Josef Tkadlec's block-recursion method:
exactly one true atom per complete block and at most one per proper subblock.

```
python tkadlec_states.py results/pascal-inputs/H53.txt -o H53-states.json
```

The old program's input format is supported. The new command writes JSON to
stdout or the explicitly named output, and never rewrites the input. It removes
the fixed atom/block/state array limits and correctly enumerates declared atoms
not present in any (sub)block. Such unused atoms do not occur in the manuscript.
Unlike the original full program, this small module does not perform the
heuristic separation and order-determination tests; none of those tests is
needed for the classical envelopes.

The supplied full Python translation is retained as `reference/2states-original.py`,
and the original Pascal source as `reference/2states.pas`. The translation's state
generation agrees exactly on all 19 configurations and on 240 small problems
also checked by brute force. The Pascal executable could not launch on the host;
the audit does not claim a Pascal execution. The full reference Python command
has the old input-overwriting behavior, so use working copies if running it.

## Interpretation and scope

For each signed expression and color pattern, `coefficients_all` stores all
distinct integer vectors obtained from all two-valued states. The sharp classical
bounds are their minimum and maximum dot products with the real color values.
`coefficients_extendable` gives the corresponding envelopes for the extendable
states. This is exact for every real parameter assignment, including negative,
repeated and zero values.

The quantum operator uses the same signed coefficients multiplying the rank-one
projections of the specified FOR. Its smallest/largest eigenvalues give the
sharp quantum endpoints. The exact ray formulas are in configurations.py; optional
symbolic evaluation reconstructs the exact operator and characteristic equation.
The state sets and exact classical bounds depend on the hypergraph, whereas the
quantum bounds depend on the chosen FOR as well.

Every exact classical facet and both signs of every affine equality are tested.
Thus all real color directions are covered for the existence of a separation,
within the listed expression family and chosen FOR. Working spectra use float64
after 60-digit ray evaluation; all 100,495 comparisons, over 20,527 distinct
operators, were independently rechecked at 80 decimal digits. Strict gaps must
exceed 1e-9. Counts are numerical spectral classifications with exact classical
envelopes, not an optimization of gap magnitude or an optimization over FORs.
Different counted expressions can overlap or be linearly dependent; these
counts are not numbers of independent contextuality proofs.

There is one corrected census entry: the complex octagon has 20 qualifying
size-three affine pairs, not zero. All other relation counts and all state/coloring
counts agree with the pre-audit manuscript. The original manuscript verifier
independently returns the same count of 20.

## Files

- `configuration-comparison.csv`: counts for each configuration.
- `representative-comparison.csv`: one unit-weight comparison per configuration.
- `unit-comparison.csv`: all 3,270 target expressions and both endpoint gaps.
- `weighted-witnesses.csv`: separating parameter choices and bounds.
- `<configuration>.json`: complete states, colorings, relations, color patterns,
  exact envelopes, facet/equality tests, and maximizing quantum witnesses.
- `pascal-inputs/`: dense legacy-format inputs including all states and explicit
  dense-to-manuscript vertex-label maps.
- `translation-audit.json`: enumeration audit and its precise scope.
- `high-precision-verification.json`: exact facet and spectral verification.

Files in this list are under results/. Intermediate Python bytecode caches are
not part of the distributed archive.
