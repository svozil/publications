"""Classical support functions, spectral comparisons, and census relations."""
import itertools
import math
from functools import lru_cache
import numpy as np
import sympy as sp
from scipy.spatial import ConvexHull
from tkadlec_states import vertex_key

TOL=1e-9

def colorings(contexts,V,d):
    index={v:i for i,v in enumerate(V)}
    adj=[set() for _ in V]
    for e in contexts:
        for v in e:adj[index[v]].update(index[w] for w in e if w!=v)
    assigned={index[v]:j for j,v in enumerate(contexts[0])};result=[]
    def visit():
        if len(assigned)==len(V):
            result.append(tuple(assigned[i] for i in range(len(V))));return
        candidates=[]
        for i in range(len(V)):
            if i in assigned:continue
            allowed=set(range(d))-{assigned[j] for j in adj[i] if j in assigned}
            if not allowed:return
            candidates.append((len(allowed),-len(adj[i]),i,allowed))
        _,_,i,allowed=min(candidates,key=lambda x:x[:3])
        for c in sorted(allowed):assigned[i]=c;visit();del assigned[i]
    visit()
    return np.asarray(result,dtype=np.int8),adj

def numeric_geometry(cfg,V):
    vectors=[]
    for v in V:
        # High precision before conversion avoids cancellation in algebraic rays.
        raw=np.asarray([complex(x.evalf(60)) for x in cfg.rays[v]],dtype=complex)
        vectors.append(raw/np.linalg.norm(raw))
    Q=np.asarray(vectors)
    projectors=np.einsum('vi,vj->vij',Q,Q.conj())
    index={v:i for i,v in enumerate(V)}
    edges={tuple(sorted((index[u],index[v]))) for e in cfg.contexts for u,v in itertools.combinations(e,2)}
    G=Q.conj()@Q.T
    minimum=1.0;ortherror=0.0;maxparallel=0.0
    for i,j in itertools.combinations(range(len(V)),2):
        overlap=abs(G[i,j]);maxparallel=max(maxparallel,overlap)
        if (i,j) in edges:
            ortherror=max(ortherror,overlap)
            assert overlap<2e-12,(cfg.key,'required orthogonality',V[i],V[j],overlap)
        else:
            minimum=min(minimum,overlap)
            assert overlap>1e-10,(cfg.key,'unrecorded orthogonality',V[i],V[j],overlap)
        assert overlap<1-1e-10,(cfg.key,'parallel rays',V[i],V[j])
    for e in cfg.contexts:
        assert np.linalg.norm(projectors[[index[v] for v in e]].sum(axis=0)-np.eye(cfg.dimension))<2e-12,cfg.key
    return Q,projectors,dict(max_context_inner_product=ortherror,
                            min_nonedge_inner_product=minimum,max_distinct_ray_overlap=maxparallel)

def census_relations(V,d,contexts,colors,adj,states,ext):
    n=len(V);targets={};pairs=[]
    def add(tup,kind):
        tup=tuple(sorted(tup))
        targets.setdefault(tup,set()).add(kind)
    actual={tuple(sorted(V.index(v) for v in e)) for e in contexts}
    for e in actual:add(e,'context')
    signatures=[colors[:,i].tobytes() for i in range(n)]
    independent={2:[],3:[]}
    rainbow_pairs=[];twin_pairs=[]
    for tup in itertools.combinations(range(n),2):
        i,j=tup
        if j in adj[i]:continue
        independent[2].append(tup)
        if np.all(colors[:,i]!=colors[:,j]):rainbow_pairs.append(tup);add(tup,'rainbow_pair')
        if signatures[i]==signatures[j]:twin_pairs.append(tup);add(tup,'twin')
    groups={}
    for i,sig in enumerate(signatures):groups.setdefault(sig,[]).append(i)
    for group in groups.values():
        for k in range(3,len(group)+1):
            for tup in itertools.combinations(group,k):add(tup,'twin_class')
    complete=[];partial=[];tvs_complete=[];tvs_partial=[]
    for tup in itertools.combinations(range(n),d):
        if tup in actual:continue
        if all(np.all(colors[:,i]!=colors[:,j]) for i,j in itertools.combinations(tup,2)):
            partial.append(tup)
            is_independent=all(j not in adj[i] for i,j in itertools.combinations(tup,2))
            add(tup,'chromatic_admissible' if is_independent else 'partial_rainbow')
            if is_independent:complete.append(tup)
            if np.all(states[:,tup].sum(axis=1)==1):
                tvs_partial.append(tup);add(tup,'two_valued_complete')
                if is_independent:tvs_complete.append(tup)
    complete_set=set(complete)
    for tup in itertools.combinations(range(n),3):
        if all(j not in adj[i] for i,j in itertools.combinations(tup,2)):
            independent[3].append(tup)
            if d>3 and all(np.all(colors[:,i]!=colors[:,j]) for i,j in itertools.combinations(tup,2)):
                add(tup,'rainbow_triple')
    for k in [2,3]:
        by_sum={}
        for tup in independent[k]:
            signature=np.asarray(ext[:,tup].sum(axis=1),dtype=np.uint8).tobytes()
            by_sum.setdefault(signature,[]).append(tup)
        for group in by_sum.values():
            for a,b in itertools.combinations(group,2):
                if set(a)&set(b):continue
                if k==d and a in complete_set and b in complete_set:continue
                if any(signatures[i]==signatures[j] for i in a for j in b):continue
                pairs.append((a,b));add(a,'paired_component');add(b,'paired_component')
    counts=dict(rainbow_pairs=len(rainbow_pairs),twin_pairs=len(twin_pairs),
                independent_complete=len(complete),partial_complete=len(partial)-len(complete),
                independent_two_valued=len(tvs_complete),partial_two_valued=len(tvs_partial)-len(tvs_complete),
                paired2=sum(len(a)==2 for a,b in pairs),paired3=sum(len(a)==3 for a,b in pairs))
    return targets,pairs,counts

def primitive(values):
    vals=list(map(sp.Rational,values));den=sp.ilcm(*[x.q for x in vals]) if len(vals)>1 else vals[0].q
    ints=[int(x*den) for x in vals]
    div=math.gcd(*ints)
    return tuple(x//div for x in ints) if div else tuple(ints)

@lru_cache(maxsize=None)
def exact_polytope(points):
    """Integer equalities/facets of conv(points), with exact support checks.

    Qhull only proposes facets; every returned plane is reconstructed exactly
    from integer points and verified against every enumerated classical point.
    """
    P=sp.Matrix(points);dim=P.cols
    difference=sp.Matrix([[row[j]-points[0][j] for j in range(dim)] for row in points])
    _,columns=difference.rref();rank=len(columns)
    equalities=[]
    for vector in difference.nullspace():
        a=primitive(vector)
        if next((v for v in a if v),1)<0:a=tuple(-v for v in a)
        b=sum(a[j]*points[0][j] for j in range(dim))
        equalities.append((a,int(b)))
    facets=set()
    if rank==1:
        j=columns[0]
        for sign in [-1,1]:
            a=tuple(sign if i==j else 0 for i in range(dim))
            facets.add((a,max(sum(x*y for x,y in zip(a,row)) for row in points)))
    elif rank>1:
        projected=[tuple(row[j] for j in columns) for row in points]
        hull=ConvexHull(np.asarray(projected,dtype=float))
        for simplex,equation in zip(hull.simplices,hull.equations):
            M=sp.Matrix([list(projected[i])+[1] for i in simplex])
            null=M.nullspace()
            if len(null)!=1:
                # Qhull can include zero-volume simplices when triangulating a
                # nonsimplicial four-dimensional face. Reconstruct its plane
                # from every exactly coplanar candidate, rather than that
                # degenerate simplex alone. Non-facet contacts are discarded.
                active=[i for i,row in enumerate(projected)
                        if abs(np.dot(equation[:-1],row)+equation[-1])<1e-7]
                M=sp.Matrix([list(projected[i])+[1] for i in active])
                null=M.nullspace()
                if len(null)!=1:continue
            plane=primitive(null[0]);a_small=plane[:-1];b=-plane[-1]
            values=[sum(x*y for x,y in zip(a_small,row)) for row in projected]
            if max(values)!=b:
                a_small=tuple(-x for x in a_small);b=-b;values=[-x for x in values]
            assert max(values)==b and all(x<=b for x in values)
            a=[0]*dim
            for j,c in enumerate(columns):a[c]=a_small[j]
            facets.add((tuple(a),int(b)))
    return dict(dimension=dim,affine_rank=rank,
                equalities=[dict(a=list(a),b=b) for a,b in sorted(equalities)],
                facets=[dict(a=list(a),b=b) for a,b in sorted(facets)])

def encode_complex(array):
    A=np.asarray(array)
    return dict(real=A.real.tolist(),imag=A.imag.tolist())

def signed_unit(states,terms,projectors):
    values=sum(sign*states[:,i] for i,sign in terms)
    O=sum((sign*projectors[i] for i,sign in terms),np.zeros_like(projectors[0]))
    eigenvalues,eigenvectors=np.linalg.eigh(O)
    return dict(classical_min=int(values.min()),classical_max=int(values.max()),
                quantum_min=float(eigenvalues[0]),quantum_max=float(eigenvalues[-1]),
                lower_gap=float(values.min()-eigenvalues[0]),upper_gap=float(eigenvalues[-1]-values.max()),
                violating=bool(values.min()-eigenvalues[0]>TOL or eigenvalues[-1]-values.max()>TOL),
                min_state=int(np.argmin(values)),max_state=int(np.argmax(values)),
                quantum_min_state=encode_complex(eigenvectors[:,0]),quantum_max_state=encode_complex(eigenvectors[:,-1]))

def weighted_cases(terms,colors,states,ext,projectors):
    vertices=[i for i,sgn in terms]
    patterns={}
    for row_number,row in enumerate(colors):
        rename={};pattern=[]
        for i in vertices:
            color=int(row[i])
            if color not in rename:rename[color]=len(rename)
            pattern.append(rename[color])
        key=tuple(pattern)
        patterns.setdefault(key,[]).append(dict(index=row_number,canonical_to_global=list(rename)))
    records=[]
    for pattern,colorrefs in patterns.items():
        e=max(pattern)+1
        coefficients=np.zeros((len(states),e),dtype=np.int16)
        extcoeff=np.zeros((len(ext),e),dtype=np.int16)
        basis=np.zeros((e,)+projectors[0].shape,dtype=complex)
        for (i,sign),j in zip(terms,pattern):
            coefficients[:,j]+=sign*states[:,i]
            extcoeff[:,j]+=sign*ext[:,i]
            basis[j]+=sign*projectors[i]
        allpoints=tuple(sorted(set(map(tuple,coefficients.tolist()))))
        extpoints=tuple(sorted(set(map(tuple,extcoeff.tolist()))))
        full=exact_polytope(allpoints);restricted=exact_polytope(extpoints)
        def test(poly):
            tests=[]
            directions=[(face['a'],face['b'],'facet') for face in poly['facets']]
            for eq in poly['equalities']:
                directions.extend([(eq['a'],eq['b'],'equality+'),([-x for x in eq['a']],-eq['b'],'equality-')])
            for a,b,kind in directions:
                O=np.einsum('j,jab->ab',np.asarray(a),basis)
                eigenvalues,vecs=np.linalg.eigh(O)
                gap=float(eigenvalues[-1]-b)
                norm=float(np.linalg.norm(a))
                tests.append(dict(c=a,b=b,kind=kind,quantum_min=float(eigenvalues[0]),
                                  quantum_max=float(eigenvalues[-1]),upper_gap=gap,
                                  gap_per_l2=gap/norm,violating=gap>TOL))
            best=max(tests,key=lambda t:t['gap_per_l2'])
            witness=None
            if best['violating']:
                O=np.einsum('j,jab->ab',np.asarray(best['c']),basis)
                eigs,vecs=np.linalg.eigh(O);psi=vecs[:,-1]
                witness=dict(best,quantum_state=encode_complex(psi),
                             residual=float(np.linalg.norm(O@psi-eigs[-1]*psi)),
                             norm_error=float(abs(np.vdot(psi,psi)-1)))
            return dict(tests=tests,violating=any(t['violating'] for t in tests),best_witness=witness)
        records.append(dict(color_pattern=list(pattern),coloring_references=colorrefs,
                            parameter_count=e,coefficients_all=[list(x) for x in allpoints],
                            coefficients_extendable=[list(x) for x in extpoints],
                            polytope_all=full,polytope_extendable=restricted,
                            comparison_all=test(full),comparison_extendable=test(restricted)))
    return records
