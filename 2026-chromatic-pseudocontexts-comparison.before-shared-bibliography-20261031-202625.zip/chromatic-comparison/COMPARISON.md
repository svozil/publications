# Classical and quantum comparison of all 19 configurations

The classical state sets and color coefficient envelopes are exact. Quantum values use the fixed faithful representations listed in configurations.py. Every parameterized expression is compared against both all two-valued states and the extendable subset. Both quantum endpoints are tested.

Coverage: 2289 single-set sums (including actual contexts, all complete rainbow sets, independent rainbow subsets, twin subsets, and components of all counted paired relations), 931 signed multiset-pair differences, and 50 twin differences. These give 3270 expressions and 10873 distinct restricted color patterns modulo palette permutations.

Every classical envelope is min/max of the stored integer vectors, dotted with the real color parameters. The facet/equality scan checks whether the quantum expectation image leaves that classical polytope. A positive reported gap exceeds 1e-9. Witness coefficients are not a global optimization of gap magnitude.

## Exhaustive comparison counts

| Configuration | All / extendable states | Single / paired / twin-difference expressions | Unit-weight separations, all states | Parameterized separations, all states | Parameterized separations, extendable |
|---|---:|---:|---:|---:|---:|
| $M_{15,8}$ | 24 / 24 | 16 / 4 / 0 | 0 | 0 | 0 |
| $\mathsf H_{20}$ | 26 / 26 | 54 / 21 / 0 | 0 | 0 | 0 |
| $B_{13,7}$ | 14 / 12 | 10 / 1 / 0 | 1 | 1 | 1 |
| $D_{16,9}$ | 21 / 14 | 10 / 0 / 0 | 0 | 0 | 1 |
| $I_{16,9}$ | 22 / 12 | 37 / 5 / 2 | 13 | 13 | 26 |
| $H_{17,10}$ | 18 / 10 | 44 / 5 / 2 | 13 | 13 | 32 |
| $T_{19,11}$ | 25 / 14 | 31 / 3 / 2 | 2 | 2 | 17 |
| $H_{20,12}$ | 25 / 10 | 110 / 32 / 4 | 21 | 38 | 117 |
| $H_{21,13}$ | 21 / 6 | 199 / 36 / 21 | 30 | 45 | 207 |
| $G_{27,16}$ | 82 / 54 | 74 / 14 / 2 | 42 | 46 | 50 |
| $G_{41,25}$ | 396 / 216 | 173 / 39 / 6 | 120 | 139 | 146 |
| $G_{41,26}$ | 107 / 63 | 571 / 318 / 6 | 186 | 484 | 620 |
| $H_{53,34}$ | 224 / 128 | 841 / 428 / 4 | 227 | 656 | 844 |
| $R_{21,12}$ | 54 / 48 | 33 / 12 / 0 | 0 | 0 | 0 |
| $R_{25,15}$ | 81 / 48 | 36 / 12 / 0 | 0 | 0 | 0 |
| $B_{14,7}^{(4)}$ | 15 / 13 | 10 / 1 / 0 | 1 | 1 | 1 |
| $D_{17,9}^{(4)}$ | 22 / 15 | 10 / 0 / 0 | 0 | 0 | 1 |
| $L_{18,7}^{(4)}$ | 68 / 68 | 8 / 0 / 0 | 1 | 1 | 1 |
| $L_{22,9}^{(4)}$ | 158 / 92 | 22 / 0 / 1 | 6 | 6 | 13 |

Counts are expressions admitting a separating direction, not independent contextuality proofs. Actual contexts are included as consistency checks. Parameterized counts include all canonical color patterns for each expression. Zero means no separation in the complete facet/equality scan for the listed expressions and chosen FOR; it does not rule out other observables or representations.

## Representative unit-weight comparisons

This table chooses one target per configuration; the CSV/JSON files contain every expression, not only these representatives.

| Configuration | Target | Classical, all states | Classical, extendable | Quantum interval | Separation from all states |
|---|---|---|---|---|---|
| $M_{15,8}$ | `{1,6,11}` | [0,2] | [0,2] | [0.17267316,2.00000000] | none |
| $\mathsf H_{20}$ | `{a1,a2}` | [0,2] | [0,2] | [0.00000000,1.55377492] | none |
| $B_{13,7}$ | `{10,11}` | [0,1] | [0,1] | [0.00000000,1.33333333] | upper |
| $D_{16,9}$ | `{14,18}` | [0,2] | [0,1] | [0.00000000,1.08888889] | none |
| $I_{16,9}$ | `{10,11}` | [0,1] | [0,1] | [0.00000000,1.27216553] | upper |
| $H_{17,10}$ | `{10,11}` | [0,1] | [0,1] | [0.00000000,1.33333333] | upper |
| $T_{19,11}$ | `{9,26}` | [0,1] | [0,1] | [0.00000000,1.25241492] | upper |
| $H_{20,12}$ | `{15,18,20}` | [1,3] | [1,1] | [0.72960967,1.23483806] | lower |
| $H_{21,13}$ | `{10,11,13}` | [0,1] | [1,1] | [0.33333333,1.33333333] | upper |
| $G_{27,16}$ | `{3,14,18}` | [1,1] | [1,1] | [0.79469070,1.20530930] | both |
| $G_{41,25}$ | `{3,27,28}` | [1,1] | [1,1] | [0.79852694,1.21074603] | both |
| $G_{41,26}$ | `{3,27,28}` | [1,1] | [1,1] | [0.68238324,1.35933946] | both |
| $H_{53,34}$ | `{a,b,u}` | [1,1] | [1,1] | [0.57095612,1.51652083] | both |
| $R_{21,12}$ | `{1,17,18}` | [0,3] | [0,3] | [0.50000000,1.76234754] | none |
| $R_{25,15}$ | `{1,17,18}` | [0,3] | [0,3] | [0.50000000,1.76234754] | none |
| $B_{14,7}^{(4)}$ | `{10,11}` | [0,1] | [0,1] | [0.00000000,1.33333333] | upper |
| $D_{17,9}^{(4)}$ | `{14,18}` | [0,2] | [0,1] | [0.00000000,1.08888889] | none |
| $L_{18,7}^{(4)}$ | `{11,15}` | [0,1] | [0,1] | [0.00000000,1.15430335] | upper |
| $L_{22,9}^{(4)}$ | `{19,20,21,22}` | [1,2] | [1,1] | [0.84569665,1.15430335] | lower |

## Exact parameter envelopes for the representative targets

For each row below, L is a finite list of linear expressions. The exact classical interval is [min L, max L] for arbitrary real parameters. The selected color pattern is canonical; all other patterns are retained in the per-configuration JSON.

- **M15 {1,6,11}**, colors [0, 1, 2]: L = {0, c_2, c_1, c_1+c_2, c_0, c_0+c_2, c_0+c_1}. The extendable envelope is the same.
- **Oct20 {a1,a2}**, colors [0, 1]: L = {0, c_1, c_0, c_0+c_1}. The extendable envelope is the same.
- **B13 {10,11}**, colors [0, 1]: L = {0, c_1, c_0}. The extendable envelope is the same.
- **D16 {14,18}**, colors [0, 1]: L = {0, c_1, c_0, c_0+c_1}. For extendable states L = {0, c_1, c_0}.
- **I16 {10,11}**, colors [0, 1]: L = {0, c_1, c_0}. The extendable envelope is the same.
- **H17 {10,11}**, colors [0, 1]: L = {0, c_1, c_0}. The extendable envelope is the same.
- **T19 {9,26}**, colors [0, 1]: L = {0, c_1, c_0}. The extendable envelope is the same.
- **H20 {15,18,20}**, colors [0, 1, 2]: L = {c_2, c_1, c_1+c_2, c_0, c_0+c_2, c_0+c_1, c_0+c_1+c_2}. For extendable states L = {c_2, c_1, c_0}.
- **H21 {10,11,13}**, colors [0, 1, 2]: L = {0, c_2, c_1, c_0}. For extendable states L = {c_2, c_1, c_0}.
- **G27 {3,14,18}**, colors [0, 1, 2]: L = {c_2, c_1, c_0}. The extendable envelope is the same.
- **G41_25 {3,27,28}**, colors [0, 1, 2]: L = {c_2, c_1, c_0}. The extendable envelope is the same.
- **G41_26 {3,27,28}**, colors [0, 1, 2]: L = {c_2, c_1, c_0}. The extendable envelope is the same.
- **H53 {a,b,u}**, colors [0, 1, 2]: L = {c_2, c_1, c_0}. The extendable envelope is the same.
- **R21 {1,17,18}**, colors [0, 1, 2]: L = {0, c_2, c_1, c_1+c_2, c_0, c_0+c_2, c_0+c_1, c_0+c_1+c_2}. The extendable envelope is the same.
- **R25 {1,17,18}**, colors [0, 1, 2]: L = {0, c_2, c_1, c_1+c_2, c_0, c_0+c_2, c_0+c_1, c_0+c_1+c_2}. The extendable envelope is the same.
- **B14 {10,11}**, colors [0, 1]: L = {0, c_1, c_0}. The extendable envelope is the same.
- **D17 {14,18}**, colors [0, 1]: L = {0, c_1, c_0, c_0+c_1}. For extendable states L = {0, c_1, c_0}.
- **L18 {11,15}**, colors [0, 1]: L = {0, c_1, c_0}. The extendable envelope is the same.
- **L22 {19,20,21,22}**, colors [0, 1, 2, 3]: L = {c_3, c_2, c_1, c_1+c_3, c_1+c_2, c_0}. For extendable states L = {c_3, c_2, c_1, c_0}.

## Compact witnesses highlighted in the article

Every classical constraint below holds for convex mixtures of all admissible two-valued states. The quantum values use the printed FORs and suitable state preparations.

| Configuration | Classical constraint | Quantum violation |
|---|---|---|
| H53 | p(u) - p(y5) + p(y9) <= 1 | Maximum 1.545525795; weights (1,-1,1) |
| H53 | p(a) + p(b) + p(u) = 1 | Quantum interval [0.57095612,1.51652083] |
| H20 | p(15) + p(18) + p(20) >= 1 | Minimum 0.72960967 |
| H21 | p(10) + p(11) + p(13) <= 1 | Maximum 4/3 |
| G41_26 | p(11) = p(18) | Maximal absolute difference 1/3 |
| L22 | p(11) - p(20) <= 0 | Maximum 1/sqrt(42) |

The weighted H53 witness is relation X0646, restricted color pattern 2. Its binary implication is u AND y9 implies y5. The projected patterns are 000,001,010,100,110,111; the inequality is a facet of that three-dimensional polytope. A maximizing state is approximately (-0.04240376,0.92996020,-0.36520672). The article now gives a structural implication proof as well as the spectral calculation.

For G41_26, the exact preparation (1,-1,0)/sqrt(2) gives p(11)=2/3 and p(18)=1/3. For H21 the same coordinate vector gives hub probabilities (2/3,2/3,0). In L22, preparing ray 11 gives p(11)=1 and p(20)=41/42, already violating the classical order inequality by 1/42.

These witnesses are state-dependent. The maximally mixed probabilities p(v)=1/d are reproduced by equally mixing the d column states of any strong d-coloring, so neither classical state family is separated from every quantum state by a linear ray-probability inequality.

## Census correction

The complex octagon has 20 independent, disjoint, non-twin color-multiset-equivalent pairs of size three, in addition to its one size-two pair. The pre-audit census listed zero in the size-three column. Both the old manuscript verifier and this independent enumeration return 20. Every pair is listed in Oct20.json. All other census entries and all state/coloring counts agree.

## Reproduction

Run `python audit_translation.py`, `python run_comparison.py`, and `python verify_results.py`; then `python build_report.py` regenerates this report. Run `python evaluate.py H53 --vertices a b u --weights 1 1 1` to evaluate arbitrary coefficients on a chosen expression. `--list` shows available expressions, and `--symbolic` constructs the exact operator and characteristic polynomial.

The supplied Python translation passed the enumeration audit. Its original Pascal-compatible CLI overwrites the input, so the audit used temporary files. The new tkadlec_states.py writes JSON separately and also enumerates declared atoms absent from every block; the original Pascal and its old Python translation silently fix such unused atoms to zero. All 19 manuscript configurations use every declared atom.

The legacy Pascal executable could not run on this host (Illegal System DLL Relocation). No Pascal execution or compilation is claimed. The original source and supplied full Python translation are preserved under reference/.

Full records: results/<configuration>.json; all state supports and dense Pascal-compatible labels: results/pascal-inputs/; every unit expression: unit-comparison.csv; separating parameter choices and gaps: weighted-witnesses.csv; audit and numerical verification: translation-audit.json and high-precision-verification.json.
