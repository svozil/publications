#!/usr/bin/env python3
#coding: utf-8

#           gpt-5-high-new-system-prompt:
#           Awesome, thanks for the dump. Here�s what the Pascal program does, in plain terms, and then a faithful, idiomatic Python port that preserves behavior, file format, and the command-line option.
#
#           High-level analysis
#           - The structure: You have a finite set of atoms (1..na). Orthogonal sets are given as blocks (complete) and subblocks (proper subsets of blocks).
#           - Elements are sums of atoms from orthogonal sets. States (aka 2-valued evaluations) assign each atom 0 or 1 such that:
#             - For every complete block, exactly one atom has value 1.
#             - For every proper subblock, at most one atom has value 1.
#           - If -s is not used, the program computes all 2-valued states consistent with the constraints. If -s is used, it reads states from the file and validates them.
#           - It then tests properties of the set of states:
#             - Unital: each atom is 1 in at least one state.
#             - Separating on atoms: for every pair of distinct atoms, some state assigns different values.
#             - Separating (elements): for different elements (represented by subsets of atoms inside blocks), some state gives different sums.
#             - �1s on nonorthogonal atoms�: for any nonorthogonal pair a,b, some state has 1 on both. If no proper subblocks exist, this equals order-determining.
#             - Order determining (approximate check via the block/coatom heuristic used in the Pascal code).
#           - Input file default: 2states.txt. Error file: 2states.err. Output is written back to the same input filename, just like the Pascal code.
#
#           Python translation (drop-in CLI)
#           - Run: python two_states.py [-s] [filename]
#           - Default filename is 2states.txt; error file is 2states.err.
#           - It writes output back into filename (overwriting), and deletes the error file if no errors were written.
#
#           Code:
#           ```python
#
#           Notes
#           - I preserved the original logic closely, including the �coatom complement� heuristics for Same/Ordered and the subset enumeration to test separating and order-determining properties.
#           - The generation algorithm matches the Pascal recursion and reorders blocks to assign already-seen atoms first for consistency with the original.
#           - The file format and output text match the Pascal program�s structure (including the states dump and the subsequent report).
#           - The -s option switches from �compute states� to �read states and validate them,� just like in the Pascal.
#           - Limits (MaxAtoms, MaxBlocks, MaxHeight, MaxStates, MaxPairs) and the error behavior are honored; an empty error file is deleted at the end.
#
#           If you want this to use stdin/stdout instead of rewriting the input file, or to accept JSON instead of the Pascal-ish flat file, I can tweak it.
#
#
import os
import re
import sys
from typing import List, Set, Tuple

NAME_PRG = "2states"
NAME_ERR = NAME_PRG + ".err"
NAMEI = NAME_PRG + ".txt"

MaxAtoms = 100
MaxBlocks = 100
MaxHeight = 5
MaxStates = 999
MaxPairs = 999

IntSet = Set[int]


class TwoStates:
    def __init__(self, readstates: bool, name1: str, errname: str = NAME_ERR):
        self.readstates = readstates
        self.name1 = name1
        self.errname = errname

        # File handles
        self.f_out = None
        self.f_err = open(self.errname, "w", encoding="utf-8")

        # Global state mirroring Pascal
        self.line = 0
        self.descr = ""
        self.na = 0
        self.nb = 0
        self.nc = 0
        self.nd = 0
        self.ns = 0
        self.np = 0
        self.height = 1

        # blocks[b] = list of atoms in block b (1-based indexing on b)
        self.blocks: List[List[int]] = [None]  # index 0 unused
        # blockss[b] = set of atoms in block b
        self.blockss: List[IntSet] = [set()]
        # blockso: reordered block atoms with previously-used-first
        # blockso[b] = dict(atoms=[...], num_atoms=int, num_used_prev=int)
        self.blockso: List[dict] = [None]

        # states[s][a] = 0/1, with s in 1..ns and a in 1..na
        # states[0] is scratch row for generation
        self.states: List[List[int]] = []

        # for avoiding duplicate pair reports when testing
        self.pairs: List[Tuple[IntSet, IntSet]] = []
        # suspicion counter for duplicates
        self.np = 0

        # For NonOrtho test
        self.NonOrtho: List[List[bool]] = []

        # flags used during checks
        self.found = False
        self.testsep = False

    def close_err_and_maybe_delete(self):
        try:
            self.f_err.close()
            if os.path.exists(self.errname) and os.stat(self.errname).st_size == 0:
                os.remove(self.errname)
        except Exception:
            pass

    def halt(self, msg: str = ""):
        if msg:
            self.writeln_err(msg)
        self.f_err.close()
        sys.exit(1)

    def write_err(self, s: str):
        self.f_err.write(f"line {self.line:2}: {s}")

    def writeln_err(self, s: str):
        self.f_err.write(f"line {self.line:2}: {s}\n")

    # Reading helpers

    @staticmethod
    def first_int_on_line(line: str):
        m = re.search(r"[-+]?\d+", line)
        if not m:
            return None
        return int(m.group(0))

    @staticmethod
    def ints_on_line(line: str) -> List[int]:
        return list(map(int, re.findall(r"[-+]?\d+", line)))

    def read_input(self):
        try:
            with open(self.name1, "r", encoding="utf-8") as fin:
                lines = fin.readlines()
        except OSError:
            self.halt(f'file "{self.name1}" cannot be opened')

        it = iter(lines)

        def next_line():
            try:
                s = next(it)
            except StopIteration:
                self.halt("unexpected end of file")
            self.line += 1
            return s.rstrip("\n")

        # line 1: description
        self.descr = next_line()

        # line 2: number of atoms
        self.na = self._read_int_line_limited(next_line(), 1, MaxAtoms, "number of atoms", "MaxAtoms")

        # line 3: number of blocks
        self.nb = self._read_int_line_limited(next_line(), 0, MaxBlocks, "number of blocks", "MaxBlocks")

        # line 4: number of proper subblocks
        self.nc = self._read_int_line_limited(next_line(), 0, MaxBlocks, "number of subblocks", "MaxBlocks")

        self.nd = self.nb + self.nc
        if self.nd > MaxBlocks:
            self.write_err(f"incrase MaxBlocks to {self.nd}")
            self.halt("")

        # read the (sub)blocks
        self.blocks = [None]
        self.blockss = [set()]
        self.height = 1
        for b in range(1, self.nd + 1):
            line = next_line()
            ints = self.ints_on_line(line)
            if not ints:
                self.write_err("empty block line")
                self.halt("")
            k = self._limit_checked(ints[0], 1, MaxHeight, "number of atoms in a (sub)block", "MaxHeight")
            if len(ints) - 1 < k:
                self.write_err("not enough atom indices in a block line")
                self.halt("")
            atoms = ints[1:1 + k]
            for a in atoms:
                self._limit_checked(a, 1, self.na, "number of an atom", "number of atoms")
            self.blocks.append(atoms)
            self.blockss.append(set(atoms))
            # track height
            if b <= self.nb:
                self.height = max(self.height, k)
            else:
                self.height = max(self.height, k + 1)

        # Maybe read states
        self.states = []
        if self.readstates:
            # line: number of states
            line = next_line()
            self.ns = self._read_int_line_limited(line, 0, MaxStates, "number of states", "MaxStates")

            # next ns lines: each has na integers (0/1)
            # We'll accept surplus numbers but require at least na per line
            # build 1-based storage with dummy row 0
            self.states = [None]
            for s in range(1, self.ns + 1):
                line = next_line()
                vals = self.ints_on_line(line)
                if len(vals) < self.na:
                    self.write_err("not enough values of a state")
                    self.halt("")
                row = [0] + [self._limit_checked(vals[i], 0, 1, "value of a state", "") for i in range(self.na)]
                self.states.append(row)
                if not self.is_state(s):
                    self.halt("not evaluation")
        else:
            # we will compute states later; create scratch row (index 0)
            self.states = [[0] * (self.na + 1)]

    def _read_int_line_limited(self, line: str, l1: int, l2: int, s1: str, s2: str) -> int:
        val = self.first_int_on_line(line)
        if val is None:
            self.write_err(f"missing {s1}")
            self.halt("")
        return self._limit_checked(val, l1, l2, s1, s2)

    def _limit_checked(self, i: int, l1: int, l2: int, s1: str, s2: str) -> int:
        if i < l1:
            self.write_err(f"small number of {s1} ({i}<{l1})")
            self.halt("")
        if i > l2:
            self.write_err(f"big number of {s1} ({i}>{l2})")
            if s2:
                self.f_err.write(f" increase {s2}")
            self.halt("")
        return i

    # State validation

    def is_state(self, s: int) -> bool:
        for i in range(1, self.nd + 1):
            total = sum(self.states[s][a] for a in self.blocks[i])
            if total > 1 or (i <= self.nb and total == 0):
                return False
        return True

    # State generation

    def rearrange_blocks(self):
        used = [False] * (self.na + 1)
        self.blockso = [None]
        for b in range(1, self.nd + 1):
            atoms = self.blocks[b]
            first = [a for a in atoms if used[a]]
            rest = [a for a in atoms if not used[a]]
            num_used_prev = len(first)
            for a in rest:
                used[a] = True
            self.blockso.append({
                "atoms": first + rest,
                "num_atoms": len(atoms),
                "num_used_prev": num_used_prev,
            })

    def find_states(self):
        self.rearrange_blocks()
        self.ns = 0
        self.states = [[0] * (self.na + 1)]  # index 0 is scratch row

        def set0_on_rest(b):
            bo = self.blockso[b]
            atoms = bo["atoms"]
            u = bo["num_used_prev"]
            for a in atoms[u:]:
                self.states[0][a] = 0

        def rec(b: int):
            if b > self.nd:
                self.ns += 1
                if self.ns > MaxStates:
                    self.write_err("increase MaxStates")
                    self.halt("")
                self.states.append(self.states[0].copy())
                return
            bo = self.blockso[b]
            atoms = bo["atoms"]
            u = bo["num_used_prev"]
            num_atoms = bo["num_atoms"]

            s = sum(self.states[0][a] for a in atoms[:u])
            if s > 1:
                return
            if s == 0:
                # try putting 1 on one of the not-yet-used atoms
                for a in atoms[u:]:
                    set0_on_rest(b)
                    self.states[0][a] = 1
                    rec(b + 1)
                # if subblock (b > nb), also allow leaving it at 0
                if b > self.nb:
                    set0_on_rest(b)
                    rec(b + 1)
            else:
                set0_on_rest(b)
                rec(b + 1)

        rec(1)

    # Output

    def write_data(self):
        try:
            self.f_out = open(self.name1, "w", encoding="utf-8")
        except OSError:
            self.halt(f'file "{self.name1}" cannot be written')

        f = self.f_out
        f.write(self.descr + "\n")
        f.write(f"{self.na:2} atoms\n")
        f.write(f"{self.nb:2} blocks\n")
        f.write(f"{self.nc:2} proper subsets of blocks\n")
        for b in range(1, self.nd + 1):
            atoms = self.blocks[b]
            f.write(f"{len(atoms):2} ")
            for a in atoms:
                f.write(f" {a:2}")
            f.write("\n")
        f.write(f"{self.ns} 2-valued evaluations of atoms:\n")
        for s in range(1, self.ns + 1):
            for a in range(1, self.na + 1):
                f.write(f"{self.states[s][a]} ")
            f.write("\n")

    # Printing helpers

    def write_set(self, sset: IntSet):
        # print atoms in ascending order separated by '+'
        xs = [str(a) for a in range(1, self.na + 1) if a in sset]
        self.f_out.write("+".join(xs))

    # Property checks

    def unital(self) -> bool:
        f = self.f_out
        f.write("unital: ")
        self.found = False
        for a in range(1, self.na + 1):
            s = 1
            while s <= self.ns and self.states[s][a] == 0:
                s += 1
            if s > self.ns:
                if not self.found:
                    self.found = True
                    f.write("no for atoms")
                f.write(f" {a}")
        f.write("\n" if self.found else "yes\n")
        return not self.found

    def separating_atoms(self) -> bool:
        f = self.f_out
        f.write("separating atoms: ")
        self.found = False
        for a in range(1, self.na):
            for aa in range(a + 1, self.na + 1):
                s = 1
                while s <= self.ns and self.states[s][a] == self.states[s][aa]:
                    s += 1
                if s > self.ns:
                    if not self.found:
                        f.write("no for pairs")
                        self.found = True
                    f.write(f" {a}/{aa}")
        f.write("\n" if self.found else "yes\n")
        return not self.found

    def same(self, set1: IntSet, set2: IntSet) -> bool:
        # quick check
        if set1 == set2:
            return True
        # Try coatom complements inside complete blocks (b <= nb)
        for b1 in range(1, self.nb + 1):
            if set1 <= self.blockss[b1]:
                for b2 in range(1, self.nb + 1):
                    if set2 <= self.blockss[b2]:
                        if (self.blockss[b2] - set2) == (self.blockss[b1] - set1):
                            return True
        return False

    def ordered(self, set1: IntSet, set2: IntSet) -> bool:
        if set1 <= set2:
            return True
        for b1 in range(1, self.nd + 1):
            if set1 <= self.blockss[b1]:
                for b2 in range(1, self.nb + 1):
                    if set2 <= self.blockss[b2]:
                        if (self.blockss[b2] - set2) <= (self.blockss[b1] - set1):
                            return True
        return False

    def not_found_pair(self, set1: IntSet, set2: IntSet) -> bool:
        # avoid duplicates using "same" equivalence
        for i in range(len(self.pairs)):
            p1, p2 = self.pairs[i]
            if self.same(p1, set1) and self.same(p2, set2):
                return False
        if len(self.pairs) >= MaxPairs:
            self.f_err.write("increase MaxPairs for check duplicities\n")
        else:
            self.pairs.append((set1, set2))
        return True

    def test_sets_sep(self, set1: IntSet, set2: IntSet):
        if self.same(set1, set2):
            return
        for s in range(1, self.ns + 1):
            sum1 = sum(self.states[s][a] for a in set1)
            sum2 = sum(self.states[s][a] for a in set2)
            if sum1 != sum2:
                return
        if not self.found:
            self.found = True
            self.f_out.write("no for sets of atoms (different elements?)\n")
        if self.not_found_pair(set1, set2) and self.not_found_pair(set2, set1):
            self.f_out.write(" ")
            self.write_set(set1)
            self.f_out.write("/")
            self.write_set(set2)
            self.f_out.write("\n")

    def test_sets_od(self, set1: IntSet, set2: IntSet):
        if self.ordered(set1, set2):
            return
        for s in range(1, self.ns + 1):
            sum1 = sum(self.states[s][a] for a in set1)
            sum2 = sum(self.states[s][a] for a in set2)
            if sum1 > sum2:
                return
        if not self.found:
            self.found = True
            self.f_out.write("no for sets of atoms (ordered elements?)\n")
        if self.not_found_pair(set1, set2):
            self.f_out.write(" ")
            self.write_set(set1)
            self.f_out.write("/")
            self.write_set(set2)
            self.f_out.write("\n")

    def find_set2(self, b1: int, b2: int, i: int, set1: IntSet, set2: IntSet):
        # generate all subsets of block b2
        atoms = self.blocks[b2]
        if i <= len(atoms):
            a = atoms[i - 1]
            self.find_set2(b1, b2, i + 1, set1, set2)
            self.find_set2(b1, b2, i + 1, set1, set2 | {a})
        else:
            if self.testsep:
                self.test_sets_sep(set1, set2)
            else:
                self.test_sets_od(set1, set2)
                self.test_sets_od(set2, set1)

    def find_set1(self, b1: int, i: int, set1: IntSet):
        # generate all subsets of block b1; then pair with all subsets of later blocks
        atoms = self.blocks[b1]
        if i <= len(atoms):
            a = atoms[i - 1]
            self.find_set1(b1, i + 1, set1)
            self.find_set1(b1, i + 1, set1 | {a})
        else:
            for b2 in range(b1 + 1, self.nd + 1):
                self.find_set2(b1, b2, 1, set1, set())

    def separating(self) -> bool:
        f = self.f_out
        f.write("separating: ")
        self.testsep = True
        self.found = False
        self.pairs = []
        for b1 in range(1, self.nd):
            self.find_set1(b1, 1, set())
        # no complete block -> add ad-hoc check with top
        if self.nb == 0:
            for a in range(1, self.na + 1):
                s = 1
                while s <= self.ns and self.states[s][a] == 1:
                    s += 1
                if s > self.ns:
                    if not self.found:
                        self.found = True
                        f.write("no for sets of atoms\n")
                    f.write(f" {a}/top\n")
        f.write("\n" if self.found else "yes\n")
        return not self.found

    def order_determining(self) -> bool:
        f = self.f_out
        f.write("order determining: ")
        self.testsep = False
        self.found = False
        self.pairs = []
        for b1 in range(1, self.nd):
            self.find_set1(b1, 1, set())
        f.write("\n" if self.found else "yes\n")
        return not self.found

    def order_determining_a(self) -> bool:
        # 1s on nonorthogonal atoms
        self.NonOrtho = [[True] * (self.na + 1) for _ in range(self.na + 1)]
        for b in range(1, self.nd + 1):
            atoms = self.blocks[b]
            for i in range(len(atoms)):
                for j in range(i + 1, len(atoms)):
                    a = atoms[i]
                    aa = atoms[j]
                    self.NonOrtho[a][aa] = False
                    self.NonOrtho[aa][a] = False

        f = self.f_out
        self.found = False
        f.write("1s on nonorthogonal atoms (=OD if no noncomplete block): ")
        for a in range(1, self.na + 1):
            for aa in range(a, self.na + 1):
                if self.NonOrtho[a][aa]:
                    s = 1
                    while s <= self.ns and not (self.states[s][a] == 1 and self.states[s][aa] == 1):
                        s += 1
                    if s > self.ns:
                        if not self.found:
                            self.found = True
                            f.write("no for atoms\n")
                        f.write(f" {a}/{aa}")
        f.write("\n" if self.found else "yes\n")
        return not self.found

    def check_set_of_states(self):
        f = self.f_out
        f.write("\nset of 2-valued evaluations of atoms:\n")
        f.write("nonempty: ")
        if self.ns > 0:
            f.write("yes\n")
        else:
            f.write("no\n")
            return
        if not self.unital():
            return
        if not self.separating_atoms():
            return
        if not self.separating():
            return
        self.order_determining_a()
        self.order_determining()

    def run(self):
        # read
        self.read_input()
        # compute states if needed
        if not self.readstates:
            self.find_states()
        # write data and checks
        self.write_data()
        self.check_set_of_states()
        self.f_out.close()
        self.close_err_and_maybe_delete()


def parse_args(argv: List[str]) -> Tuple[bool, str]:
    # Options can be on either side, unknown options are warned about (in err file in Pascal,
    # but here we keep it simple and print to stderr).
    readstates = False
    name1 = NAMEI
    no_opt_args = []
    unknown_opts = []

    for a in argv[1:]:
        if a.startswith("-"):
            if a == "-s":
                readstates = True
            else:
                unknown_opts.append(a)
        else:
            no_opt_args.append(a)

    if len(no_opt_args) >= 1:
        name1 = no_opt_args[0]
    if len(no_opt_args) > 1:
        # Mimic Pascal: ignore extras but note it
        sys.stderr.write("extra no-option parameter(s) omitted\n")
    if unknown_opts:
        sys.stderr.write("ignored unknown program option(s): " + " ".join(unknown_opts) + "\n")

    return readstates, name1


if __name__ == "__main__":
    readstates, name1 = parse_args(sys.argv)
    prog = TwoStates(readstates=readstates, name1=name1)
    try:
        prog.run()
    except SystemExit:
        raise
    except Exception as e:
        # Fail-safe: mimic a hard stop
        prog.writeln_err(f"internal error: {e}")
        prog.close_err_and_maybe_delete()
        raise
