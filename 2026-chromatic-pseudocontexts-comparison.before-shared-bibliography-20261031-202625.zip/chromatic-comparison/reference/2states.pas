(*

Pascal, Josef Tkadlec

Considered quantum structures are given by a nonempty finite set of atoms
(at most 255) and sets of orthogonal atoms - either blocks (maximal sets of
orthogonal atoms) or proper subsets of blocks. The elements are sums of
atoms in an orthogonal set (including the least element - sum of an empty
set of atoms) and the greatest element (which is the sum of all atoms in
every block).

Implicitely finds (might be changed to read) 2-valued evaluations of atoms
(gives 2-valued states) - values in {0,1}, sum over every blok is 1, over
every proper subset of a block is <=1.

Tests, whether the set of evaluations is
  unital (for each atom there is an evaluation with value 1),
  separating on atoms (for different atoms ev. with different values)
  separating (for different elements there is an ev. with different values),
  "order determining" (for nonorthogonal atoms an ev. with 1 on both)
    = order determining if there is no proper subset of a block
  order determining (if not a<=b then there is an s such that not s(a)<=s(b))

Input/output file (implicitely "namei") has the structure:
  line 1:  description
  line 2:  number "na" of atoms, anything (will be enumerated 1,2,...)
  line 3:  number "nb" of defined blocks, anything
  line 4:  number "nc" of defined proper subblocks, anything
  next nb: each line: number of atoms and atoms in a block
  next nc: each line: number of atoms and atoms in a proper subblock
  next:    number "ns" of 2-valued evaluations of atoms
  next ns: each line: values of an evaluation an atoms
  next:    in input omitted, in the output results

usage:
  2states [option] [filename] [option]
options: -s : do not find evaluations but read them from the input file

Versions:
25. 6.2009 1st

Remarks:
* Maximum possible number of atoms is 255.
* The check of same/ordered elements need not be complete (same: same sets
  of atoms or same sets of coatoms in blocks; ordered: same, sets of atoms
  or coatoms in a block are properly ordered), hence in testing separating
  and order determining property there are only suspicions. (Order
  determining property is completely verified if no non-complete block is
  given trying nonorthogonal atoms.)

*)

uses dos;

const NamePrg   = '2states';      {program name}
      NameErr   = NamePrg+'.err'; {name of the error file}
      namei     = NamePrg+'.txt'; {implicit name of the input/output file}
      MaxAtoms  = 100;            {maximum number of atoms - cannot >255}
      MaxBlocks = 100;            {maximum number of blocks+subblocks}
      MaxHeight =   5;            {maximal number of atoms in a (sub)block}
      MaxStates = 999;            {maximum number of states}
      MaxPairs  = 999;            {maximal number of pairs of tested sets}

type setI = set of byte;

var readstates:Boolean; {whether read states}
    found     :Boolean; {whether found an counterexample}
    testsep   :Boolean; {whether test separating/order determining}
    name1     :string;  {name of the input/output file}
    descr     :string;  {description of an example}
    line      :integer; {line of the input file}
    na        :integer; {number of atoms}
    nb        :integer; {number of blocks}
    nc        :integer; {number of proper subblocks}
    nd        :integer; {number of (sub)blocks}
    ns        :integer; {number of states}
    np        :integer; {number of pairs of tested sets}
    height    :integer; {maximal number of atoms in a block}
    blocks    :array[1..MaxBlocks,0..MaxHeight] of smallint; {number of/atoms}
    blockso   :array[1..MaxBlocks,-1..Maxheight] of smallint; {ordered}
    blockss   :array[1..MaxBlocks] of setI; {number of/atoms}
    states    :array[0..MaxStates,1..MaxAtoms] of smallint;
    pairs     :array[1..MaxPairs,1..2] of setI;
    NonOrtho  :array[1..MaxAtoms,1..MaxAtoms] of Boolean; {not orthogonal}
    f,fe      :text;    {input/output, error file}

function MaxI (x,y :integer) :integer;
{------------------------------------}
begin if x<y then MaxI:=y else MaxI:=x end;

procedure WriteErr (s :string);
{-----------------------------}
begin write(fe,'line ',line:2,': ',s) end;

procedure WritelnErr (s :string);
{-------------------------------}
begin writeln(fe,'line ',line:2,': ',s) end;

procedure Halt1 (s :string);
{==========================}
begin if s<>'' then WritelnErr(s);close(fe);halt; end;

procedure AssignRewriteErr (var f :text; name :string);
{-----------------------------------------------------}
begin
assign(f,name);{$I-}rewrite(f);{$I+}
if IOResult<>0 then
  begin writeln('file "',name,'" cannot be written');halt end;
end;

procedure AssignRewrite (var f :text; name :string);
{--------------------------------------------------}
begin
assign(f,name);{$I-}rewrite(f);{$I+}
if IOResult<>0 then Halt1('file "'+name+'" cannot be written');
end;

procedure AssignReset (var f :text; name :string);
{------------------------------------------------}
begin
assign(f,name);{$I-}reset(f);{$I+}
if IOResult<>0 then Halt1('file "'+name+'" cannot be opened');
end;

procedure EraseIfEmpty (s :string);
{---------------------------------}
var SR :SearchRec;
    f  :text;
begin
FindFirst(s,AnyFile,SR);
if DosError=0 then if SR.Size=0 then begin assign(f,s);Erase(f) end;
end;

procedure ReadI (var i :integer; l1,l2 :integer; s1,s2 :string);
{--------------------------------------------------------------}
begin
read(f,i);
if i<l1 then
  begin
  WriteErr('small number of '+s1);write(fe,' (',i,'<',l1,')');
  Halt1('');
  end;
if i>l2 then
  begin
  WriteErr('big number of '+s1);write(fe,' (',i,'>',l2,')');
  if s2<>'' then write(fe,' increase ',s2);
  Halt1('')
  end;
end;

procedure WriteSet (set0 :setI);
{==============================}
var a,i :integer;
begin
i:=0;for a:=1 to na do if a in set0 then
  begin Inc(i);if i>1 then write(f,'+');write(f,a) end;
end;

procedure Readln1;
{================}
begin readln(f);Inc(line) end;

procedure ReadProgramParameters;
{******************************} {for some options starting with -}
var i,j,n :integer;
begin
readstates:=false;name1:=namei;                               {implicit values}
n:=0;                                          {number of no-option parameters}
for i:=1 to ParamCount do
  if Copy(ParamStr(i),1,1)='-'
    then begin                                               {option parameter}
         if length(ParamStr(i))=1 then WritelnErr('empty program option') else
         if ParamStr(i)='-s' then readstates:=true else
         WritelnErr('ignored unknown program option "'+ParamStr(i)+'"');
         end
    else begin                                            {no-option parameter}
         Inc(n);case n of
           1 :name1:=ParamStr(i);
           else WritelnErr('extra no-option parameter(s) omitted');
           end;
         end;
end;

function IsState (s :integer) :Boolean;
{*************************************}
var i,j,sum :integer;
begin
IsState:=false;
for i:=1 to nd do
  begin
  sum:=0;for j:=1 to blocks[i,0] do Inc(sum,states[s,blocks[i,j]]);
  if (sum>1) or ((i<=nb) and (sum=0)) then exit;
  end;
IsState:=true;
end;

procedure ReadInput;
{******************}
var i,j,s,a :integer;
begin
readln(f,descr);Inc(line);
ReadI(na,1,MaxAtoms,'number of atoms','MaxAtoms');Readln1;
ReadI(nb,0,MaxBlocks,'number of blocks','MaxBlocks');Readln1;
ReadI(nc,0,MaxBlocks,'number of subblocks','MaxBlocks');Readln1;
nd:=nb+nc;
if nd>MaxBlocks then
  begin write(fe,'incrase MaxBlocks to ',nd);Halt1('') end;
height:=1;
for i:=1 to nd do                                                 {(sub)blocks}
  begin
  ReadI(blocks[i,0],1,MaxHeight,'number of atoms in a (sub)block','MaxHeight');
  if i<=nb then height:=MaxI(height,blocks[i,0])
           else height:=MaxI(height,blocks[i,0]+1);
  blockss[i]:=[];
  for j:=1 to blocks[i,0] do
    begin
    ReadI(blocks[i,j],1,na,'number of an atom','number of atoms');
    blockss[i]:=blockss[i]+[blocks[i,j]];
    end;
    Readln1;
  end;
if readstates then                                                     {states}
  begin
  ReadI(ns,0,MaxStates,'number of states','MaxStates');Readln1;
  for s:=1 to ns do
    begin
    for a:=1 to na do ReadI(states[s,a],0,1,'value of a state','');Readln1;
    if not IsState(s) then Halt1('not evaluation');          {check of a state}
    end;
  end;
end;

procedure RearrangeBlocks;
{************************} {atoms used in previous (sub)blocks first}
var a,b,i,j   :integer;
    usedatoms :array[1..MaxAtoms] of Boolean;
begin
for a:=1 to na do usedatoms[a]:=false;
for b:=1 to nd do
  begin
  blockso[b,0]:=blocks[b,0];                                  {number of atoms}
  j:=0;
  for i:=1 to blocks[b,0] do if usedatoms[blocks[b,i]] then
    begin Inc(j);blockso[b,j]:=blocks[b,i]; end;
  blockso[b,-1]:=j;                              {number of already used atoms}
  for i:=1 to blocks[b,0] do if not usedatoms[blocks[b,i]] then
    begin Inc(j);blockso[b,j]:=blocks[b,i];usedatoms[blocks[b,i]]:=true; end;
  end;
end;

procedure FindState (b :integer);
{*******************************} {for which block check}
var i,sum :integer;
procedure Set0OnRest;
  var i :integer;
  begin
  for i:=blockso[b,-1]+1 to blockso[b,0] do states[0,blockso[b,i]]:=0;
  end;
begin
if b>nd then begin Inc(ns);states[ns]:=states[0] end else
  begin
  sum:=0;for i:=1 to blockso[b,-1] do Inc(sum,states[0,blockso[b,i]]);
  if sum>1 then exit;
  if sum=0
    then begin
         for i:=blockso[b,-1]+1 to blockso[b,0] do
           begin Set0OnRest;states[0,blockso[b,i]]:=1;FindState(b+1); end;
         if b>nb then begin Set0OnRest;FindState(b+1); end;
         end
    else begin Set0OnRest;FindState(b+1); end;
  end;
end;

procedure FindStates;
{*******************}
begin
RearrangeBlocks;
ns:=0;
FindState(1);
end;

procedure WriteData;
{******************}
var a,b,s,i :integer;
begin
writeln(f,descr);
writeln(f,na:2,' atoms');
writeln(f,nb:2,' blocks');writeln(f,nc:2,' proper subsets of blocks');
for b:=1 to nd do
  begin
  write(f,blocks[b,0]:2,' ');
  for i:=1 to blocks[b,0] do write(f,' ',blocks[b,i]:2);
  writeln(f);
  end;
writeln(f,ns,' 2-valued evaluations of atoms:');
for s:=1 to ns do
  begin for a:=1 to na do write(f,states[s,a],' ');writeln(f) end;
end;

function Unital :Boolean;
{***********************}
var a,s :integer;
begin
write(f,'unital: ');
found:=false;
for a:=1 to na do
  begin
  s:=1;while (s<=ns) and (states[s,a]=0) do Inc(s);
  if s>ns then
    begin
    if not found then begin found:=true;write(f,'no for atoms') end;
    write(f,' ',a);
    end;
  end;
if found then writeln(f) else writeln(f,'yes');
Unital:=not found;
end;

function SeparatingAtoms :Boolean;
{********************************}
var a,aa,s :integer;
begin
write(f,'separating atoms: ');
found:=false;
for a:=1 to na-1 do for aa:=a+1 to na do
  begin
  s:=1;while (s<=ns) and (states[s,a]=states[s,aa]) do Inc(s);
  if s>ns then
    begin
    if not found then begin write(f,'no for pairs');found:=true end;
    write(f,' ',a,'/',aa);
    end;
  end;
if found then writeln(f) else writeln(f,'yes');
SeparatingAtoms:=not found;
end;

function Same (set1,set2 :setI) :Boolean;
{***************************************}
var b1,b2 :integer;
begin
Same:=true;
if set1=set2 then exit;
for b1:=1 to nb do if set1<=blockss[b1] then
  for b2:=1 to nb do if set2<=blockss[b2] then
    if blockss[b2]-set2=blockss[b1]-set1 then exit;
Same:=false;
end;

function Ordered (set1,set2 :setI) :Boolean;
{******************************************}
var b1,b2 :integer;
begin
Ordered:=true;
if set1<=set2 then exit;
for b1:=1 to nd do if set1<=blockss[b1] then
  for b2:=1 to nb do if set2<=blockss[b2] then
    if blockss[b2]-set2<=blockss[b1]-set1 then exit;
Ordered:=false;
end;

function NotFoundPair (set1,set2 :setI) :Boolean;
{***********************************************}
var i :integer;
begin
NotFoundPair:=false;
for i:=1 to np do if Same(pairs[i,1],set1) and Same(pairs[i,2],set2) then exit;
NotFoundPair:=true;
if np=MaxPairs then writeln(fe,'increase MaxPairs for check duplicities') else
  begin Inc(np);pairs[np,1]:=set1;pairs[np,2]:=set2; end;
end;

procedure TestSetsSep (set1,set2 :setI);
{**************************************}
var s,a,sum1,sum2 :integer;
begin
if Same(set1,set2) then exit;
for s:=1 to ns do
  begin
  sum1:=0;for a:=1 to na do if a in set1 then Inc(sum1,states[s,a]);
  sum2:=0;for a:=1 to na do if a in set2 then Inc(sum2,states[s,a]);
  if sum1<>sum2 then exit;
  end;
if not found then
  begin found:=true;writeln(f,'no for sets of atoms (different elements?)') end;
if NotFoundPair(set1,set2) and NotFoundPair(set2,set1) then
  begin write(f,' ');WriteSet(set1);write(f,'/');WriteSet(set2);writeln(f) end;
end;

procedure TestSetsOD (set1,set2 :setI);
{*************************************}
var s,a,sum1,sum2 :integer;
begin
if Ordered(set1,set2) then exit;
for s:=1 to ns do
  begin
  sum1:=0;for a:=1 to na do if a in set1 then Inc(sum1,states[s,a]);
  sum2:=0;for a:=1 to na do if a in set2 then Inc(sum2,states[s,a]);
  if sum1>sum2 then exit;
  end;
if not found then
  begin found:=true;writeln(f,'no for sets of atoms (ordered elements?)') end;
if NotFoundPair(set1,set2) then
  begin write(f,' ');WriteSet(set1);write(f,'/');WriteSet(set2);writeln(f) end;
end;

procedure FindSet2 (b1,b2,i :integer; set1,set2 :setI);
{*****************************************************}
var j           :integer;
    set1c,set2c :setI;
begin
if i<=blocks[b2,0]
  then begin
       FindSet2(b1,b2,i+1,set1,set2);
       FindSet2(b1,b2,i+1,set1,set2+[blocks[b2,i]])
       end
  else if testsep
         then TestSetsSep(set1,set2)
         else begin TestSetsOD(set1,set2);TestSetsOD(set2,set1) end;
end;

procedure FindSet1 (b1,i :integer; set1 :setI);
{*********************************************} {subsets of atoms of block b1}
var b2 :integer;
begin
if i<=blocks[b1,0]
  then begin
       FindSet1(b1,i+1,set1);
       FindSet1(b1,i+1,set1+[blocks[b1,i]])
       end
  else for b2:=b1+1 to nd do FindSet2(b1,b2,1,set1,[]);
end;

function Separating :Boolean;
{***************************}
var b1,a,s :integer;
begin
write(f,'separating: ');
testsep:=true;found:=false;np:=0;
for b1:=1 to nd-1 do FindSet1(b1,1,[]);
if nb=0 then       {no complete block, hence was no check with the top element}
  for a:=1 to na do
    begin
    s:=1;while (s<=ns) and (states[s,a]=1) do Inc(s);
    if s>ns then
      begin
      if not found then begin found:=true;writeln(f,'no for sets of atoms') end;
      writeln(f,' ',a,'/top');
      end;
    end;
if found then writeln(f) else writeln(f,'yes');
Separating:=not found;
end;

function OrderDetermining :Boolean;
{*********************************}
var b1 :integer;
begin
write(f,'order determining: ');
testsep:=false;found:=false;np:=0;
for b1:=1 to nd-1 do FindSet1(b1,1,[]);
if found then writeln(f) else writeln(f,'yes');
OrderDetermining:=not found;
end;

function OrderDeterminingA :Boolean;
{**********************************}
var a,aa,b,i,j,s :integer;
begin
for a:=1 to na do for aa:=1 to na do NonOrtho[a,aa]:=true;
for b:=1 to nd do for i:=1 to blocks[b,0] do for j:=i+1 to blocks[b,0] do
  begin
  NonOrtho[blocks[b,i],blocks[b,j]]:=false;
  NonOrtho[blocks[b,j],blocks[b,i]]:=false;
  end;
found:=false;
write(f,'1s on nonorthogonal atoms (=OD if no noncomplete block): ');
for a:=1 to na do for aa:=a to na do if NonOrtho[a,aa] then
  begin
  s:=1;while (s<=ns) and ((states[s,a]<>1) or (states[s,aa]<>1)) do Inc(s);
  if s>ns then
    begin
    if not found then begin found:=true;writeln(f,'no for atoms') end;
    write(f,' ',a,'/',aa);
    end;
  end;
if found then writeln(f) else writeln(f,'yes');
OrderDeterminingA:=not found;
end;

procedure CheckSetOfStates;
{*************************}
begin
writeln(f);writeln(f,'set of 2-valued evaluations of atoms:');
write(f,'nonempty: ');
if ns>0 then writeln(f,'yes') else begin writeln(f,'no');exit end;
if Unital then else exit;
if SeparatingAtoms then else exit;
if Separating then else exit;
if OrderDeterminingA then;
if OrderDetermining then;
end;

{main program}
{***********}
begin
AssignRewriteErr(fe,NameErr);line:=0;
ReadProgramParameters;
AssignReset(f,name1);line:=1;
ReadInput;
close(f);
if not readstates then FindStates;
AssignRewrite(f,name1);
WriteData;
CheckSetOfStates;
close(f);close(fe);
EraseIfEmpty(NameErr);
end.

