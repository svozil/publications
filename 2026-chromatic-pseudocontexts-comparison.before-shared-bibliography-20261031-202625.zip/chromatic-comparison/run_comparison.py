"""Reproduce all 19 state censuses and classical/quantum comparisons.

Dependencies: numpy, scipy, sympy. Run from any directory:
    python run_comparison.py [--only CONFIG_KEY ...]
Outputs are written to results/ beside this script. Classical support functions
are exact finite integer envelopes. Quantum spectra are numerical for the fixed
printed FORs; a reported strict gap must exceed 1e-9. Facet directions are
exhaustive, but the scan does not optimize gap magnitude over all coefficients.
"""
import argparse
import csv
import itertools
import json
from pathlib import Path
import numpy as np
import sympy as sp
from configurations import configurations
from tkadlec_states import enumerate_states,enumerate_independently,write_legacy
from comparison_core import colorings,numeric_geometry,census_relations,signed_unit,weighted_cases,primitive,TOL

EXPECTED={
 'M15':(0,0,0,0,0,0,0,4),'Oct20':(0,0,0,0,0,0,1,0),
 'B13':(1,0,0,0,0,0,0,1),'D16':(1,0,0,0,0,0,0,0),
 'I16':(10,2,0,6,0,0,2,3),'H17':(16,2,0,6,0,0,2,3),
 'T19':(8,2,0,4,0,0,1,2),'H20':(28,4,2,12,0,0,8,24),
 'H21':(66,21,21,63,0,0,36,0),'G27':(18,2,0,10,0,10,4,10),
 'G41_25':(46,6,1,29,1,29,10,29),'G41_26':(60,6,1,29,1,29,10,308),
 'H53':(66,4,2,23,2,23,12,416),'R21':(0,0,0,0,0,0,0,12),
 'R25':(0,0,0,0,0,0,0,12),'B14':(1,0,0,0,0,0,0,1),
 'D17':(1,0,0,0,0,0,0,0),'L18':(1,0,0,0,0,0,0,0),
 'L22':(8,1,0,4,0,0,0,0),
}
COUNT_KEYS=['rainbow_pairs','twin_pairs','independent_complete','partial_complete',
            'independent_two_valued','partial_two_valued','paired2','paired3']

def save(path,data):
    path.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':'))+'\n',encoding='utf-8')

def analyze(cfg,destination):
    print('START',cfg.key,flush=True)
    V,rows=enumerate_states(cfg.contexts)
    V2,rows2=enumerate_independently(cfg.contexts)
    assert V==V2 and rows==rows2
    states=np.asarray(rows,dtype=np.int8)
    colors,adj=colorings(cfg.contexts,V,cfg.dimension)
    ext=np.asarray(sorted({tuple((row==j).astype(int)) for row in colors for j in range(cfg.dimension)}),dtype=np.int8)
    assert (len(colors),len(ext),len(states))==cfg.expected,(cfg.key,'state/coloring census',len(colors),len(ext),len(states))
    assert set(map(tuple,ext)).issubset(map(tuple,states))
    Q,projectors,geometry=numeric_geometry(cfg,V)
    print('  states, colorings, FOR verified',cfg.key,flush=True)
    targets,pairs,counts=census_relations(V,cfg.dimension,cfg.contexts,colors,adj,states,ext)
    differences={k:dict(printed=EXPECTED[cfg.key][j],computed=counts[k])
                 for j,k in enumerate(COUNT_KEYS) if counts[k]!=EXPECTED[cfg.key][j]}
    if differences:print('  CENSUS DIFFERENCES',cfg.key,differences,flush=True)
    incidence=sp.Matrix([[int(v in e) for v in V] for e in cfg.contexts])
    null=incidence.nullspace()
    nullrows=[primitive(vector) for vector in null]
    def affine_identity(terms):
        return all(sum(sign*row[i] for i,sign in terms)==0 for row in nullrows)
    records=[]
    for number,(X,kinds) in enumerate(sorted(targets.items()),1):
        terms=[(i,1) for i in X]
        records.append(dict(id=f'X{number:04}',kind='single',categories=sorted(kinds),
                            terms=[[V[i],sgn] for i,sgn in terms],
                            unit_all=signed_unit(states,terms,projectors),
                            unit_extendable=signed_unit(ext,terms,projectors),
                            weighted=weighted_cases(terms,colors,states,ext,projectors)))
    for number,(A,B) in enumerate(pairs,1):
        terms=[(i,1) for i in A]+[(i,-1) for i in B]
        records.append(dict(id=f'D{number:04}',kind='pair',size=len(A),
                            categories=['color_multiset_pair'],
                            terms=[[V[i],sgn] for i,sgn in terms],
                            affine_context_identity=affine_identity(terms),
                            unit_all=signed_unit(states,terms,projectors),
                            unit_extendable=signed_unit(ext,terms,projectors),
                            weighted=weighted_cases(terms,colors,states,ext,projectors)))
    twins=[X for X,kinds in sorted(targets.items()) if len(X)==2 and 'twin' in kinds]
    for number,(i,j) in enumerate(twins,1):
        terms=[(i,1),(j,-1)]
        records.append(dict(id=f'T{number:04}',kind='twin_difference',categories=['chromatic_twin_difference'],
                            terms=[[V[i],sgn] for i,sgn in terms],
                            affine_context_identity=False,
                            unit_all=signed_unit(states,terms,projectors),
                            unit_extendable=signed_unit(ext,terms,projectors),
                            weighted=weighted_cases(terms,colors,states,ext,projectors)))
    total_patterns=sum(len(r['weighted']) for r in records)
    summary=dict(key=cfg.key,name=cfg.name,dimension=cfg.dimension,vertices=len(V),contexts=len(cfg.contexts),
                 states=len(states),extendable=len(ext),normalized_colorings=len(colors),
                 relation_census=counts,printed_census_differences=differences,incidence_rank=incidence.rank(),
                 single_targets=len(targets),paired_targets=len(pairs),twin_differences=len(twins),weighted_patterns=total_patterns,
                 unit_violating_all=sum(r['unit_all']['violating'] for r in records),
                 unit_violating_extendable=sum(r['unit_extendable']['violating'] for r in records),
                 weighted_violating_all=sum(any(w['comparison_all']['violating'] for w in r['weighted']) for r in records),
                 weighted_violating_extendable=sum(any(w['comparison_extendable']['violating'] for w in r['weighted']) for r in records))
    data=dict(summary=summary,geometry=geometry,coordinate_source=cfg.source,
              vertices=V,contexts=cfg.contexts,states=rows,extendable_states=ext.tolist(),
              normalized_colorings=colors.tolist(),relations=records,
              semantics=dict(classical_lower='min_{n in coefficients_all} dot(c,n)',
                             classical_upper='max_{n in coefficients_all} dot(c,n)',
                             quantum_operator='sum over terms (vertex,sign) of sign*c[color_pattern]*P_vertex',
                             quantum_lower='smallest eigenvalue of the quantum operator',
                             quantum_upper='largest eigenvalue of the quantum operator',
                             color_patterns='Canonicalized by first appearance in terms; coloring_references maps each used parameter index to its original global color.',
                             quantum_precision='float64 after 60-decimal-digit ray evaluation; strict separation threshold 1e-9',
                             parameter_scan='All exact facet normals and both signs of affine equality normals; witness sizes are not globally optimized over coefficient directions.'))
    save(destination/(cfg.key+'.json'),data)
    legacy=destination/'pascal-inputs';legacy.mkdir(exist_ok=True)
    write_legacy(legacy/(cfg.key+'.txt'),cfg.name,V,cfg.contexts,rows)
    save(legacy/(cfg.key+'-labels.json'),dict(legacy_to_manuscript={str(i+1):v for i,v in enumerate(V)}))
    print('DONE',cfg.key,'targets',len(targets),'pairs',len(pairs),'patterns',total_patterns,
          'violations(all states): unit',summary['unit_violating_all'],'weighted',summary['weighted_violating_all'],flush=True)
    return summary

def aggregate(destination):
    summaries=[];unitrows=[];witnessrows=[]
    for cfg in configurations():
        path=destination/(cfg.key+'.json')
        if not path.exists():continue
        data=json.loads(path.read_text(encoding='utf-8'));summaries.append(data['summary'])
        for record in data['relations']:
            label=' + '.join(v for v,sign in record['terms'] if sign>0)
            minus=[v for v,sign in record['terms'] if sign<0]
            if minus:label+=' - ('+' + '.join(minus)+')'
            unitrows.append(dict(configuration=cfg.key,relation=record['id'],kind=record['kind'],
                                 categories=';'.join(record['categories']),target=label,
                                 **{k:record['unit_all'][k] for k in ['classical_min','classical_max','quantum_min','quantum_max','lower_gap','upper_gap','violating']},
                                 extendable_min=record['unit_extendable']['classical_min'],extendable_max=record['unit_extendable']['classical_max']))
            for index,weighted in enumerate(record['weighted']):
                for family in ['all','extendable']:
                    witness=weighted['comparison_'+family]['best_witness']
                    if witness:
                        witnessrows.append(dict(configuration=cfg.key,relation=record['id'],pattern=index,
                                                state_family=family,target=label,c=' '.join(map(str,witness['c'])),
                                                classical_upper=witness['b'],quantum_max=witness['quantum_max'],
                                                upper_gap=witness['upper_gap'],gap_per_l2=witness['gap_per_l2'],
                                                residual=witness['residual']))
    save(destination/'summary.json',summaries)
    for name,rows in [('unit-comparison.csv',unitrows),('weighted-witnesses.csv',witnessrows)]:
        with (destination/name).open('w',encoding='utf-8-sig',newline='') as stream:
            writer=csv.DictWriter(stream,fieldnames=list(rows[0]) if rows else ['configuration'])
            writer.writeheader();writer.writerows(rows)
    print('AGGREGATE',len(summaries),'configurations,',len(unitrows),'target expressions,',len(witnessrows),'weighted witnesses',flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--only',nargs='+');args=parser.parse_args()
    destination=Path(__file__).parent/'results';destination.mkdir(exist_ok=True)
    for cfg in configurations():
        if args.only and cfg.key not in args.only:continue
        analyze(cfg,destination)
    aggregate(destination)
