"""Create human-readable and tabular summaries from the exhaustive results."""
import csv
import json
from pathlib import Path

REPS={
 'M15':['1','6','11'],'Oct20':['a1','a2'],'B13':['10','11'],'D16':['14','18'],
 'I16':['10','11'],'H17':['10','11'],'T19':['9','26'],'H20':['15','18','20'],
 'H21':['10','11','13'],'G27':['3','14','18'],'G41_25':['3','27','28'],
 'G41_26':['3','27','28'],'H53':['a','b','u'],'R21':['1','17','18'],
 'R25':['1','17','18'],'B14':['10','11'],'D17':['14','18'],'L18':['11','15'],
 'L22':['19','20','21','22'],
}

def linear(row):
    terms=[]
    for j,a in enumerate(row):
        if a:terms.append(('+' if a>0 else '-')+(str(abs(a))+' ' if abs(a)!=1 else '')+f'c_{j}')
    return ''.join(terms).lstrip('+') or '0'

def main():
    root=Path(__file__).parent;results=root/'results'
    summaries=json.loads((results/'summary.json').read_text(encoding='utf-8'))
    totals={k:sum(r[k] for r in summaries) for k in ['single_targets','paired_targets','twin_differences','weighted_patterns','unit_violating_all','weighted_violating_all']}
    lines=['# Classical and quantum comparison of all 19 configurations','',
           'The classical state sets and color coefficient envelopes are exact. Quantum values use the fixed faithful representations listed in configurations.py. Every parameterized expression is compared against both all two-valued states and the extendable subset. Both quantum endpoints are tested.','',
           f"Coverage: {totals['single_targets']} single-set sums (including actual contexts, all complete rainbow sets, independent rainbow subsets, twin subsets, and components of all counted paired relations), {totals['paired_targets']} signed multiset-pair differences, and {totals['twin_differences']} twin differences. These give {sum(totals[k] for k in ['single_targets','paired_targets','twin_differences'])} expressions and {totals['weighted_patterns']} distinct restricted color patterns modulo palette permutations.",'',
           'Every classical envelope is min/max of the stored integer vectors, dotted with the real color parameters. The facet/equality scan checks whether the quantum expectation image leaves that classical polytope. A positive reported gap exceeds 1e-9. Witness coefficients are not a global optimization of gap magnitude.','',
           '## Exhaustive comparison counts','',
           '| Configuration | All / extendable states | Single / paired / twin-difference expressions | Unit-weight separations, all states | Parameterized separations, all states | Parameterized separations, extendable |',
           '|---|---:|---:|---:|---:|---:|']
    for r in summaries:
        lines.append(f"| ${r['name']}$ | {r['states']} / {r['extendable']} | {r['single_targets']} / {r['paired_targets']} / {r['twin_differences']} | {r['unit_violating_all']} | {r['weighted_violating_all']} | {r['weighted_violating_extendable']} |")
    lines+=['','Counts are expressions admitting a separating direction, not independent contextuality proofs. Actual contexts are included as consistency checks. Parameterized counts include all canonical color patterns for each expression. Zero means no separation in the complete facet/equality scan for the listed expressions and chosen FOR; it does not rule out other observables or representations.','',
            '## Representative unit-weight comparisons','',
            'This table chooses one target per configuration; the CSV/JSON files contain every expression, not only these representatives.','',
            '| Configuration | Target | Classical, all states | Classical, extendable | Quantum interval | Separation from all states |',
            '|---|---|---|---|---|---|']
    reps=[];texrows=[];countrows=[]
    for r in summaries:
        d=json.loads((results/(r['key']+'.json')).read_text(encoding='utf-8'))
        wanted=set(REPS[r['key']])
        record=next(x for x in d['relations'] if x['kind']=='single' and {v for v,sign in x['terms']}==wanted)
        unit=record['unit_all'];ext=record['unit_extendable']
        low=unit['quantum_min'];high=unit['quantum_max']
        if abs(low)<1e-12:low=0
        if abs(high)<1e-12:high=0
        sep='both' if unit['lower_gap']>1e-9 and unit['upper_gap']>1e-9 else 'lower' if unit['lower_gap']>1e-9 else 'upper' if unit['upper_gap']>1e-9 else 'none'
        target='{'+','.join(v for v,sign in record['terms'])+'}'
        classic=f"[{unit['classical_min']},{unit['classical_max']}]"
        restricted=f"[{ext['classical_min']},{ext['classical_max']}]"
        quantum=f'[{low:.8f},{high:.8f}]'
        lines.append(f"| ${r['name']}$ | `{target}` | {classic} | {restricted} | {quantum} | {sep} |")
        reps.append(dict(configuration=r['key'],target=target,relation=record['id'],classical_min=unit['classical_min'],
                         classical_max=unit['classical_max'],extendable_min=ext['classical_min'],extendable_max=ext['classical_max'],
                         quantum_min=low,quantum_max=high,separation=sep))
        def tex_label(v):
            if len(v)==2 and v[0] in 'ab' and v[1].isdigit():return v[0]+'_'+v[1]
            return v.replace('_',r'\_')
        tex_target=r'\{'+','.join(tex_label(v) for v,sign in record['terms'])+r'\}'
        texrows.append(f"${r['name']}$ & ${tex_target}$ & ${classic}$ & ${restricted}$ & $[{low:.6f},{high:.6f}]$ & {sep}\\\\")
        countrows.append(f"${r['name']}$ & ${r['extendable']}/{r['states']}$ & ${r['single_targets']}/{r['paired_targets']}/{r['twin_differences']}$ & ${r['unit_violating_all']}$ & ${r['weighted_violating_all']}$ & ${r['weighted_violating_extendable']}$\\\\")
    lines+=['','## Exact parameter envelopes for the representative targets','',
            'For each row below, L is a finite list of linear expressions. The exact classical interval is [min L, max L] for arbitrary real parameters. The selected color pattern is canonical; all other patterns are retained in the per-configuration JSON.','']
    for rep in reps:
        d=json.loads((results/(rep['configuration']+'.json')).read_text(encoding='utf-8'))
        record=next(x for x in d['relations'] if x['id']==rep['relation'])
        w=max(record['weighted'],key=lambda w:w['parameter_count'])
        expressions=', '.join(linear(row) for row in w['coefficients_all'])
        ext_expressions=', '.join(linear(row) for row in w['coefficients_extendable'])
        tail='The extendable envelope is the same.' if expressions==ext_expressions else f'For extendable states L = {{{ext_expressions}}}.'
        lines.append(f"- **{rep['configuration']} {rep['target']}**, colors {w['color_pattern']}: L = {{{expressions}}}. {tail}")
    lines+=['','## Compact witnesses highlighted in the article','',
            'Every classical constraint below holds for convex mixtures of all admissible two-valued states. The quantum values use the printed FORs and suitable state preparations.','',
            '| Configuration | Classical constraint | Quantum violation |',
            '|---|---|---|',
            '| H53 | p(u) - p(y5) + p(y9) <= 1 | Maximum 1.545525795; weights (1,-1,1) |',
            '| H53 | p(a) + p(b) + p(u) = 1 | Quantum interval [0.57095612,1.51652083] |',
            '| H20 | p(15) + p(18) + p(20) >= 1 | Minimum 0.72960967 |',
            '| H21 | p(10) + p(11) + p(13) <= 1 | Maximum 4/3 |',
            '| G41_26 | p(11) = p(18) | Maximal absolute difference 1/3 |',
            '| L22 | p(11) - p(20) <= 0 | Maximum 1/sqrt(42) |','',
            'The weighted H53 witness is relation X0646, restricted color pattern 2. Its binary implication is u AND y9 implies y5. The projected patterns are 000,001,010,100,110,111; the inequality is a facet of that three-dimensional polytope. A maximizing state is approximately (-0.04240376,0.92996020,-0.36520672). The article now gives a structural implication proof as well as the spectral calculation.','',
            'For G41_26, the exact preparation (1,-1,0)/sqrt(2) gives p(11)=2/3 and p(18)=1/3. For H21 the same coordinate vector gives hub probabilities (2/3,2/3,0). In L22, preparing ray 11 gives p(11)=1 and p(20)=41/42, already violating the classical order inequality by 1/42.','',
            'These witnesses are state-dependent. The maximally mixed probabilities p(v)=1/d are reproduced by equally mixing the d column states of any strong d-coloring, so neither classical state family is separated from every quantum state by a linear ray-probability inequality.','',
            '## Census correction','',
            'The complex octagon has 20 independent, disjoint, non-twin color-multiset-equivalent pairs of size three, in addition to its one size-two pair. The pre-audit census listed zero in the size-three column. Both the old manuscript verifier and this independent enumeration return 20. Every pair is listed in Oct20.json. All other census entries and all state/coloring counts agree.','',
            '## Reproduction','',
            'Run `python audit_translation.py`, `python run_comparison.py`, and `python verify_results.py`; then `python build_report.py` regenerates this report. Run `python evaluate.py H53 --vertices a b u --weights 1 1 1` to evaluate arbitrary coefficients on a chosen expression. `--list` shows available expressions, and `--symbolic` constructs the exact operator and characteristic polynomial.','',
            'The supplied Python translation passed the enumeration audit. Its original Pascal-compatible CLI overwrites the input, so the audit used temporary files. The new tkadlec_states.py writes JSON separately and also enumerates declared atoms absent from every block; the original Pascal and its old Python translation silently fix such unused atoms to zero. All 19 manuscript configurations use every declared atom.','',
            'The legacy Pascal executable could not run on this host (Illegal System DLL Relocation). No Pascal execution or compilation is claimed. The original source and supplied full Python translation are preserved under reference/.','',
            'Full records: results/<configuration>.json; all state supports and dense Pascal-compatible labels: results/pascal-inputs/; every unit expression: unit-comparison.csv; separating parameter choices and gaps: weighted-witnesses.csv; audit and numerical verification: translation-audit.json and high-precision-verification.json.','']
    (root/'COMPARISON.md').write_text('\n'.join(lines),encoding='utf-8')
    for name,rows in [('representative-comparison.csv',reps),('configuration-comparison.csv',summaries)]:
        with (results/name).open('w',encoding='utf-8-sig',newline='') as f:
            fields=list(rows[0]) if name.startswith('representative') else [k for k in rows[0] if k not in ['relation_census','printed_census_differences']]
            writer=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
    (results/'representative-table-rows.tex').write_text('\n'.join(texrows)+'\n',encoding='utf-8')
    (results/'coverage-table-rows.tex').write_text('\n'.join(countrows)+'\n',encoding='utf-8')
    print('Totals:',totals)
    print('\n'.join(str(r) for r in reps))

if __name__=='__main__':main()
