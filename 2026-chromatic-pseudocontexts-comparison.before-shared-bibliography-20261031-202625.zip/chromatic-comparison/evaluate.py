"""Evaluate one saved expression for arbitrary real color values.

Example: python evaluate.py H53 --vertices a b u --weights 1 1 1
Or: python evaluate.py H21 --relation X0001 --pattern 0 --weights 0 1 2
Use --list to show saved expressions and --symbolic for an exact characteristic
polynomial in the used color parameters (potentially slow for algebraic FORs).
"""
import argparse
import json
from pathlib import Path
import numpy as np
import sympy as sp
from configurations import configurations
from comparison_core import numeric_geometry

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('configuration');p.add_argument('--relation');p.add_argument('--vertices',nargs='+')
    p.add_argument('--pattern',type=int,default=0);p.add_argument('--weights',type=float,nargs='+')
    p.add_argument('--list',action='store_true');p.add_argument('--symbolic',action='store_true')
    args=p.parse_args();root=Path(__file__).parent/'results'
    data=json.loads((root/(args.configuration+'.json')).read_text(encoding='utf-8'))
    if args.list:
        for r in data['relations']:print(r['id'],r['kind'],r['terms'],'patterns:',len(r['weighted']))
        return
    if args.vertices:
        wanted=set(args.vertices)
        r=next(r for r in data['relations'] if r['kind']=='single' and {v for v,sign in r['terms']}==wanted)
    else:r=next(r for r in data['relations'] if r['id']==args.relation)
    w=r['weighted'][args.pattern];e=w['parameter_count']
    c=np.asarray(args.weights if args.weights is not None else [1]*e)
    if len(c)!=e:raise ValueError(f'This pattern uses {e} color values, got {len(c)}.')
    cfg=next(c for c in configurations() if c.key==args.configuration)
    _,P,_=numeric_geometry(cfg,data['vertices']);index={v:i for i,v in enumerate(data['vertices'])}
    O=sum((sign*c[j]*P[index[v]] for (v,sign),j in zip(r['terms'],w['color_pattern'])),np.zeros((cfg.dimension,cfg.dimension),complex))
    eigenvalues,eigenvectors=np.linalg.eigh(O)
    answer=dict(configuration=cfg.key,relation=r['id'],terms=r['terms'],color_pattern=w['color_pattern'],weights=c.tolist(),
                classical_all=[float(min(np.dot(c,row) for row in w['coefficients_all'])),float(max(np.dot(c,row) for row in w['coefficients_all']))],
                classical_extendable=[float(min(np.dot(c,row) for row in w['coefficients_extendable'])),float(max(np.dot(c,row) for row in w['coefficients_extendable']))],
                quantum_eigenvalues=eigenvalues.tolist(),maximizing_state_real=eigenvectors[:,-1].real.tolist(),maximizing_state_imag=eigenvectors[:,-1].imag.tolist())
    print(json.dumps(answer,indent=2))
    if args.symbolic:
        parameters=sp.symbols('c_0:'+str(e),real=True);symbol=sp.Symbol('lambda')
        exact=sp.zeros(cfg.dimension)
        for (v,sign),j in zip(r['terms'],w['color_pattern']):
            q=cfg.rays[v];P=q*q.conjugate().T/(q.conjugate().T*q)[0]
            exact+=sign*parameters[j]*P
        exact=exact.applyfunc(sp.simplify)
        print('Exact operator:');sp.pprint(exact)
        print('Characteristic equality:');sp.pprint(sp.Eq(sp.factor(exact.charpoly(symbol).as_expr()),0))

if __name__=='__main__':main()
