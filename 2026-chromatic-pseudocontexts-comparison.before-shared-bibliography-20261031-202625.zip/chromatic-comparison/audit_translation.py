"""Audit the supplied full Python translation against two independent methods."""
import hashlib
import importlib.util
import itertools
import json
import random
import tempfile
from pathlib import Path
from configurations import configurations
from tkadlec_states import enumerate_states,enumerate_independently,write_legacy

def load(path):
    spec=importlib.util.spec_from_file_location('legacy_tkadlec',path)
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    return mod

def main(legacy_path):
    legacy_path=Path(legacy_path);legacy=load(legacy_path)
    report={'python_sha256':hashlib.sha256(legacy_path.read_bytes()).hexdigest(),
            'legacy_executable':'Could not launch: Illegal System DLL Relocation on this Windows host.',
            'configurations':{},'random_cases':0,
            'scope':'State enumeration and read-state mode, exact-one blocks, at-most-one proper subblocks; not a validation of legacy heuristic separation/order tests.'}
    with tempfile.TemporaryDirectory() as td:
        td=Path(td)
        for cfg in configurations():
            V,rows=enumerate_states(cfg.contexts)
            checkV,checkrows=enumerate_independently(cfg.contexts)
            assert V==checkV and rows==checkrows,cfg.key
            file=td/'input.txt';err=td/'error.txt'
            write_legacy(file,cfg.name,V,cfg.contexts)
            program=legacy.TwoStates(False,str(file),str(err))
            program.read_input();program.find_states()
            old=sorted(tuple(row[1:]) for row in program.states[1:])
            program.close_err_and_maybe_delete()
            assert rows==old,(cfg.key,'legacy mismatch')
            assert len(rows)==len(set(rows))==cfg.expected[2],cfg.key
            write_legacy(file,cfg.name,V,cfg.contexts,rows)
            program=legacy.TwoStates(True,str(file),str(err))
            program.read_input()
            assert sorted(tuple(row[1:]) for row in program.states[1:])==rows,(cfg.key,'read-state mode')
            program.close_err_and_maybe_delete()
            report['configurations'][cfg.key]=len(rows)
            print('Three enumerators agree:',cfg.key,len(rows),flush=True)
        rng=random.Random(20261031)
        for trial in range(240):
            n=rng.randint(1,9);V=list(range(1,n+1));edges=[]
            for i in range(rng.randint(1,7)):
                edges.append(tuple(sorted(rng.sample(V,rng.randint(1,min(n,4))))))
            # Legacy assumes every declared atom occurs in a block/subblock.
            covered=set().union(*map(set,edges))
            for v in set(V)-covered:edges.append((v,))
            nb=rng.randint(0,len(edges));blocks=edges[:nb];subs=edges[nb:]
            _,rows=enumerate_states(blocks,subs,V)
            _,independent=enumerate_independently(blocks,subs,V)
            brute=sorted(bits for bits in itertools.product((0,1),repeat=n)
                         if all(sum(bits[v-1] for v in e)==1 for e in blocks)
                         and all(sum(bits[v-1] for v in e)<=1 for e in subs))
            assert rows==independent==brute,trial
            file=td/'random.txt'
            lines=['Audit case',f'{n} atoms',f'{len(blocks)} blocks',f'{len(subs)} subblocks']
            lines+= [str(len(e))+' '+' '.join(map(str,e)) for e in edges]
            file.write_text('\n'.join(lines)+'\n',encoding='utf-8')
            program=legacy.TwoStates(False,str(file),str(td/'err.txt'))
            program.read_input();program.find_states()
            old=sorted(tuple(row[1:]) for row in program.states[1:])
            program.close_err_and_maybe_delete()
            assert rows==old,trial
            report['random_cases']+=1
    # Explicitly expose the shared original assumption on unused labels.
    _,free=enumerate_states([(1,2)],vertices=[1,2,3])
    assert len(free)==4
    report['findings']=[
        'No state-enumeration discrepancy found in the supplied Python translation for all 19 configurations and 240 small complete/subblock cases.',
        'Both legacy Pascal and its existing Python translation assume all declared atoms occur in the listed blocks: unused atoms are silently zero. The new module enumerates them freely.',
        'The existing Python port safely checks the 999-state limit; its other fixed limits are inherited from the Pascal source. The new enumeration API has no such limits.',
        'The supplied full Python CLI overwrites its input, just like Pascal; all audit runs used temporary copies. The new CLI writes a separate JSON result.',
        'Legacy Same/Ordered tests were explicitly described by Tkadlec as potentially incomplete; they are not used to compute the classical bounds.'
    ]
    destination=Path(__file__).parent/'results'/'translation-audit.json'
    destination.parent.mkdir(exist_ok=True)
    destination.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print('PASS:',len(report['configurations']),'configurations and',report['random_cases'],'brute-force cases.')

if __name__=='__main__':
    import sys
    path=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent/'reference'/'2states-original.py'
    main(path)
