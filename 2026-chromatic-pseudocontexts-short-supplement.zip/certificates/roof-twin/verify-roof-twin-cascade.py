"""Verify the accompanying roof-twin-cascade-certificate.json.
Requires Python 3, SymPy and mpmath. Run in any directory; the certificate
must be beside this script. No input files elsewhere are needed.

All three state and coloring inventories are recomputed exhaustively.
Faithfulness of G27,16 and G41,26 is tested with exact number fields.
G41,25 uses the proved coordinate recipe for intended edges and rigorous
interval enclosures for all nonedges and all distinct ray pairs.
"""
from pathlib import Path
from itertools import combinations
from collections import Counter
import json, math, sys, ast
import sympy as sp


ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'outputs'
BASE_EDGES=[(1,2,3),(7,8,9),(2,8,5),(3,11,14),(7,11,15),
            (9,10,23),(1,10,19),(4,11,24),(4,10,18)]
INTERNAL=[1,2,3,5,7,8,9,14,15,19,23]

def bug_edges(x,y,off):
    return [(off+1,off+2,off+3),(off+7,off+8,off+9),(off+2,off+8,off+5),
            (off+3,y,off+14),(off+7,y,off+15),(off+9,x,off+23),(off+1,x,off+19)]

def base_vectors(a=1,b=1):
    a,b=sp.sympify(a),sp.sympify(b)
    v={1:sp.Matrix([0,1,a]),2:sp.Matrix([1,0,0]),3:sp.Matrix([0,a,-1]),
       5:sp.Matrix([0,0,1]),7:sp.Matrix([1,0,b]),8:sp.Matrix([0,1,0]),9:sp.Matrix([b,0,-1]),
       10:sp.Matrix([1,-a*b,b]),11:sp.Matrix([a*b,-1,-a])}
    v[4]=v[10].cross(v[11]);v[14]=v[11].cross(v[3]);v[15]=v[7].cross(v[11])
    v[19]=v[1].cross(v[10]);v[23]=v[10].cross(v[9])
    v[18]=v[4].cross(v[10]);v[24]=v[11].cross(v[4])
    return v

def projective(q):
    q=sp.simplify(q)
    z=next(x for x in q if x!=0)
    return sp.simplify(q/z)

def bug_vectors(u,v,f1,f2,off):
    q={2:f1,8:f2,5:f1.cross(f2),1:f1.cross(u),3:f1.cross(v),9:f2.cross(u),7:f2.cross(v)}
    q[14]=v.cross(q[3]);q[15]=v.cross(q[7]);q[19]=u.cross(q[1]);q[23]=u.cross(q[9])
    return {off+k:projective(w) for k,w in q.items()}

def universal_bug(u,v,off):
    u=sp.simplify(u/sp.sqrt(u.dot(u)));v=sp.simplify(v/sp.sqrt(v.dot(v)))
    if float(u.dot(v).evalf())<0:v=-v
    e1,e2,e3=u+v,u-v,u.cross(v)
    ratio=sp.simplify(e1.dot(e1)/e2.dot(e2))
    a=e1/sp.sqrt(sp.simplify(e1.dot(e1)))
    b=sp.sqrt(2-ratio)*e2/sp.sqrt(sp.simplify(e2.dot(e2)))+sp.sqrt(ratio-1)*e3/sp.sqrt(sp.simplify(e3.dot(e3)))
    return bug_vectors(u,v,sp.simplify(a+b),sp.simplify(a-b),off)

def geometry(vec,edges,exact=True):
    adj={frozenset(p) for e in edges for p in combinations(e,2)}
    keys=sorted({v for e in edges for v in e})
    values={v:projective(vec[v]) for v in keys}
    # Convert one common algebraic number field once, then test all pairs exactly.
    field=None
    if exact:
        roots=set()
        for q in values.values():
            for x in q:
                roots.update(x.atoms(sp.Pow))
        roots=[x for x in roots if x.exp.is_Rational and x.exp.q!=1]
        field=sp.QQ.algebraic_field(*roots) if roots else sp.QQ
        kv={v:tuple(field.from_sympy(x) for x in values[v]) for v in keys}
    else:
        kv={v:tuple(float(x.evalf(30)) for x in values[v]) for v in keys}
    extra=[];missing=[];parallel=[]
    for a,b in combinations(keys,2):
        u,v=kv[a],kv[b]
        ip=sum((x*y for x,y in zip(u,v)),field.zero if exact else 0.)
        orth=(ip==field.zero) if exact else abs(ip)<1e-9*math.sqrt(sum(x*x for x in u)*sum(x*x for x in v))
        par=all(u[i]*v[j]==u[j]*v[i] for i,j in combinations(range(3),2)) if exact else sum((u[i]*v[j]-u[j]*v[i])**2 for i,j in combinations(range(3),2))<1e-16
        if par:parallel.append([a,b])
        edge=frozenset((a,b)) in adj
        if orth and not edge:extra.append([a,b])
        if edge and not orth:missing.append([a,b])
    return {'vertices':len(keys),'contexts':len(edges),'pairs_checked':len(keys)*(len(keys)-1)//2,
            'extra_orthogonalities':extra,'missing_orthogonalities':missing,'parallel_pairs':parallel,
            'field_degree':int(field.ext.minpoly.degree()) if exact and hasattr(field,'ext') else 1 if exact else None}

def fixed_cascade():
    v=base_vectors()
    # Keep the small integer representatives used in the manuscript.
    v.update({4:sp.Matrix([1,1,0]),14:sp.Matrix([2,1,1]),18:sp.Matrix([1,-1,-2]),24:sp.Matrix([1,-1,2])})
    v.update(bug_vectors(v[18],v[24],sp.Matrix([1,1,sp.sqrt(2)]),sp.Matrix([1,1,-sp.sqrt(2)]),100))
    v[26]=sp.Matrix([-1,5,-3]);v[27]=sp.Matrix([8,-5,-11]);v[28]=sp.Matrix([-13,-5,-4])
    A=sp.Matrix([3,0,-1]);B=sp.Matrix([1,2,3]);C=sp.Matrix([-1,5,-3])
    v.update(bug_vectors(v[27],v[28],sp.sqrt(35)*A+sp.sqrt(15)*B+2*C,sp.sqrt(35)*A-sp.sqrt(15)*B-2*C,200))
    g27=BASE_EDGES+bug_edges(18,24,100)
    g25=g27+[(14,27,26),(18,28,26)]+bug_edges(27,28,200)
    return v,{'G27_16':g27,'G41_25':g25,'G41_26':g25+[(4,5,105)]}

def rational_g27():
    v=base_vectors(sp.Rational(9,32),sp.Rational(24,11))
    n=v[4]/sp.Rational(45305,15488)
    x,y,z=n;cross=sp.Matrix([[0,-z,y],[z,0,-x],[-y,x,0]])
    rotation=n*n.T-cross
    for k in INTERNAL:v[100+k]=projective(rotation*v[k])
    return v,BASE_EDGES+bug_edges(18,24,100)

def summary(edges):
    ss=states(edges);cc=colorings(edges)
    V=sorted(ss[0]);ext={tuple(int(c[v]==j) for v in V) for c in cc for j in range(3)}
    result={'vertices':len(V),'contexts':len(edges),'states':len(ss),'normalized_colorings':len(cc),'extendable_states':len(ext)}
    if 27 in V:
        U=(3,27,28)
        result['target_patterns']={''.join(map(str,k)):n for k,n in sorted(Counter(tuple(s[v] for v in U) for s in ss).items())}
        assert all(sum(s[v] for v in U)==1 for s in ss)
        assert all(len({c[v] for v in U})==3 for c in cc)
    assert all(s[10]==s[24] and s[11]==s[18] for s in ss)
    return result,ss,cc


def states(edges, fixed=None):
    vertices=sorted(set().union(*map(set,edges)))
    result=[]
    def visit(values):
        while True:
            changed=False
            for e in edges:
                ones=[v for v in e if values.get(v)==1]
                unset=[v for v in e if v not in values]
                if len(ones)>1 or (not ones and not unset): return
                if ones:
                    for v in unset: values[v]=0; changed=True
                elif len(unset)==1: values[unset[0]]=1; changed=True
            if not changed: break
        if len(values)==len(vertices): result.append(values); return
        e=min((e for e in edges if any(v not in values for v in e)),
              key=lambda e:sum(v not in values for v in e))
        for v in e:
            if v not in values:
                new=values.copy()
                for u in e:new[u]=int(u==v)
                visit(new)
    visit(dict(fixed or {}))
    return result

def colorings(edges,d=3,limit=None):
    vertices=sorted(set().union(*map(set,edges)))
    adj={v:set() for v in vertices}
    for e in edges:
        for a,b in combinations(e,2):adj[a].add(b);adj[b].add(a)
    c=dict(zip(edges[0],range(d))); result=[]
    def visit():
        if limit is not None and len(result)>=limit:return
        if len(c)==len(vertices):result.append(c.copy());return
        v=max((v for v in vertices if v not in c),
              key=lambda v:(len({c[w] for w in adj[v] if w in c}),len(adj[v])))
        for col in set(range(d))-{c[w] for w in adj[v] if w in c}:
            c[v]=col;visit();del c[v]
    visit();return result


import mpmath as mp
from functools import lru_cache
mp.iv.dps=70
@lru_cache(None)
def ev(x):
    if x.is_Rational:return mp.iv.mpf(int(x.p))/int(x.q)
    if x.is_Add:return sum((ev(a) for a in x.args),mp.iv.mpf(0))
    if x.is_Mul:
        r=mp.iv.mpf(1)
        for a in x.args:r*=ev(a)
        return r
    if x.is_Pow:
        if x.exp.is_Integer:return ev(x.base)**int(x.exp)
        if x.exp.is_Rational and x.exp.q==2:return mp.iv.sqrt(ev(x.base))**int(x.exp.p)
    raise ValueError(x)
def nz(x):return bool(x.a>0 or x.b<0)
def interval_check(v,e):
    keys=sorted(v);adj={frozenset(p) for c in e for p in combinations(c,2)}
    kv={k:tuple(ev(x) for x in projective(v[k])) for k in keys}
    low=[]
    for a,b in combinations(keys,2):
        u,w=kv[a],kv[b];dot=sum((x*y for x,y in zip(u,w)),mp.iv.mpf(0))
        if frozenset((a,b)) not in adj:
            assert nz(dot),(a,b,str(dot))
            norm=mp.iv.sqrt(sum(x*x for x in u)*sum(x*x for x in w))
            low.append(float((abs(dot)/norm).a))
        assert any(nz(u[i]*w[j]-u[j]*w[i]) for i,j in combinations(range(3),2)),(a,b,'parallel')
    return {'vertices':len(keys),'contexts':len(e),'pairs_checked':len(keys)*(len(keys)-1)//2,'all_nonadjacent_dot_products_certifiably_nonzero':True,'all_rays_certifiably_distinct':True,'interval_decimal_digits':mp.iv.dps,'minimum_certified_absolute_normalized_nonedge_dot_product_lower_bound':min(low)}


if __name__=='__main__':
    from itertools import product
    data=json.loads(Path(__file__).with_name('roof-twin-cascade-certificate.json').read_text())
    # Audit the lemma on its complete binary cube, without graph assumptions.
    admissible=0
    for a,x,y,xp,yp in product((0,1),repeat=5):
        if a+x+yp==a+y+xp==1 and x+y<=1 and xp+yp<=1:
            assert x==xp and y==yp and a+x+y==1
            admissible+=1
    assert admissible==3
    print('Roof lemma: all 32 binary assignments checked.',flush=True)
    fv,cases=fixed_cascade();rv,re=rational_g27()
    gv=dict(rv)
    gv[26]=gv[14].cross(gv[18]);gv[27]=gv[26].cross(gv[14]);gv[28]=gv[26].cross(gv[18])
    gv.update(universal_bug(gv[27],gv[28],200))
    for name,edges in cases.items():
        item=data['cases'][name];keys=item['vertices']
        assert edges==[tuple(e) for e in item['contexts']]
        info,ss,cc=summary(edges)
        assert info==item['census']
        assert {tuple(s[k] for k in keys) for s in ss}==set(map(tuple,item['states']))
        assert {tuple(c[k] for k in keys) for c in cc}==set(map(tuple,item['normalized_colorings']))
        vec=rv if name=='G27_16' else gv if name=='G41_25' else fv
        for k in keys:
            assert list(map(str,projective(vec[k])))==item['vectors'][str(k)],(name,k)
        if name=='G41_25':
            g=interval_check(vec,edges)
            assert g['minimum_certified_absolute_normalized_nonedge_dot_product_lower_bound']>.00155
        else:
            g=geometry(vec,edges)
            assert not g['extra_orthogonalities'] and not g['missing_orthogonalities'] and not g['parallel_pairs']
        if name!='G27_16':
            adj={frozenset(p) for e in edges for p in combinations(e,2)}
            assert all(frozenset(p) not in adj for p in combinations(data['target'],2))
        print(name,info,'faithfulness verified',flush=True)
    # Verify the distinguishing Born preparation exactly.
    U=(3,27,28);psi=fv[3]
    born=sum((psi.dot(fv[k])**2/(psi.dot(psi)*fv[k].dot(fv[k])) for k in U),sp.S(0))
    assert born==sp.Rational(457,420)
    print('Born target sum:',born,flush=True)
    for name,edges in data['yu_oh_contexts'].items():
        p=data['binary_filters_and_minimality'][name+'_promotion']
        ss=states(edges);cc=colorings(edges);keys=sorted(ss[0])
        retained=[s for s in ss if all(s[a]+s[b]<=1 for a,b in p['pairs'])]
        ext={tuple(int(c[k]==j) for k in keys) for c in cc for j in range(3)}
        assert {tuple(s[k] for k in keys) for s in retained}==ext
        assert len(retained)==p['retained_states']
    edges=data['yu_oh_contexts']['H21'];ss=states(edges)
    keys=sorted(ss[0]);adj={frozenset(p) for e in edges for p in combinations(e,2)}
    ex=[u for u in combinations(keys,3) if all(frozenset(p) not in adj for p in combinations(u,2)) and all(sum(s[k] for k in u)<=1 for s in ss)]
    assert ex==[(10,11,13)]
    witnesses=data['binary_filters_and_minimality']['H21_minimality']['single_deletion_witnesses']
    assert len(witnesses)==13
    assert {frozenset(w['removed_context']) for w in witnesses}==set(map(frozenset,edges))
    for w in witnesses:
        s={int(k):v for k,v in w['assignment'].items()}
        assert all(v in (0,1) for v in s.values())
        assert sum(s[k] for k in (10,11,13))>1
        assert all(sum(s[k] for k in e)==1 for e in edges if set(e)!=set(w['removed_context']))
    print('Yu-Oh filters, unique exclusive hub, and all 13 deletion witnesses verified.',flush=True)
