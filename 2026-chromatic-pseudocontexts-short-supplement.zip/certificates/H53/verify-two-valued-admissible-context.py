from pathlib import Path
from itertools import combinations
from collections import Counter
import json
import sympy as sp
from pathlib import Path
from itertools import combinations
import json

ROOT=Path(__file__).resolve().parent

def states(edges, fixed=None):
    vertices=sorted(set().union(*map(set,edges)))
    result=[]
    def visit(values):
        while True:
            changed=False
            for e in edges:
                ones=[v for v in e if values.get(v)==1]
                unset=[v for v in e if v not in values]
                if len(ones)>1 or (not ones and not unset): return
                if ones:
                    for v in unset: values[v]=0; changed=True
                elif len(unset)==1: values[unset[0]]=1; changed=True
            if not changed: break
        if len(values)==len(vertices): result.append(values); return
        e=min((e for e in edges if any(v not in values for v in e)),
              key=lambda e:sum(v not in values for v in e))
        for v in e:
            if v not in values:
                new=values.copy()
                for u in e:new[u]=int(u==v)
                visit(new)
    visit(dict(fixed or {}))
    return result

def colorings(edges,d=3,limit=None):
    vertices=sorted(set().union(*map(set,edges)))
    adj={v:set() for v in vertices}
    for e in edges:
        for a,b in combinations(e,2):adj[a].add(b);adj[b].add(a)
    c=dict(zip(edges[0],range(d))); result=[]
    def visit():
        if limit is not None and len(result)>=limit:return
        if len(c)==len(vertices):result.append(c.copy());return
        v=max((v for v in vertices if v not in c),
              key=lambda v:(len({c[w] for w in adj[v] if w in c}),len(adj[v])))
        for col in set(range(d))-{c[w] for w in adj[v] if w in c}:
            c[v]=col;visit();del c[v]
    visit();return result

def find_complete(edges,d,ss):
    if not ss:return []
    vertices=sorted(ss[0]);full=(1<<len(ss))-1
    supports={v:sum(s[v]<<i for i,s in enumerate(ss)) for v in vertices}
    adj={frozenset(p) for e in edges for p in combinations(e,2)}
    found=[]
    for u in combinations(vertices,d):
        if any(frozenset(p) in adj for p in combinations(u,2)):continue
        cover=0
        for v in u:
            if supports[v]==0 or cover&supports[v]:break
            cover|=supports[v]
        else:
            if cover==full:found.append(u)
    return found



ROOT=Path(__file__).resolve().parent
S2=sp.sqrt(2);S3=sp.sqrt(3)
K=sp.QQ.algebraic_field(S2,S3)

def cross_matrix(v):
    x,y,z=v
    return sp.Matrix([[0,-z,y],[z,0,-x],[-y,x,0]])

def kv(v):return tuple(K.from_sympy(sp.expand(x)) for x in v)
def dot(a,b):return sum((x*y for x,y in zip(a,b)),K.zero)
def parallel(a,b):return all(a[i]*b[j]==a[j]*b[i] for i,j in combinations(range(3),2))
def expr(v):return [str(sp.simplify(K.to_sympy(x))) for x in v]

a=sp.Matrix([1,-1,1]);b=sp.Matrix([1,-1,-1]);c=sp.Matrix([1,1,0])
cu=c/S2
R=cu*cu.T+cross_matrix(cu)
bug_vectors={
    'a':a,'b':b,
    'x1':sp.Matrix([2,1,-1]),'x2':sp.Matrix([0,1,1]),
    'x3':sp.Matrix([1,0,0]),'x4':sp.Matrix([0,1,-1]),
    'x5':sp.Matrix([2,1,1]),'x6':sp.Matrix([1,2,-1]),
    'x7':sp.Matrix([1,0,1]),'x8':sp.Matrix([0,1,0]),
    'x9':sp.Matrix([1,0,-1]),'x10':sp.Matrix([1,2,1]),
    'x11':sp.Matrix([0,0,1]),
}
bug=[('a','x1','x2'),('x2','x3','x4'),('x4','x5','b'),
     ('b','x6','x7'),('x7','x8','x9'),('x9','x10','a'),('x3','x8','x11')]
rotate_names={'a':'bp','b':'ap',**{f'x{i}':f'y{i}' for i in range(1,12)}}
Gvec={**bug_vectors,**{rotate_names[v]:R*q for v,q in bug_vectors.items()},'c':c}
Gedges=bug+[tuple(rotate_names[v] for v in e) for e in bug]+[
    ('a','c','bp'),('b','c','ap'),('c','x11','y11')]

def check_for(vec,edges):
    adj={frozenset(pair) for e in edges for pair in combinations(e,2)}
    extra=[];missing=[];duplicates=[]
    for v,w in combinations(vec,2):
        if parallel(vec[v],vec[w]):duplicates.append((v,w))
        orth=dot(vec[v],vec[w])==K.zero
        edge=frozenset((v,w)) in adj
        if orth and not edge:extra.append((v,w))
        if edge and not orth:missing.append((v,w))
    return {'extra_orthogonalities':extra,'missing_orthogonalities':missing,'parallel_pairs':duplicates}

Gkv={v:kv(q) for v,q in Gvec.items()}
base_check=check_for(Gkv,Gedges)
assert not any(base_check.values()),base_check
Gss=states(Gedges);Gcc=colorings(Gedges)
assert len(Gss)==24 and len(Gcc)==8
assert all(s['a']==s['ap'] and s['b']==s['bp'] for s in Gss)

# Map an orthonormal frame at a to a frame at c; the partner ap then
# has a rational ray (-2,-2,1). Rational rotations about c keep it rational.
au=a/S3
e2=sp.Matrix([1,-1,-2])/sp.sqrt(6)
e3=au.cross(e2)
z=sp.Matrix([0,0,1])
Q0=sp.Matrix.hstack(cu,z,cu.cross(z))*sp.Matrix.hstack(au,e2,e3).T
assert sp.simplify(Q0*au-cu)==sp.zeros(3,1)

rename={v:('c' if v=='a' else ('u' if v=='ap' else 't_'+v)) for v in Gvec}
edges=Gedges+[tuple(rename[v] for v in e) for e in Gedges]
for num,den in [(1,1),(1,3),(2,1),(1,2),(2,3),(3,5),(2,7),(3,11),(5,13)]:
    t=sp.Rational(num,den)
    co=(1-2*t*t)/(1+2*t*t);si=2*S2*t/(1+2*t*t)
    Q=(cu*cu.T+co*(sp.eye(3)-cu*cu.T)+si*cross_matrix(cu))*Q0
    transformed={rename[v]:kv(Q*q) for v,q in Gvec.items() if v!='a'}
    vec={**Gkv,**transformed}
    check=check_for(vec,edges)
    if not any(check.values()):break
else:raise ValueError('No tested generic rotation gave a faithful union')

# Use a small integer representative for the distinguished u ray.
ratios=[sp.simplify(K.to_sympy(x/vec['u'][0])) for x in vec['u']]
assert all(x.is_Rational for x in ratios)
scale=sp.ilcm(*[x.q for x in ratios])
vec['u']=kv(sp.Matrix([scale*x for x in ratios]))
assert not any(check_for(vec,edges).values())

ss=states(edges);cc=colorings(edges)
vertices=sorted(vec)
ext={tuple(int(z[v]==j) for v in vertices) for z in cc for j in range(3)}
U=('a','b','u')
patterns=Counter(tuple(s[v] for v in U) for s in ss)
assert set(patterns)=={(1,0,0),(0,1,0),(0,0,1)}
assert all(sum(s[v] for v in U)==1 for s in ss)
assert all(len({z[v] for v in U})==3 for z in cc)
assert all(dot(vec[v],vec[w])!=K.zero for v,w in combinations(U,2))
assert len(vec)==53 and len(edges)==34 and len(ss)==224 and len(cc)==128

incidence=sp.Matrix([[int(v in e) for v in vertices] for e in edges])
target=sp.Matrix([[int(v in U) for v in vertices]])
rank=incidence.rank();rank_target=incidence.col_join(target).rank()
assert rank_target==rank+1

born={v:sp.simplify(K.to_sympy(dot(vec['c'],vec[v]))**2/
                  (K.to_sympy(dot(vec['c'],vec['c']))*K.to_sympy(dot(vec[v],vec[v])))) for v in U}
assert sum(born.values())==sp.Rational(8,9)

result={
    'name':'H53_34_two_valued_admissible_context',
    'dimension':3,'field':'R (coordinates in Q(sqrt(2),sqrt(3)))',
    'vertices':len(vec),'number_of_contexts':len(edges),'contexts':edges,
    'vectors':{v:expr(q) for v,q in vec.items()},
    'distinguished_set':U,'two_valued_states':len(ss),
    'normalized_colorings':len(cc),'all_labeled_colorings':6*len(cc),
    'extendable_states':len(ext),'state_patterns':{str(k):v for k,v in patterns.items()},
    'faithfulness_check':check,'incidence_rank':rank,'rank_with_target':rank_target,
    'rotation_half_angle_tangent':str(S2*t),
    'target_inner_products':{str((v,w)):str(sp.simplify(K.to_sympy(dot(vec[v],vec[w])))) for v,w in combinations(U,2)},
    'born_probabilities_in_c':{v:str(p) for v,p in born.items()},
    'states':[{v:s[v] for v in vertices} for s in ss],
    'normalized_coloring_assignments':[{v:z[v] for v in vertices} for z in cc],
}
(ROOT/'two-valued-admissible-context-certificate.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k not in ['states','normalized_coloring_assignments','vectors','contexts']},indent=2))
print('Target vectors:',{v:expr(vec[v]) for v in U},flush=True)
print('All 1378 ray pairs checked exactly; all 224 two-valued states and 128 normalized colorings enumerated.')
