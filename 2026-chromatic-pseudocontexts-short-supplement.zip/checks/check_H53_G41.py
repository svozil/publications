#!/usr/bin/env python3
"""Independent recount of the numbers quoted for H_{53,34}, G_{27,16},
G_{41,25} and G_{41,26} in the short paper (Secs. III and IV).

This script does not read the certificates; it rebuilds the hypergraphs and
the rays from the formulas printed in the paper.  Orthogonality is tested in
floating point (tolerance 1e-9); the exact tests are in the SymPy verifiers
under certificates/.

Requires Python 3 and NumPy.   Run:  python check_H53_G41.py
"""
import itertools, math, sys
from collections import Counter
import numpy as np

sys.setrecursionlimit(10000)


def states(E):
    res = []

    def rec(i, ch):
        if i == len(E):
            res.append(ch); return
        hit = [v for v in E[i] if v in ch]
        if len(hit) > 1: return
        if len(hit) == 1:
            rec(i+1, ch); return
        for v in E[i]:
            if all(v not in E[j] for j in range(i)):
                rec(i+1, ch | {v})
    rec(0, frozenset())
    return set(res)


def colorings(E, d=3):
    adj = {}
    for e in E:
        for a in e:
            adj.setdefault(a, set()).update(b for b in e if b != a)
    V = sorted(adj, key=str)
    col = {v: k for k, v in enumerate(E[0])}
    res = []

    def rec():
        best = None
        for v in V:
            if v in col: continue
            free = [k for k in range(d) if all(col.get(u) != k for u in adj[v])]
            if not free: return
            if best is None or len(free) < len(best[1]): best = (v, free)
        if best is None:
            res.append(dict(col)); return
        v, free = best
        for k in free:
            col[v] = k; rec(); del col[v]
    rec()
    return res, adj


def census(E):
    S = states(E); C, adj = colorings(E)
    ext = {frozenset(v for v in c if c[v] == k) for c in C for k in range(3)}
    return S, C, adj, ext


P = lambda q: np.outer(q, q) / (q @ q)
spec = lambda *qs: np.linalg.eigvalsh(sum(P(np.array(q, float)) for q in qs))


def faithful(vec, adj, tol=1e-9):
    orth, bad = 0, []
    for a, b in itertools.combinations(list(vec), 2):
        ip = abs(vec[a] @ vec[b]) / math.sqrt((vec[a] @ vec[a]) * (vec[b] @ vec[b]))
        o = ip < tol
        orth += o
        if o != (b in adj[a]) or abs(ip - 1) < tol: bad.append((a, b))
    return orth, bad


def main():
    ok = True

    def check(label, cond):
        nonlocal ok
        ok &= bool(cond)
        print(('PASS  ' if cond else 'FAIL  ') + label)

    # ---------------- H_{53,34}
    def bug(a, b, x):
        X = lambda i: f'{x}{i}'
        return [(a, X(1), X(2)), (X(2), X(3), X(4)), (X(4), X(5), b), (b, X(6), X(7)),
                (X(7), X(8), X(9)), (X(9), X(10), a), (X(3), X(8), X(11))]
    G = bug('a', 'b', 'x') + bug("b'", "a'", 'y') + [('a', 'c', "b'"), ('b', 'c', "a'"), ('c', 'x11', 'y11')]
    ren = lambda v: 'c' if v == 'a' else '~' + v          # second copy, its a identified with c
    H53 = G + [tuple(ren(v) for v in e) for e in G]
    u = "~a'"
    S, C, adj, ext = census(H53)
    check('H53,34: 53 rays, 34 contexts', (len(adj), len(H53)) == (53, 34))
    check('H53,34: 224 states, 128 extendable, 128 normalized colorings', (len(S), len(ext), len(C)) == (224, 128, 128))
    pat = Counter((int('a' in s), int('b' in s), int(u in s)) for s in S)
    check('H53,34: (s(a),s(b),s(u)) = 100, 010, 001 with multiplicities 80, 80, 64',
          dict(pat) == {(1, 0, 0): 80, (0, 1, 0): 80, (0, 0, 1): 64})
    indep = lambda T: all(y not in adj[x] for x, y in itertools.combinations(T, 2))
    V = sorted(adj)
    tv = [T for T in itertools.combinations(V, 3) if indep(T) and all(sum(t in s for t in T) == 1 for s in S)]
    check("H53,34: independent triples normalized on all states are {a,b,u} and {a',b',u}",
          sorted(map(set, tv), key=sorted) == sorted([{'a', 'b', u}, {"a'", "b'", u}], key=sorted))
    ctx = {frozenset(e) for e in H53}
    rb = [T for T in itertools.combinations(V, 3) if frozenset(T) not in ctx and all(len({c[t] for t in T}) == 3 for c in C)]
    check('H53,34: 25 non-context always-rainbow triples, 2 of them independent', len(rb) == 25 and sum(indep(T) for T in rb) == 2)
    qa, qb, qc = np.array([1, -1, 1.]), np.array([1, -1, -1.]), np.array([1, 1, 0.])
    xs = [(2, 1, -1), (0, 1, 1), (1, 0, 0), (0, 1, -1), (2, 1, 1), (1, 2, -1), (1, 0, 1), (0, 1, 0), (1, 0, -1), (1, 2, 1), (0, 0, 1)]
    n = qc / math.sqrt(2)
    K = np.array([[0, -n[2], n[1]], [n[2], 0, -n[0]], [-n[1], n[0], 0]])
    R = np.outer(n, n) + K
    vec = {'a': qa, 'b': qb, 'c': qc, "b'": R @ qa, "a'": R @ qb}
    for i, v in enumerate(xs, 1):
        vec[f'x{i}'] = np.array(v, float); vec[f'y{i}'] = R @ np.array(v, float)
    F0 = np.column_stack([qa / math.sqrt(3), np.array([1, -1, -2.]) / math.sqrt(6), n])
    E0 = np.column_stack([n, np.array([0, 0, 1.]), np.array([1, -1, 0.]) / math.sqrt(2)])
    L0 = np.array([[9, 2, 6], [2, 9, -6], [-6, 6, 7.]]) / 11
    Q = L0 @ E0 @ F0.T
    full = dict(vec)
    for k, v in vec.items():
        if k != 'a': full['~' + k] = Q @ v
    check('H53,34: Q q_a parallel to q_c; Q q_a\' proportional to (16,28,-7)',
          np.allclose(np.cross(Q @ qa, qc), 0) and np.allclose(np.cross(Q @ vec["a'"], [16, 28, -7]), 0))
    orth, bad = faithful(full, adj)
    check('H53,34: representation faithful, 102 orthogonal pairs of 1378', orth == 102 and not bad)
    qu = np.array([16, 28, -7.])
    w = spec(qa, qb, qu)
    check('H53,34: spectrum of P_a+P_b+P_u = 0.57095612, 0.91252305, 1.51652083', np.allclose(w, [0.57095612, 0.91252305, 1.51652083], atol=1e-8))
    check('H53,34: these are roots of 9801 x^3 - 29403 x^2 + 27156 x - 7744', all(abs(9801*l**3 - 29403*l**2 + 27156*l - 7744) < 1e-6 for l in w))
    check("H53,34: spectrum of P_a'+P_b'+P_u = 0.54898049, 0.97527351, 1.47574600", np.allclose(spec(vec["a'"], vec["b'"], qu), [0.54898049, 0.97527351, 1.47574600], atol=1e-8))
    B = P(qu) - P(full['y5']) + P(full['y9'])
    check('H53,34: spectrum of B_53 = -0.62955192, 0.08402613, 1.54552580', np.allclose(np.linalg.eigvalsh(B), [-0.62955192, 0.08402613, 1.54552580], atol=1e-8))
    check('H53,34: restrictions to (u,y5,y9) are 000,001,010,100,110,111',
          sorted({(int(u in s), int('y5' in s), int('y9' in s)) for s in S}) == [(0, 0, 0), (0, 0, 1), (0, 1, 0), (1, 0, 0), (1, 1, 0), (1, 1, 1)])
    M = np.array([[1.0 if v in e else 0 for v in V] for e in H53])
    chi = np.array([1.0 if v in ('a', 'b', u) else 0 for v in V])
    check('H53,34: incidence rank 34, rank 35 with the indicator of U', np.linalg.matrix_rank(M) == 34 and np.linalg.matrix_rank(np.vstack([M, chi])) == 35)
    check('H53,34: Born probability of u in the state q_c equals 8/9', abs((qc @ qu)**2 / (2 * (qu @ qu)) - 8/9) < 1e-12)

    # ---------------- roof-twin cascades
    def Bug(x, y, l):
        return [(l+1, l+2, l+3), (l+7, l+8, l+9), (l+2, l+8, l+5), (l+3, y, l+14), (l+7, y, l+15), (l+9, x, l+23), (l+1, x, l+19)]
    I16 = Bug(10, 11, 0) + [(4, 11, 24), (4, 10, 18)]
    G27 = I16 + Bug(18, 24, 100)
    G4125 = G27 + [(14, 27, 26), (18, 28, 26)] + Bug(27, 28, 200)
    G4126 = G4125 + [(4, 5, 105)]
    for name, E, want in [('I16,9', I16, (6, 12, 22)), ('G27,16', G27, (36, 54, 82)), ('G41,25', G4125, (216, 216, 396)), ('G41,26', G4126, (48, 63, 107))]:
        S, C, adj, ext = census(E)
        check(f'{name}: (N_c, extendable, states) = {want}', (len(C), len(ext), len(S)) == want)
        if name == 'G27,16':
            check('G27,16: s(11)=s(18) and s(10)=s(24) on all states', all((11 in s) == (18 in s) and (10 in s) == (24 in s) for s in S))
        if name.startswith('G41'):
            check(f'{name}: s(11)=s(18)=s(27), s(14)=s(28), s(3)=s(26) on all states',
                  all((11 in s) == (18 in s) == (27 in s) and (14 in s) == (28 in s) and (3 in s) == (26 in s) for s in S))
            check(f'{name}: s(3)+s(27)+s(28)=1 on all states; 3,27,28 pairwise nonadjacent',
                  all((3 in s) + (27 in s) + (28 in s) == 1 for s in S) and all(y not in adj[x] for x, y in itertools.combinations((3, 27, 28), 2)))
    check('G41,26: spectrum of P_3+P_27+P_28 has range [0.68238324, 1.35933946]',
          np.allclose(spec((0, 1, -1), (8, -5, -11), (-13, -5, -4))[[0, 2]], [0.68238324, 1.35933946], atol=1e-8))
    check('G41,26: Born total at r_3 equals 457/420', abs(1 + 36/420 + 1/420 - 457/420) < 1e-15 and (np.array([0, 1, -1]) @ np.array([8, -5, -11]))**2 == 36)
    check('G41,26: spectrum of P_11-P_18 = -1/3, 0, 1/3', np.allclose(np.linalg.eigvalsh(P(np.array([1, -1, -1.])) - P(np.array([1, -1, -2.]))), [-1/3, 0, 1/3]))
    al, be = 9/32, 24/11
    t3 = np.array([0, al, -1]); t10 = np.array([1, -al*be, be]); t11 = np.array([al*be, -1, -al])
    t4 = np.cross(t10, t11); t14 = np.cross(t11, t3); t18 = np.cross(t4, t10)
    t26 = np.cross(t14, t18); t27 = np.cross(t26, t14); t28 = np.cross(t26, t18)
    check('G41,25: |r_4| = 45305/15488 at (alpha,beta)=(9/32,24/11)', abs(np.linalg.norm(t4) - 45305/15488) < 1e-12)
    check('G41,25: spectrum of P_3+P_27+P_28 has range [0.79852694, 1.21074603]', np.allclose(spec(t3, t27, t28)[[0, 2]], [0.79852694, 1.21074603], atol=1e-8))
    print('ALL CHECKS PASSED' if ok else 'SOME CHECKS FAILED')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
