#!/usr/bin/env python3
"""Checks for the Yu-Oh restrictions H_{21,13} and H_{20,12}.

Supports the statements in Sec. V ("Completeness on color classes only") of the
short paper:

  (1) the printed rays of H_{21,13} form a faithful orthogonal representation;
  (2) H_{21,13} has 21 two-valued states, 2 normalized colorings, 21 independent
      triples that are rainbow in every strong 3-coloring, and the stated state
      restrictions and spectra of the hub, core and coplanar triples;
  (3) H_{20,12} = H_{21,13} minus {6,13,22} has a faithful representation (the
      Yu-Oh rays are NOT faithful for it, because r6 is orthogonal to r13), two
      chromatic admissible triples, classical totals in [1,3] on its 25 states,
      and quantum minimum 0.7296... on both triples;
  (4) among all 2^13 - 1 nonempty context subsets of H_{21,13}, none with fewer
      than 12 contexts has a triple that is rainbow in every strong 3-coloring
      and pairwise nonorthogonal.

Requires Python 3 and NumPy (NumPy only for the 3x3 spectra).
Run:  python check_H20_H21.py
"""
import itertools, sys
from fractions import Fraction
import numpy as np

sys.setrecursionlimit(10000)

BASE = [(1, 2, 3), (4, 5, 6), (7, 8, 9), (2, 5, 8)]
SECTORS = [(9, 10, 23), (1, 10, 19), (4, 10, 18),
           (3, 11, 14), (7, 11, 15), (4, 11, 24),
           (1, 13, 20), (7, 13, 21), (6, 13, 22)]
H21 = BASE + SECTORS
H20 = [e for e in H21 if set(e) != {6, 13, 22}]


def cross(u, v):
    return (u[1]*v[2]-u[2]*v[1], u[2]*v[0]-u[0]*v[2], u[0]*v[1]-u[1]*v[0])


def dot(u, v):
    return sum(a*b for a, b in zip(u, v))


YO = {1: (0, 1, 1), 2: (1, 0, 0), 3: (0, 1, -1), 4: (1, 1, 0), 5: (0, 0, 1),
      6: (1, -1, 0), 7: (1, 0, 1), 8: (0, 1, 0), 9: (1, 0, -1),
      10: (1, -1, 1), 11: (1, -1, -1), 13: (1, 1, -1)}
for (x, h, w) in SECTORS:            # third ray of each sector context
    YO[w] = cross(YO[x], YO[h])

# Faithful integer rays for H_{20,12} (comparison archive, configurations.py).
H20_RAYS = {1: (0, 1, 2), 2: (1, 0, 0), 3: (0, 2, -1), 4: (1, 1, 0), 5: (0, 0, 1),
            6: (1, -1, 0), 7: (2, 0, 1), 8: (0, 1, 0), 9: (1, 0, -2),
            10: (2, -2, 1), 11: (1, -1, -2), 13: (1, 4, -2), 14: (5, 1, 2),
            15: (1, 5, -2), 18: (1, -1, -4), 19: (5, 4, -2), 20: (-10, 2, -1),
            21: (-4, 5, 8), 23: (4, 5, 2), 24: (1, -1, 1)}


def adjacency(E):
    adj = {}
    for e in E:
        for a in e:
            adj.setdefault(a, set()).update(b for b in e if b != a)
    return adj


def states(E):
    """All two-valued states: exactly one vertex of value 1 in each context."""
    res = []

    def rec(i, chosen):
        if i == len(E):
            res.append(chosen)
            return
        hit = [v for v in E[i] if v in chosen]
        if len(hit) > 1:
            return
        if len(hit) == 1:
            rec(i+1, chosen)
            return
        for v in E[i]:
            if all(v not in E[j] for j in range(i)):
                rec(i+1, chosen | {v})
    rec(0, frozenset())
    return set(res)


def colorings(E, d=3):
    """Strong d-colorings with the first context colored (0,1,...,d-1)."""
    adj = adjacency(E)
    V = sorted(adj)
    col = {v: k for k, v in enumerate(E[0])}
    res = []

    def rec():
        best = None
        for v in V:
            if v in col:
                continue
            free = [k for k in range(d) if all(col.get(u) != k for u in adj[v])]
            if not free:
                return
            if best is None or len(free) < len(best[1]):
                best = (v, free)
        if best is None:
            res.append(dict(col))
            return
        v, free = best
        for k in free:
            col[v] = k
            rec()
            del col[v]
    rec()
    return res


def components(E):
    comps = []
    for e in E:
        touching = [c for c in comps if c[0] & set(e)]
        new = (set(e), [e])
        for c in touching:
            new[0].update(c[0])
            new[1].extend(c[1])
            comps.remove(c)
        comps.append(new)
    return [c[1] for c in comps]


def faithful(rays, E):
    adj = adjacency(E)
    orth, bad = 0, []
    for a, b in itertools.combinations(sorted(rays), 2):
        o = dot(rays[a], rays[b]) == 0
        orth += o
        if o != (b in adj[a]):
            bad.append((a, b))
        if cross(rays[a], rays[b]) == (0, 0, 0):
            bad.append(('parallel', a, b))
    return orth, bad


def spectrum(rays, T):
    P = sum(np.outer(rays[t], rays[t]) / dot(rays[t], rays[t]) for t in T)
    return np.linalg.eigvalsh(np.array(P, dtype=float))


def always_rainbow_triples(E, nonorth):
    """Triples that are rainbow in every strong 3-coloring and pairwise 'nonorth'.

    A triple meeting two connected components is never always-rainbow, because
    the colors of different components can be permuted independently.
    """
    out = []
    for comp in components(E):
        C = colorings(comp)
        V = sorted(set().union(*comp))
        for T in itertools.combinations(V, 3):
            if all(nonorth(x, y) for x, y in itertools.combinations(T, 2)) and \
               all(len({c[t] for t in T}) == 3 for c in C):
                out.append(T)
    return out


def main():
    ok = True

    def check(label, cond):
        nonlocal ok
        ok &= bool(cond)
        print(('PASS  ' if cond else 'FAIL  ') + label)

    # (1), (2): H21
    orth, bad = faithful(YO, H21)
    check('H21,13: Yu-Oh rays faithful, 39 orthogonal pairs of 210', orth == 39 and not bad)
    S = states(H21); C = colorings(H21); adj = adjacency(H21)
    ext = {frozenset(v for v in c if c[v] == k) for c in C for k in range(3)}
    check('H21,13: 21 states, 6 extendable, 2 normalized colorings',
          (len(S), len(ext), len(C)) == (21, 6, 2))
    adm = always_rainbow_triples(H21, lambda x, y: y not in adj[x])
    check('H21,13: 21 chromatic admissible triples', len(adm) == 21)
    pat = lambda T: sorted({''.join(str(int(t in s)) for t in T) for s in S})
    check('H21,13: hub triple restrictions 000,001,010,100', pat((10, 11, 13)) == ['000', '001', '010', '100'])
    allbut111 = sorted(''.join(p) for p in itertools.product('01', repeat=3) if ''.join(p) != '111')
    check('H21,13: core and coplanar triples take all restrictions except 111',
          pat((1, 4, 7)) == allbut111 and pat((3, 6, 9)) == allbut111)
    for name, T, want in [('hub', (10, 11, 13), (1/3, 4/3, 4/3)), ('core', (1, 4, 7), (.5, .5, 2)), ('coplanar', (3, 6, 9), (0, 1.5, 1.5))]:
        check(f'H21,13: spectrum of the {name} triple = {tuple(round(w, 4) for w in want)}',
              np.allclose(spectrum(YO, T), want))

    # (3): H20
    orth, bad = faithful({k: v for k, v in YO.items() if k != 22}, H20)
    check('H20,12: Yu-Oh rays are NOT faithful (extra pair 6,13)', bad == [(6, 13)])
    orth, bad = faithful(H20_RAYS, H20)
    check('H20,12: separate integer rays faithful, 36 orthogonal pairs of 190', orth == 36 and not bad)
    S = states(H20); C = colorings(H20); adj20 = adjacency(H20)
    ext = {frozenset(v for v in c if c[v] == k) for c in C for k in range(3)}
    check('H20,12: 25 states, 10 extendable, 4 normalized colorings', (len(S), len(ext), len(C)) == (25, 10, 4))
    adm = always_rainbow_triples(H20, lambda x, y: y not in adj20[x])
    check('H20,12: chromatic admissible triples are {15,18,20} and {19,21,24}', adm == [(15, 18, 20), (19, 21, 24)])
    for T in adm:
        sums = [sum(t in s for t in T) for s in S]
        w = spectrum(H20_RAYS, T)
        print(f'      {T}: classical totals {min(sums)}..{max(sums)}; quantum spectrum {np.round(w, 8)}')
        check(f'H20,12 {T}: classical minimum 1, quantum minimum 0.72960967 < 1',
              min(sums) == 1 and max(sums) == 3 and abs(w[0]-0.72960967) < 1e-8 and abs(w[2]-1.23483806) < 1e-8)

    # (4): subset search
    adj21 = adjacency(H21)
    geo = lambda x, y: dot(YO[x], YO[y]) != 0          # nonorthogonal Yu-Oh rays
    best = {}
    for m in range(1, 14):
        for sub in itertools.combinations(range(13), m):
            E = [H21[i] for i in sub]
            a = adjacency(E)
            tg = always_rainbow_triples(E, geo)
            tc = always_rainbow_triples(E, lambda x, y: y not in a[x])
            if tg: best.setdefault(('geometric', m), []).append((sub, tg))
            if tc: best.setdefault(('combinatorial', m), []).append((sub, tc))
    for kind in ('geometric', 'combinatorial'):
        sizes = sorted(m for (k, m) in best if k == kind)
        print(f'      {kind}: context numbers with an always-rainbow pairwise-nonorthogonal triple: {sizes}')
        for m in sizes[:1]:
            for sub, tr in best[(kind, m)]:
                missing = [H21[i] for i in range(13) if i not in sub]
                print(f'        {m} contexts, deleted {missing}: {tr}')
    gmin = min(m for (k, m) in best if k == 'geometric')
    cmin = min(m for (k, m) in best if k == 'combinatorial')
    check('subset search: no such triple below 12 contexts (nonorthogonality in the Yu-Oh rays)', gmin == 12)
    check('subset search: no such triple below 12 contexts (nonadjacency in the subhypergraph)', cmin == 12)
    print('ALL CHECKS PASSED' if ok else 'SOME CHECKS FAILED')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
