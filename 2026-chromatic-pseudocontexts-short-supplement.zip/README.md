# Supplemental Material

For the short paper *Two-Valued States Can Force Nonorthogonal Rays to Behave as a
Context* (working title; source `2026-chromatic-pseudocontexts-short.tex`).

Assembled 15 November 2026 from three sources:

| Folder | What it is | Origin |
|---|---|---|
| `certificates/` | Exact certificates and verifiers for the 53-ray and 41-ray constructions | Codex run of 30/31 October 2026, unchanged |
| `checks/` | Two short, independent recounts of every number quoted in the short paper | written 15 November 2026 |
| `chromatic-comparison/` | Classical and quantum comparison for all 19 configurations | `2026-chromatic-pseudocontexts-comparison.zip` of 12 November 2026, unchanged |
| `manuscript/` | The long version of the paper, with BBL, PDF and bibliography | same archive, unchanged |

## Which file supports which statement

| Statement in the short paper | File |
|---|---|
| Sec. III: $H_{53,34}$ has a faithful real representation; 1378 pairs, 102 orthogonal | `certificates/H53/two-valued-admissible-context-certificate.json`, `certificates/H53/verify-two-valued-admissible-context.py` |
| Sec. III: 224 states, 128 extendable, 128 normalized colorings; restrictions 80/80/64 | same certificate; `certificates/H53/H53-34-census.json`; `checks/check_H53_G41.py` |
| Sec. III: quantum range $[0.57095612, 1.51652083]$; second triple; three-term inequality with maximum 1.54552580 | `checks/check_H53_G41.py`; `chromatic-comparison/results/H53.json` |
| Sec. IV: $G_{27,16}$, $G_{41,25}$, $G_{41,26}$: contexts, rays, all states and colorings, faithfulness, Born total 457/420 | `certificates/roof-twin/roof-twin-cascade-certificate.json`, `certificates/roof-twin/verify-roof-twin-cascade.py` |
| Sec. IV: counts (36,54,82), (216,216,396), (48,63,107); twin identities; quantum ranges | same certificate; `checks/check_H53_G41.py` |
| Sec. V: $H_{21,13}$: faithful Yu--Oh rays, 21 states, 2 colorings, 21 chromatic admissible triples, spectra of the hub, core and coplanar triples | `checks/check_H20_H21.py` |
| Sec. V: $H_{20,12}$ needs its own representation; quantum minimum 0.72960967 below the classical bound one | `checks/check_H20_H21.py` (rays as in `chromatic-comparison/configurations.py`) |
| Sec. V: no always-rainbow pairwise nonorthogonal triple with fewer than 12 contexts | `checks/check_H20_H21.py`, part (4): all $2^{13}-1$ context subsets |
| Sec. VI: $R_{21,12}$, $R_{25,15}$, Specker bug, Mayet, octagon: states, colorings, paired relations | `chromatic-comparison/results/R21.json`, `R25.json`, `B13.json`, `M15.json`, `Oct20.json` |
| Introduction: comparison across 19 configurations, parameter-dependent bounds | `chromatic-comparison/COMPARISON.md` and `results/` |
| Introduction: four-dimensional examples, weighted operators, classical envelopes, census tables | so far only as text in `manuscript/2026-chromatic-pseudocontexts.tex` (long version) |

## How to run

The two scripts in `checks/` need Python 3 and NumPy only:

```
python checks/check_H53_G41.py
python checks/check_H20_H21.py
```

Their output of 15 November 2026 is stored next to them (`*-output.txt`); every
line reads `PASS`.

The verifiers in `certificates/` need SymPy and mpmath in addition:

```
python certificates/H53/verify-two-valued-admissible-context.py
python certificates/roof-twin/verify-roof-twin-cascade.py
```

The first one rebuilds its certificate file in place. For `chromatic-comparison/`
see its own `README.md`.

## Notes

- `checks/` rebuilds each hypergraph and its rays from the formulas printed in the
  paper and does not read the certificates. Orthogonality of the 53 rays is tested
  there in floating point; the exact test is the SymPy verifier.
- The SymPy verifiers were not rerun when this archive was assembled. The state
  counts stored in both certificates were compared with an independent recount and
  agree.
- The two `.tikz` files are the standalone figure sources of 31 October 2026. The
  figures printed in the paper differ from them in a few lines and are
  authoritative.
- `manuscript/` holds the long version, not the short paper. It uses the
  "Context--Color Matrix" wording, cites a companion manuscript on that topic which
  the short paper no longer needs, and contains the full shared bibliography file
  `svozil.bib`. `chromatic-comparison/manifest.json` records checksums for these
  files, so they are kept unchanged here.
- Not included: a separate supplement text. The parts that the short paper defers
  (weighted operators, classical envelopes, four-dimensional examples, census
  tables) still have to be extracted from the long version.
