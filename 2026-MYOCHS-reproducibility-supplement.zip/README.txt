Reproducibility supplement for 2026-MYOCHS
===========================================

Files
-----
2026-MYOCHS-referee2-revision.tex
    The exact manuscript source from which the qutrit input tables are read.

verify_myochs.py
    Standard-library Python script. It reconstructs the qutrit ray and context
    inventories using exact arithmetic in Q(omega), computes lineage
    memberships, and enumerates exact-one two-valued states. It independently
    enumerates the complete orthogonality hypergraph of the concrete D=4
    20-ray realization and its B10, B13, and B17 state spaces.

qutrit_inventory.json
    Machine-readable 225 labelled generation outputs, 165 canonical rays,
    all 130 contexts, ray/context lineage memberships and bitmasks, and lineage
    state counts.

d4_inventory.json
    Machine-readable 20 rays, all 17 supported contexts, the imposed,
    disjoint-support and equality-induced partitions, and every two-valued
    state for B10, B13, and B17 represented by its true rays.

Running the verification
------------------------
With Python 3.10 or later, from this directory run:

    python verify_myochs.py

The script overwrites the two JSON files only after all internal assertions
pass. No third-party packages, network connection, floating-point arithmetic,
or numerical tolerance is used.

Expected summary
----------------
qutrit: 165 rays, 130 contexts
ray memberships: 48 exclusive to each lineage and 21 common to all three
mixed-lineage-only contexts: 0
each lineage: 69 rays, 50 contexts, 4 all-exclusive contexts, 0 states
D4 B10: 10 contexts, 36 separating states
D4 B13: 13 contexts, 36 separating states
D4 B17: 17 contexts, 16 separating states
