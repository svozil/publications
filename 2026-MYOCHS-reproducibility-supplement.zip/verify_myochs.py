#!/usr/bin/env python3
"""Reproduce the exact finite inventories reported in 2026-MYOCHS.

Only the Python standard library is required.  The qutrit input is read from
Tables I and II of the accompanying LaTeX source.  Arithmetic is exact in
Q(omega), omega^2 + omega + 1 = 0.  The D=4 concrete rays are specified below
with integer coordinates and independently searched for all orthogonal bases.
"""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import re
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path


@dataclass(frozen=True)
class Qw:
    """Element a + b*omega of Q(omega), with omega^2 = -1 - omega."""

    a: Fraction = Fraction(0)
    b: Fraction = Fraction(0)

    def __add__(self, other: "Qw") -> "Qw":
        return Qw(self.a + other.a, self.b + other.b)

    def __neg__(self) -> "Qw":
        return Qw(-self.a, -self.b)

    def __sub__(self, other: "Qw") -> "Qw":
        return self + (-other)

    def __mul__(self, other: "Qw") -> "Qw":
        return Qw(
            self.a * other.a - self.b * other.b,
            self.a * other.b + self.b * other.a - self.b * other.b,
        )

    def inv(self) -> "Qw":
        norm = self.a * self.a - self.a * self.b + self.b * self.b
        if norm == 0:
            raise ZeroDivisionError("division by zero in Q(omega)")
        return Qw((self.a - self.b) / norm, -self.b / norm)

    def __truediv__(self, other: "Qw") -> "Qw":
        return self * other.inv()

    def conj(self) -> "Qw":
        return Qw(self.a - self.b, -self.b)

    def is_zero(self) -> bool:
        return self.a == 0 and self.b == 0


ZERO = Qw()


def fraction_text(value: Fraction) -> str:
    return str(value.numerator) if value.denominator == 1 else f"{value.numerator}/{value.denominator}"


def qw_text(value: Qw) -> str:
    if value.b == 0:
        return fraction_text(value.a)
    b_abs = abs(value.b)
    b_term = "omega" if b_abs == 1 else f"{fraction_text(b_abs)}*omega"
    if value.a == 0:
        return b_term if value.b > 0 else f"-{b_term}"
    sign = "+" if value.b > 0 else "-"
    return f"{fraction_text(value.a)}{sign}{b_term}"


def parse_scalar(raw: str) -> Qw:
    token = raw.strip().replace("{", "").replace("}", "")
    token = token.replace(r"\omega", "w").replace(" ", "")
    if token == "0":
        return ZERO
    sign = -1 if token.startswith("-") else 1
    if token[:1] in "+-":
        token = token[1:]
    if "w" not in token:
        return Qw(Fraction(sign * int(token)))
    coefficient_text = token.split("w", 1)[0]
    coefficient = int(coefficient_text) if coefficient_text else 1
    if "^2" in token:
        return Qw(Fraction(-sign * coefficient), Fraction(-sign * coefficient))
    return Qw(Fraction(0), Fraction(sign * coefficient))


def canonical(vector: tuple[Qw, ...]) -> tuple[Qw, ...]:
    pivot = next((entry for entry in vector if not entry.is_zero()), None)
    if pivot is None:
        raise ValueError("zero vector has no projective representative")
    return tuple(entry / pivot for entry in vector)


def inner(left: tuple[Qw, ...], right: tuple[Qw, ...]) -> Qw:
    total = ZERO
    for x, y in zip(left, right):
        total = total + x.conj() * y
    return total


def clean_label(label: str) -> str:
    return label.replace("{", "").replace("}", "")


def extract_generation(text: str) -> tuple[list[dict[str, object]], list[set[tuple[Qw, ...]]]]:
    start = text.index(r"\label{tab:vector_generation}")
    end = text.index(r"\end{table*}", start)
    table = text[start:end]
    outputs: list[dict[str, object]] = []
    lineages = [set(), set(), set()]
    row_number = 0
    for line in table.splitlines():
        coordinate_groups = re.findall(r"\(([^()]*)\)", line)
        if len(coordinate_groups) != 9:
            continue
        row_number += 1
        rule_label = line.split("&", 1)[0].strip().replace("$", "")
        vectors = [tuple(parse_scalar(item) for item in group.split(",")) for group in coordinate_groups]
        for column, vector in enumerate(vectors, 1):
            ray = canonical(vector)
            lineage = (column - 1) // 3 + 1
            lineages[lineage - 1].add(ray)
            outputs.append(
                {
                    "rule_row": row_number,
                    "rule_label_tex": rule_label,
                    "seed_column": column,
                    "lineage": lineage,
                    "coordinates": [qw_text(x) for x in vector],
                    "canonical_coordinates": [qw_text(x) for x in ray],
                }
            )
    if row_number != 25 or len(outputs) != 225:
        raise AssertionError(f"expected 25 rows and 225 outputs, found {row_number} and {len(outputs)}")
    return outputs, lineages


def extract_qutrit_rays(text: str) -> dict[str, tuple[Qw, ...]]:
    start = text.index(r"\label{tab:noncollinear_vectors_6col}")
    end = text.index(r"\end{table*}", start)
    table = text[start:end]
    pattern = re.compile(r"\$([A-Za-z]+_\{?\d+\}?)[ ]*=\(([^)]*)\)\$")
    rays: dict[str, tuple[Qw, ...]] = {}
    for label, coordinates in pattern.findall(table):
        ray_label = clean_label(label)
        vector = tuple(parse_scalar(item) for item in coordinates.split(","))
        if len(vector) != 3:
            raise AssertionError((ray_label, coordinates))
        rays[ray_label] = vector
    if len(rays) != 165:
        raise AssertionError(f"expected 165 qutrit rays, parsed {len(rays)}")
    return rays


def orthogonality_contexts(
    rays: dict[str, tuple[Qw, ...]], dimension: int
) -> tuple[list[tuple[str, ...]], dict[str, set[str]]]:
    labels = list(rays)
    order = {label: index for index, label in enumerate(labels)}
    neighbors = {label: set() for label in labels}
    for index, left in enumerate(labels):
        for right in labels[index + 1 :]:
            if inner(rays[left], rays[right]).is_zero():
                neighbors[left].add(right)
                neighbors[right].add(left)
    contexts: list[tuple[str, ...]] = []
    for candidate in itertools.combinations(labels, dimension):
        if all(right in neighbors[left] for left, right in itertools.combinations(candidate, 2)):
            contexts.append(tuple(sorted(candidate, key=order.get)))
    contexts.sort(key=lambda context: tuple(order[label] for label in context))
    return contexts, neighbors


def exact_one_states(vertices: list[str], contexts: list[tuple[str, ...]]) -> list[dict[str, int]]:
    index = {vertex: position for position, vertex in enumerate(vertices)}
    constraints = [tuple(index[vertex] for vertex in context) for context in contexts]
    states: list[dict[str, int]] = []

    def propagate(values: list[int]) -> bool:
        changed = True
        while changed:
            changed = False
            for block in constraints:
                ones = sum(values[position] == 1 for position in block)
                unknown = [position for position in block if values[position] < 0]
                if ones > 1 or (ones == 0 and not unknown):
                    return False
                if ones == 1:
                    for position in unknown:
                        values[position] = 0
                        changed = True
                elif len(unknown) == 1:
                    values[unknown[0]] = 1
                    changed = True
        return True

    def search(values: list[int]) -> None:
        if not propagate(values):
            return
        unresolved = [block for block in constraints if all(values[position] != 1 for position in block)]
        if not unresolved:
            if any(value < 0 for value in values):
                position = values.index(-1)
                for choice in (0, 1):
                    branch = values.copy()
                    branch[position] = choice
                    search(branch)
                return
            states.append({vertex: values[position] for vertex, position in index.items()})
            return
        block = min(unresolved, key=lambda item: sum(values[position] < 0 for position in item))
        for chosen in (position for position in block if values[position] < 0):
            branch = values.copy()
            branch[chosen] = 1
            search(branch)

    search([-1] * len(vertices))
    return states


def separating(states: list[dict[str, int]], vertices: list[str]) -> bool:
    return bool(states) and all(
        any(state[left] != state[right] for state in states)
        for left, right in itertools.combinations(vertices, 2)
    )


def qutrit_inventory(tex_path: Path) -> dict[str, object]:
    text = tex_path.read_text(encoding="utf-8")
    generation_outputs, generated_lineages = extract_generation(text)
    rays = extract_qutrit_rays(text)
    canonical_rays = {label: canonical(vector) for label, vector in rays.items()}
    if len(set(canonical_rays.values())) != 165:
        raise AssertionError("Table II contains projectively duplicate rays")
    contexts, _ = orthogonality_contexts(rays, 3)

    ray_memberships = {
        label: tuple(index + 1 for index, group in enumerate(generated_lineages) if ray in group)
        for label, ray in canonical_rays.items()
    }
    context_memberships = {
        context: tuple(
            index + 1
            for index, group in enumerate(generated_lineages)
            if all(canonical_rays[label] in group for label in context)
        )
        for context in contexts
    }

    membership_histogram: dict[str, int] = {}
    for membership in ray_memberships.values():
        key = ",".join(map(str, membership))
        membership_histogram[key] = membership_histogram.get(key, 0) + 1

    lineage_summaries: dict[str, object] = {}
    for lineage in (1, 2, 3):
        vertices = [label for label in rays if lineage in ray_memberships[label]]
        blocks = [context for context in contexts if lineage in context_memberships[context]]
        states = exact_one_states(vertices, blocks)
        exclusive_only = [
            context for context in blocks if all(ray_memberships[label] == (lineage,) for label in context)
        ]
        lineage_summaries[str(lineage)] = {
            "ray_count": len(vertices),
            "context_count": len(blocks),
            "exclusive_only_context_count": len(exclusive_only),
            "two_valued_state_count": len(states),
        }

    mixed_only = [context for context, membership in context_memberships.items() if not membership]
    common_contexts = [context for context, membership in context_memberships.items() if membership == (1, 2, 3)]

    assert [len(group) for group in generated_lineages] == [69, 69, 69]
    assert membership_histogram == {"1": 48, "1,2,3": 21, "2": 48, "3": 48}
    assert len(contexts) == 130
    assert len(common_contexts) == 10
    assert not mixed_only
    assert all(lineage_summaries[str(i)]["context_count"] == 50 for i in (1, 2, 3))
    assert all(lineage_summaries[str(i)]["exclusive_only_context_count"] == 4 for i in (1, 2, 3))
    assert all(lineage_summaries[str(i)]["two_valued_state_count"] == 0 for i in (1, 2, 3))

    return {
        "source_file": tex_path.name,
        "source_sha256": hashlib.sha256(tex_path.read_bytes()).hexdigest(),
        "arithmetic": "Q(omega), omega^2 + omega + 1 = 0",
        "labelled_generation_outputs": generation_outputs,
        "ray_count": len(rays),
        "ray_membership_histogram": membership_histogram,
        "rays": [
            {
                "label": label,
                "canonical_coordinates": [qw_text(entry) for entry in canonical_rays[label]],
                "lineages": list(ray_memberships[label]),
                "lineage_bitmask": sum(1 << (lineage - 1) for lineage in ray_memberships[label]),
            }
            for label in rays
        ],
        "context_count": len(contexts),
        "common_context_count": len(common_contexts),
        "mixed_lineage_only_context_count": len(mixed_only),
        "contexts": [
            {
                "rays": list(context),
                "lineages": list(context_memberships[context]),
                "lineage_bitmask": sum(1 << (lineage - 1) for lineage in context_memberships[context]),
            }
            for context in contexts
        ],
        "lineages": lineage_summaries,
    }


def d4_inventory() -> dict[str, object]:
    integer_rays = {
        "u": (1, 1, 1, 1),
        "e1": (1, 0, 0, 0), "e2": (0, 1, 0, 0),
        "e3": (0, 0, 1, 0), "e4": (0, 0, 0, 1),
        "v12": (0, 0, 1, -1), "w12": (0, 0, 1, 1),
        "v13": (0, -1, 0, 1), "w13": (0, 1, 0, 1),
        "v14": (0, 1, -1, 0), "w14": (0, 1, 1, 0),
        "v23": (1, 0, 0, -1), "w23": (1, 0, 0, 1),
        "v24": (-1, 0, 1, 0), "w24": (1, 0, 1, 0),
        "v34": (1, -1, 0, 0), "w34": (1, 1, 0, 0),
        "v1234": (1, 1, -1, -1),
        "v1324": (1, -1, 1, -1),
        "v1423": (1, -1, -1, 1),
    }
    rays = {label: tuple(Qw(Fraction(value)) for value in vector) for label, vector in integer_rays.items()}
    contexts, _ = orthogonality_contexts(rays, 4)
    order = {label: index for index, label in enumerate(rays)}

    def block(*labels: str) -> tuple[str, ...]:
        return tuple(sorted(labels, key=order.get))

    b10 = [
        block("e1", "e2", "e3", "e4"),
        block("e1", "e2", "v12", "w12"), block("e1", "e3", "v13", "w13"),
        block("e1", "e4", "v14", "w14"), block("e2", "e3", "v23", "w23"),
        block("e2", "e4", "v24", "w24"), block("e3", "e4", "v34", "w34"),
        block("u", "v1234", "v34", "v12"),
        block("u", "v1324", "v24", "v13"),
        block("u", "v1423", "v23", "v14"),
    ]
    disjoint = [
        block("v12", "w12", "v34", "w34"),
        block("v13", "w13", "v24", "w24"),
        block("v14", "w14", "v23", "w23"),
    ]
    b13 = b10 + disjoint
    equality = [context for context in contexts if context not in b13]
    b17 = contexts

    def state_summary(blocks: list[tuple[str, ...]]) -> dict[str, object]:
        vertices = list(rays)
        states = exact_one_states(vertices, blocks)
        return {
            "context_count": len(blocks),
            "two_valued_state_count": len(states),
            "separating": separating(states, vertices),
            "states_as_true_rays": [
                [vertex for vertex in vertices if state[vertex] == 1] for state in states
            ],
        }

    summaries = {"B10": state_summary(b10), "B13": state_summary(b13), "B17": state_summary(b17)}
    assert len(contexts) == 17
    assert len(equality) == 4
    assert summaries["B10"]["two_valued_state_count"] == 36
    assert summaries["B13"]["two_valued_state_count"] == 36
    assert summaries["B17"]["two_valued_state_count"] == 16
    assert all(summaries[name]["separating"] for name in summaries)

    return {
        "ray_count": len(rays),
        "rays": [{"label": label, "coordinates": list(vector)} for label, vector in integer_rays.items()],
        "complete_context_count": len(contexts),
        "contexts": [list(context) for context in contexts],
        "imposed_contexts_B10": [list(context) for context in b10],
        "disjoint_support_contexts": [list(context) for context in disjoint],
        "equality_induced_contexts": [list(context) for context in equality],
        "state_enumeration": summaries,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--tex", type=Path, default=Path(__file__).with_name("2026-MYOCHS-referee2-revision.tex"))
    parser.add_argument("--out", type=Path, default=Path(__file__).parent)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    qutrit = qutrit_inventory(args.tex)
    d4 = d4_inventory()
    (args.out / "qutrit_inventory.json").write_text(json.dumps(qutrit, indent=2) + "\n", encoding="utf-8")
    (args.out / "d4_inventory.json").write_text(json.dumps(d4, indent=2) + "\n", encoding="utf-8")

    print("qutrit:", qutrit["ray_count"], "rays,", qutrit["context_count"], "contexts")
    print("qutrit ray memberships:", qutrit["ray_membership_histogram"])
    print("qutrit mixed-lineage-only contexts:", qutrit["mixed_lineage_only_context_count"])
    print("qutrit lineages:", qutrit["lineages"])
    print("D4: 20 rays,", d4["complete_context_count"], "complete contexts")
    for name, summary in d4["state_enumeration"].items():
        print(name, summary["context_count"], "contexts,", summary["two_valued_state_count"], "states, separating =", summary["separating"])


if __name__ == "__main__":
    main()
