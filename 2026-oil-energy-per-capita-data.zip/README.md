# Per-capita figure supplement

Figure 5 divides the annual daily series underlying Figure 4 by midyear world population in the same calendar year. It uses population as a denominator only; it does not change the oil data, mass-to-energy conversion, or joint-return allocation.

Population source: United Nations, Department of Economic and Social Affairs, Population Division, *World Population Prospects 2024*. The selection is `World`, location code `900`, field `TPopulation1July`, both sexes. The source field is in thousands; multiplying by 1,000 gives persons. Historical estimates cover 1965-2023; the 2024 and 2025 population denominators are medium-scenario projections. Population is not extrapolated beyond the published UN series.

Official source: https://population.un.org/wpp/

Download: https://population.un.org/wpp/assets/Excel%20Files/1_Indicator%20(Standard)/CSV_FILES/WPP2024_Demographic_Indicators_Medium.csv.gz

Access date: 17 October 2026. The download checksum and the selection are recorded in `population-source.json`. The selected 61 original UN rows are preserved in full in `world-population-source-rows-1965-2025.csv`. Population values are estimated or projected; printing them to persons does not imply person-level measurement accuracy.

Definitions, with P in persons, q in million barrels/day, and g and n in EJ/day:

- Volume per person per day = 1,000,000 q / P, in barrels.
- Gross equivalent per person per day = 1,000,000,000,000 g / P, in MJ.
- Net-equivalent proxy per person per day = 1,000,000,000,000 n / P, in MJ, available only for 1971-2020.

These are production averages across world population. They do not measure individual consumption, equal distribution, or access to supply. The actual oil-only 2025 return remains unavailable. No net-equivalent values are extended beyond 2020.

Run `python recalculate_per_capita.py` in this directory to recalculate all quotients using Python's standard library and decimal arithmetic. The program checks the delivered quotient table, the missing years, and all three available-period maxima. It writes `recalculated-per-capita.csv`. The original inputs are not changed.

The highest annual per-capita values occur in 1979: approximately 0.015123 barrels/day and 85.011 MJ/day gross equivalent; the net-equivalent proxy is approximately 82.908 MJ/day. In 2025, the corresponding available values are 0.012220 barrels/day and 65.509 MJ/day gross equivalent, 19.20% and 22.94% below 1979. The latest net-equivalent proxy is for 2020, not 2025.

`figure-per-capita.tex` retains the editable drawing and embedded annual quotient table. Include it in a LaTeX document with pgfplots and the same figure-reference context. The complete manuscript already embeds the same table and drawing. The small bibliography supplement must remain beside the complete manuscript, together with the existing `svozil.bib`.
