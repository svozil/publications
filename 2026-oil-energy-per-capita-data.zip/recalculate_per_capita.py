"""Recalculate the per-person daily rates from the two preserved source extracts."""
from pathlib import Path
from decimal import Decimal, getcontext
import csv, json

getcontext().prec=40
root=Path(__file__).resolve().parent
with (root/'world-population-source-rows-1965-2025.csv').open(encoding='utf-8',newline='') as f:
    population={int(r['Time']):Decimal(r['TPopulation1July'])*1000 for r in csv.DictReader(f) if r['Location']=='World' and r['LocID']=='900'}
with (root/'oil-inputs-for-per-capita.csv').open(encoding='utf-8',newline='') as f:
    oil=list(csv.DictReader(f))
with (root/'oil-per-capita-1965-2025.csv').open(encoding='utf-8',newline='') as f:
    saved={int(r['year']):r for r in csv.DictReader(f)}
assert set(population)==set(saved)==set(range(1965,2026))
out=[]
for r in oil:
    y=int(r['year']);p=population[y]
    q=Decimal(r['oil_million_barrels_per_day'])*10**6/p
    g=Decimal(r['gross_EJ_per_day'])*10**12/p
    n=Decimal(r['net_proxy_EJ_per_day'])*10**12/p if r['net_proxy_EJ_per_day'] else None
    assert abs(p-Decimal(saved[y]['population_persons']))==0
    assert abs(q-Decimal(saved[y]['oil_barrels_per_person_per_day']))<Decimal('1e-16')
    assert abs(g-Decimal(saved[y]['gross_MJ_per_person_per_day']))<Decimal('1e-11')
    if n is None:
        assert not saved[y]['net_proxy_MJ_per_person_per_day']
        assert y<1971 or y>2020
    else:
        assert abs(n-Decimal(saved[y]['net_proxy_MJ_per_person_per_day']))<Decimal('1e-11')
        assert 1971<=y<=2020
    out.append(dict(year=y,population_persons=int(p),oil_barrels_per_person_per_day=str(q),gross_MJ_per_person_per_day=str(g),net_proxy_MJ_per_person_per_day=str(n) if n is not None else ''))
with (root/'recalculated-per-capita.csv').open('w',encoding='utf-8',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
assert max(out,key=lambda r:Decimal(r['oil_barrels_per_person_per_day']))['year']==1979
assert max(out,key=lambda r:Decimal(r['gross_MJ_per_person_per_day']))['year']==1979
assert max((r for r in out if r['net_proxy_MJ_per_person_per_day']),key=lambda r:Decimal(r['net_proxy_MJ_per_person_per_day']))['year']==1979
print('Verified 61 population denominators and 172 available per-capita values. All three available-period maxima occur in 1979.')
