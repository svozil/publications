"""Check that each 69-ray, 50-context lineage of Navara & Svozil,
Int. J. Theor. Phys. 65, 322 (2026), is isomorphic to the 69-50 hypergraph of
M. Pavicic, Quantum 7, 953 (2023), Fig. 10(e), p. 55 (also listed in
Pavicic & Megill, Phys. Rev. A 106, L060203 (2022), Table I).

The lineages are generated with the 25 rules of Sect. 2 of the corrected
manuscript (2026-MYOCHS-final.tex). Requires numpy and networkx.
"""
import itertools, cmath, collections
import numpy as np
import networkx as nx
from networkx.algorithms import isomorphism as iso

# Pavicic's 69-50 hyperedge string, Quantum 7, 953 (2023), p. 55
PAVICIC_69_50 = ("451,176,6wK,KLG,G3H,HNM,MqD,DC2,2AB,BmX,XWR,RZY,Y&8,8%U,UVQ,QST,TId,"
                 "dca,aef,f$F,F#h,hgb,bij,jt4,123,189,2EF,GIJ,HOP,QR3,ab3,ATk,AYl,BUn,CIo,"
                 "COp,DKr,4fs,5hu,5dv,6Ox,M7y,MXh,Iz7,KUf,OYj,Ed!,Ej\",X90,T(9")

w = cmath.exp(2j * cmath.pi / 3)
seeds = [(1, 1, 1), (1, w, w**2), (1, w**2, w),          # B_1
         (1, w, w), (1, w**2, 1), (1, 1, w**2),          # B_2
         (1, w**2, w**2), (1, w, 1), (1, 1, w)]          # B_3

def X(x, y):  # Hermitian cross product, Sect. 2
    return np.conj(np.array([x[1]*y[2]-x[2]*y[1], x[2]*y[0]-x[0]*y[2], x[0]*y[1]-x[1]*y[0]]))

def rules(u):
    u = np.array(u, dtype=complex); a = list(np.eye(3, dtype=complex))
    c = [-X(a[i], u) for i in range(3)]
    b = [X(a[i], c[i]) for i in range(3)]
    d = [X(u, c[i]) for i in range(3)]
    b12, b13, b23 = X(b[0], b[1]), -X(b[0], b[2]), X(b[1], b[2])
    e = [X(c[0], b23), X(c[1], b13), X(c[2], b12)]
    rest = [-X(b[0], b12), X(b[0], b13), X(b[1], b12), -X(b[1], b23), -X(b[2], b13), X(b[2], b23)]
    return a + [u] + c + b + d + [b12, b13, b23] + e + rest   # 25 vectors

def key(v):
    k = next(i for i in range(3) if abs(v[i]) > 1e-9); v = v / v[k]
    return tuple(np.round(v.real, 9)) + tuple(np.round(v.imag, 9))

def lineage(r):
    R = {}
    for s in seeds[3*r:3*r+3]:
        for v in rules(s):
            assert np.linalg.norm(v) > 1e-9
            R.setdefault(key(v), v)
    R = list(R.values())
    ctx = [t for t in itertools.combinations(range(len(R)), 3)
           if all(abs(np.vdot(R[i], R[j])) < 1e-9 for i, j in itertools.combinations(t, 2))]
    return R, ctx

def incidence(edges):
    G = nx.Graph()
    for i, e in enumerate(edges):
        G.add_node(('e', i), t='e')
        for v in e:
            G.add_node(('v', v), t='v'); G.add_edge(('e', i), ('v', v))
    return G

P = [tuple(s) for s in PAVICIC_69_50.split(',')]
GP = incidence(P)
print('Pavicic 69-50:', len({v for e in P for v in e}), 'vertices,', len(P), 'hyperedges')
for r in range(3):
    R, ctx = lineage(r)
    m = collections.Counter(i for t in ctx for i in t)
    same = iso.GraphMatcher(GP, incidence(ctx), node_match=lambda x, y: x['t'] == y['t']).is_isomorphic()
    print(f'lineage B_{r+1}: {len(R)} rays, {len(ctx)} contexts, '
          f'multiplicities {sorted(collections.Counter(m.values()).items())}, '
          f'isomorphic to Pavicic 69-50: {same}')
