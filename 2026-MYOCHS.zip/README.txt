Navara & Svozil, Int. J. Theor. Phys. 65, 322 (2026): erratum package (21 November 2026)

2026-MYOCHS-erratum.tex          one-page erratum paper (revtex4-2)
2026-MYOCHS-final.tex            corrected manuscript (for arXiv:2509.08636v3)
2026-MYOCHS-final-diff.tex       same, with changes against the published article in blue
2026-MYOCHS-erratum-letter.tex   letter to the IJTP Editors (+ PDF)
2026-MYOCHS-69-50-check.py       checks that the three 69-ray, 50-context lineages are
                                 isomorphic to Pavicic's 69-50 hypergraph (needs numpy, networkx)
svozil.bib                       full copy of C:\mytex\svozil.bib

Build each paper: pdflatex, bibtex, pdflatex, pdflatex.
