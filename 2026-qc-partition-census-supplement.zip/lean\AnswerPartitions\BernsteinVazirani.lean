import Mathlib.Data.Fintype.Card
import Mathlib.Algebra.Field.ZMod
import Mathlib.LinearAlgebra.Dimension.Constructions
import Mathlib.LinearAlgebra.FiniteDimensional.Lemmas
import Mathlib.Tactic.Order

/-!
# A finite model of the garbage-bearing Bernstein--Vazirani example

We split coordinates into an accessible label block of size `m = n-k` and a
recorded/discarded block of size `k`.  We then *declare* the finite distribution
suggested by the paper's final Hadamard measurement: it is supported exactly on
strings with the correct accessible block and is uniform over the discarded
block.  This module verifies that this declared distribution is normalized,
checks its finite fiber structure, and proves the collision bound for linear
transcript maps.  It does not formalize the quantum circuit or a lower bound for
arbitrary adaptive classical-oracle algorithms.
-/

namespace AnswerPartitions

local instance : Fact (Nat.Prime 2) := ⟨Nat.prime_two⟩

abbrev F₂ := ZMod 2

/-- An `n=m+k` bit string with coordinates explicitly split into the
unrecorded (`Fin m`) and witness-recorded (`Fin k`) parts. -/
abbrev BVSplitString (m k : ℕ) := (Fin m ⊕ Fin k) → F₂

/-- The answer that survives discarding the address witness. -/
def survivingBVAnswer {m k : ℕ} (a : BVSplitString m k) : Fin m → F₂ :=
  fun i => a (Sum.inl i)

/-- The address coordinates whose coherence was removed by the witness. -/
def recordedBVPart {m k : ℕ} (a : BVSplitString m k) : Fin k → F₂ :=
  fun i => a (Sum.inr i)

/-- Reassemble the two coordinate blocks. -/
def mergeBVParts {m k : ℕ} (u : Fin m → F₂) (s : Fin k → F₂) :
    BVSplitString m k :=
  Sum.elim u s

@[simp] theorem survivingBVAnswer_merge {m k : ℕ}
    (u : Fin m → F₂) (s : Fin k → F₂) :
    survivingBVAnswer (mergeBVParts u s) = u :=
  rfl

@[simp] theorem recordedBVPart_merge {m k : ℕ}
    (u : Fin m → F₂) (s : Fin k → F₂) :
    recordedBVPart (mergeBVParts u s) = s :=
  rfl

/-- A surviving answer cell is freely parametrized by the `k` discarded
coordinates. -/
def survivingBVFiberEquiv {m k : ℕ} (u : Fin m → F₂) :
    {a : BVSplitString m k // survivingBVAnswer a = u} ≃ (Fin k → F₂) where
  toFun a := recordedBVPart a.1
  invFun s := ⟨mergeBVParts u s, rfl⟩
  left_inv a := by
    apply Subtype.ext
    funext q
    cases q with
    | inl i =>
        exact (congrFun a.property i).symm
    | inr i =>
        rfl
  right_inv s := rfl

/-- There are exactly `2^k` strings compatible with any surviving answer label.
This is the combinatorial multiplicity used by the declared distribution below. -/
theorem survivingBVFiber_card {m k : ℕ} (u : Fin m → F₂) :
    Fintype.card {a : BVSplitString m k // survivingBVAnswer a = u} = 2 ^ k := by
  rw [Fintype.card_congr (survivingBVFiberEquiv u)]
  simp

/-- The support predicate of the declared leaky-BV distribution. -/
def InLeakyBVSupport {m k : ℕ} (a z : BVSplitString m k) : Prop :=
  survivingBVAnswer z = survivingBVAnswer a

theorem leakyBVSupport_resolves_partition {m k : ℕ} {a z : BVSplitString m k}
    (hz : InLeakyBVSupport a z) :
    survivingBVAnswer z = survivingBVAnswer a :=
  hz

/-- A finite rational model of Eq. (leaky-distribution): every supported outcome
has probability `2^{-k}`, and every other outcome has probability zero. -/
noncomputable def leakyBVProbability {m k : ℕ} (a z : BVSplitString m k) : ℚ := by
  classical
  exact if InLeakyBVSupport a z then 1 / (2 ^ k : ℚ) else 0

theorem leakyBVProbability_eq_of_mem {m k : ℕ} {a z : BVSplitString m k}
    (hz : InLeakyBVSupport a z) :
    leakyBVProbability a z = 1 / (2 ^ k : ℚ) := by
  simp [leakyBVProbability, hz]

theorem leakyBVProbability_eq_zero_of_not_mem {m k : ℕ} {a z : BVSplitString m k}
    (hz : ¬ InLeakyBVSupport a z) :
    leakyBVProbability a z = 0 := by
  simp [leakyBVProbability, hz]

/-- The declared leaky-BV probabilities have total mass one. -/
theorem leakyBVProbability_sum {m k : ℕ} (a : BVSplitString m k) :
    ∑ z : BVSplitString m k, leakyBVProbability a z = 1 := by
  classical
  have hcard :
      (Finset.univ.filter fun z : BVSplitString m k => InLeakyBVSupport a z).card =
        2 ^ k := by
    rw [← Fintype.card_subtype]
    rw [Fintype.card_congr
      ((Equiv.subtypeEquivRight (fun _ => by rfl)).trans
        (survivingBVFiberEquiv (m := m) (k := k) (survivingBVAnswer a)))]
    simp
  simp only [leakyBVProbability]
  rw [Finset.sum_ite, Finset.sum_const_zero, add_zero, Finset.sum_const, hcard]
  norm_num

/-- Fewer than `m` linear equations over any division ring cannot identify an
arbitrary `m`-coordinate label: every such transcript map has a collision. -/
theorem linearTranscript_collision {K : Type*} [DivisionRing K]
    {m t : ℕ} (h : t < m)
    (L : (Fin m → K) →ₗ[K] (Fin t → K)) :
    ∃ a b, a ≠ b ∧ L a = L b := by
  have hdim : Module.finrank K (Fin t → K) <
      Module.finrank K (Fin m → K) := by
    simpa using h
  have hker : LinearMap.ker L ≠ ⊥ :=
    LinearMap.ker_ne_bot_of_finrank_lt hdim
  obtain ⟨v, hvker, hvne⟩ := Submodule.exists_mem_ne_zero_of_ne_bot hker
  refine ⟨0, v, hvne.symm, ?_⟩
  rw [map_zero, LinearMap.mem_ker.mp hvker]

/-- Binary-field specialization of `linearTranscript_collision`. -/
theorem f₂_linearTranscript_collision {m t : ℕ} (h : t < m)
    (L : (Fin m → F₂) →ₗ[F₂] (Fin t → F₂)) :
    ∃ a b, a ≠ b ∧ L a = L b :=
  linearTranscript_collision (K := F₂) h L

/-- No decoder can be a left inverse to a *linear transcript map* with fewer
than `m` output coordinates.  This is deliberately narrower than a theorem
about arbitrary adaptive classical value-query algorithms. -/
theorem no_linearTranscript_decoder {m t : ℕ} (h : t < m)
    (L : (Fin m → F₂) →ₗ[F₂] (Fin t → F₂)) :
    ¬ ∃ decode : (Fin t → F₂) → (Fin m → F₂), Function.LeftInverse decode L := by
  rintro ⟨decode, hdecode⟩
  obtain ⟨a, b, hab, hsame⟩ := f₂_linearTranscript_collision h L
  apply hab
  rw [← hdecode a, ← hdecode b, hsame]

end AnswerPartitions
