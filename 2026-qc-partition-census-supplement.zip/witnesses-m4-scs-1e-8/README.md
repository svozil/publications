# Raw SCS rerun (July 2026), kept as the numerical record

These witness files, and `data/results-m4-orbits-scs-1e-8.csv`, are the
unchanged output of the tighter-tolerance (1e-8) SCS rerun of the July 2026
version. Where they give `lower_bound` 3 with `certification`
`numerical_candidate`, that bound was numerical when written.

It is now proved exactly: see `../dual-certificates/` and the updated
principal files `../data/results-m4-orbits.csv` and `../witnesses-m4/`, where
each row states the source of its lower bound.
