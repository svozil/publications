import unittest
from collections import Counter
import json
from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np

import partition_query_scan as scan


class PartitionEnumerationTests(unittest.TestCase):
    def test_unlabeled_balanced_counts(self):
        for n, expected in ((2, 1), (4, 3), (6, 10), (8, 35)):
            iterator, count = scan.balanced_partitions(n)
            partitions = list(iterator)
            self.assertEqual(expected, count)
            self.assertEqual(expected, len(partitions))
            self.assertTrue(all(0 in cell for cell in partitions))
            self.assertEqual(len(partitions), len(set(partitions)))


class OrbitReductionTests(unittest.TestCase):
    def test_boolean_cube_automorphism_counts(self):
        for addresses, expected in ((1, 2), (2, 8), (3, 48), (4, 384)):
            automorphisms = scan.boolean_cube_automorphisms(addresses)
            self.assertEqual(expected, len(automorphisms))
            self.assertEqual(expected, len(set(automorphisms)))

    def test_small_orbit_sizes(self):
        two = scan.balanced_boolean_partition_orbits(2)
        self.assertEqual(2, len(two))
        self.assertEqual([1, 2], sorted(spec.orbit_size for spec in two))
        self.assertEqual(3, sum(spec.orbit_size for spec in two))

        three = scan.balanced_boolean_partition_orbits(3)
        self.assertEqual(6, len(three))
        self.assertEqual(
            [1, 3, 3, 4, 12, 12],
            sorted(spec.orbit_size for spec in three),
        )
        self.assertEqual(35, sum(spec.orbit_size for spec in three))

    def test_four_address_orbit_inventory(self):
        specifications = scan.balanced_boolean_partition_orbits(4)
        self.assertEqual(58, len(specifications))
        self.assertEqual(6435, sum(spec.orbit_size for spec in specifications))
        self.assertEqual(
            {
                1: 1,
                4: 2,
                6: 1,
                12: 1,
                16: 3,
                24: 3,
                32: 6,
                48: 7,
                96: 12,
                192: 20,
                384: 2,
            },
            dict(Counter(spec.orbit_size for spec in specifications)),
        )


class ClassicalComplexityTests(unittest.TestCase):
    def setUp(self):
        self.family = scan.all_boolean_truth_tables(2)

    def test_deutsch_partition(self):
        # Rows are 00, 01, 10, 11.  Constants are 00 and 11.
        labels = scan.labels_from_cell(4, (0, 3))
        self.assertEqual(
            2, scan.deterministic_exact_queries(self.family.values, labels)
        )

    def test_single_coordinate_partition(self):
        labels = scan.labels_from_cell(4, (0, 1))
        self.assertEqual(
            1, scan.deterministic_exact_queries(self.family.values, labels)
        )

    def test_indistinguishable_cross_cell_instances(self):
        values = np.asarray([[0], [0], [1], [1]], dtype=int)
        labels = scan.labels_from_cell(4, (0, 2))
        self.assertIsNone(scan.deterministic_exact_queries(values, labels))


class ExactBooleanOneQueryTests(unittest.TestCase):
    def test_deutsch_factor_two(self):
        family = scan.all_boolean_truth_tables(2)
        labels = scan.labels_from_cell(4, (0, 3))
        result = scan.exact_quantum_queries(
            family,
            labels,
            classical_queries=2,
            max_queries=None,
            solver_name="AUTO",
            tolerance=1e-7,
            verbose_solver=False,
        )
        self.assertEqual(1, result.queries)

    def test_exact_boolean_one_query_weights(self):
        family = scan.all_boolean_truth_tables(2)
        deutsch_labels = scan.labels_from_cell(4, (0, 3))
        weights = scan.exact_one_query_boolean_weights(
            family.values, deutsch_labels
        )
        self.assertIsNotNone(weights)
        self.assertEqual(1, sum(weights))
        parity_three = scan.all_boolean_truth_tables(3)
        even = tuple(
            index
            for index, row in enumerate(parity_three.values)
            if int(np.sum(row)) % 2 == 0
        )
        labels = scan.labels_from_cell(8, even)
        self.assertIsNone(
            scan.exact_one_query_boolean_weights(parity_three.values, labels)
        )

    def test_programmatic_negative_cap_is_rejected(self):
        family = scan.all_boolean_truth_tables(2)
        labels = scan.labels_from_cell(4, (0, 3))
        with self.assertRaisesRegex(ValueError, "max_queries must be positive"):
            scan.exact_quantum_queries(
                family,
                labels,
                classical_queries=2,
                max_queries=-1,
                solver_name="AUTO",
                tolerance=1e-7,
                verbose_solver=False,
            )

    def test_even_response_alphabet_supports_pair_parity(self):
        binary = scan.all_boolean_truth_tables(2)
        family = scan.OracleFamily(
            values=binary.values,
            names=binary.names,
            alphabet_size=4,
            description="Boolean entries with a four-level response",
        )
        labels = scan.labels_from_cell(4, (0, 3))
        result = scan.exact_quantum_queries(
            family,
            labels,
            classical_queries=2,
            max_queries=None,
            solver_name="AUTO",
            tolerance=1e-7,
            verbose_solver=False,
        )
        self.assertEqual(1, result.queries)
        self.assertEqual("exact", result.certification)


class ExactPairParityTreeTests(unittest.TestCase):
    @staticmethod
    def evaluate(tree, row):
        node = tree
        while "output" not in node:
            addresses = node["query"]["addresses"]
            outcome = 0
            for address in addresses:
                outcome ^= int(row[address])
            node = node["branches"][str(outcome)]
        return int(node["output"])

    def assert_tree_classifies(self, cell_zero, expected_depth=2):
        family = scan.all_boolean_truth_tables(3)
        labels = scan.labels_from_cell(8, cell_zero)
        certificate = scan.pair_parity_decision_tree(family.values, labels)
        self.assertIsNotNone(certificate)
        depth, tree = certificate
        self.assertEqual(expected_depth, depth)
        observed = [self.evaluate(tree, row) for row in family.values]
        self.assertEqual(labels.astype(int).tolist(), observed)
        classical = scan.deterministic_exact_queries(family.values, labels)
        result = scan.exact_quantum_queries(
            family,
            labels,
            classical_queries=classical,
            max_queries=None,
            solver_name="AUTO",
            tolerance=1e-7,
            verbose_solver=False,
        )
        self.assertEqual(expected_depth, result.queries)
        self.assertEqual("exact", result.certification)
        self.assertEqual("exact_pair_parity_tree", result.witness.kind)

    def test_majority(self):
        self.assert_tree_classifies((0, 1, 2, 4))

    def test_nonlinear_three_bit_representative(self):
        # Zero cell of x1 xor (x2 and x3).
        self.assert_tree_classifies((0, 1, 2, 7))

    def test_three_bit_parity(self):
        self.assert_tree_classifies((0, 3, 5, 6))

    def test_capped_scan_retains_constructive_upper_witness(self):
        family = scan.all_boolean_truth_tables(4)
        cell_zero = (0, 1, 2, 3, 4, 5, 6, 8)
        labels = scan.labels_from_cell(16, cell_zero)
        classical = scan.deterministic_exact_queries(family.values, labels)
        result = scan.exact_quantum_queries(
            family,
            labels,
            classical_queries=classical,
            max_queries=1,
            solver_name="AUTO",
            tolerance=1e-7,
            verbose_solver=False,
        )
        self.assertIsNone(result.queries)
        self.assertEqual(2, result.lower_bound)
        self.assertEqual(3, result.upper_bound)
        self.assertEqual("cap_unresolved", result.certification)
        self.assertEqual("exact_pair_parity_tree", result.witness.kind)

    def test_complete_three_address_orbit_scan_is_exact(self):
        family = scan.all_boolean_truth_tables(3)
        specifications = scan.balanced_boolean_partition_orbits(3)
        results = scan.scan_partitions(
            family,
            specifications,
            analyzed_count=len(specifications),
            max_quantum_queries=None,
            solver_name="AUTO",
            tolerance=1e-7,
            verbose_solver=False,
            progress_every=0,
        )
        histogram = Counter()
        for result in results:
            histogram[(result.classical_queries, result.quantum_queries)] += (
                result.orbit_size
            )
            self.assertEqual("exact", result.certification)
        self.assertEqual(
            {(1, 1): 3, (2, 1): 3, (2, 2): 12, (3, 2): 17},
            dict(histogram),
        )
        parity_result = next(
            result for result in results if result.cell_zero == (0, 3, 5, 6)
        )
        self.assertIsNone(parity_result.residual)

    def test_exact_witness_files(self):
        family = scan.all_boolean_truth_tables(2)
        raw, count = scan.balanced_partitions(4)
        specifications = [scan.PartitionSpec(cell) for cell in raw]
        with TemporaryDirectory() as directory:
            results = scan.scan_partitions(
                family,
                specifications,
                analyzed_count=count,
                max_quantum_queries=None,
                solver_name="AUTO",
                tolerance=1e-7,
                verbose_solver=False,
                progress_every=0,
                witness_dir=Path(directory),
            )
            self.assertTrue(all(result.witness_file for result in results))
            self.assertEqual(3, len(list(Path(directory).glob("*.json"))))


class QuantumComplexityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            scan._import_cvxpy()
        except RuntimeError as exc:
            raise unittest.SkipTest(str(exc))

    def test_three_bit_parity_needs_two_queries(self):
        family = scan.all_boolean_truth_tables(3)
        even = tuple(
            index
            for index, row in enumerate(family.values)
            if int(np.sum(row)) % 2 == 0
        )
        labels = scan.labels_from_cell(8, even)
        classical = scan.deterministic_exact_queries(family.values, labels)
        self.assertEqual(3, classical)
        result = scan.exact_quantum_queries(
            family,
            labels,
            classical_queries=classical,
            max_queries=None,
            solver_name="AUTO",
            tolerance=1e-7,
            verbose_solver=False,
        )
        self.assertEqual(2, result.queries)

    def test_numerical_gram_witness_is_captured_and_saved(self):
        family = scan.all_boolean_truth_tables(3)
        labels = scan.labels_from_cell(8, (0, 1, 2, 4))
        deltas, mode_names = scan.query_mode_matrices(
            family.values, family.alphabet_size
        )
        feasibility = scan.exact_quantum_feasible(
            deltas,
            mode_names,
            labels,
            queries=2,
            solver_name="AUTO",
            tolerance=1e-7,
            capture_witness=True,
        )
        self.assertTrue(feasibility.verdict)
        self.assertIsNotNone(feasibility.witness)
        self.assertEqual("numerical_gram_sdp", feasibility.witness.kind)
        self.assertLessEqual(feasibility.residual, 1e-6)

        quantum = scan.QuantumResult(
            queries=2,
            lower_bound=2,
            upper_bound=2,
            status="test numerical witness",
            solver=feasibility.solver,
            solver_status=feasibility.status,
            residual=feasibility.residual,
            certification="numerical_candidate",
            witness=feasibility.witness,
        )
        with TemporaryDirectory() as directory:
            metadata = scan.save_query_witness(
                Path(directory),
                family,
                partition_number=1,
                cell_zero=(0, 1, 2, 4),
                labels=labels,
                orbit_size=4,
                quantum=quantum,
            )
            self.assertTrue(Path(metadata).is_file())
            with Path(metadata).open("r", encoding="utf-8") as handle:
                provenance = json.load(handle)
            self.assertIn(
                provenance["classification"]["solver_status"],
                ("optimal", "optimal_inaccurate"),
            )
            self.assertEqual(2, provenance["classification"]["lower_bound"])
            self.assertEqual(
                2, provenance["classification"]["constructive_upper_bound"]
            )
            archive = Path(directory, "partition-0001-q2.npz")
            self.assertTrue(archive.is_file())
            with np.load(archive) as payload:
                self.assertEqual((2, 4, 8, 8), payload["matrices"].shape)
                self.assertEqual((4, 8, 8), payload["deltas"].shape)


if __name__ == "__main__":
    unittest.main()
