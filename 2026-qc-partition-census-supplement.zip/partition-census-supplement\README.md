# Finite oracle-partition census: reproducibility archive

This archive accompanies *Oracle-Relative Resolution of Decision Partitions*.
It contains the Python implementation, tests, generated CSV output, exact and
audited numerical witnesses, and a standalone explanatory supplement.

## Contents

- `supplementary_partition_census.tex` and `supplementary_partition_census.pdf`:
  detailed mathematical and code documentation;
- `code/partition_query_scan.py`: the scanner;
- `code/test_partition_query_scan.py`: unit tests;
- `code/requirements-partition-scan.txt`: Python dependencies;
- `data/`: the three-address and four-address orbit scans and the one-query
  screen;
- `witnesses-m3/` and `witnesses-m4/`: JSON certificates and compressed SDP
  witnesses for the canonical orbit representatives;
- `data/PARTITION_QUERY_SCAN.md`: the command reference;
- `data/SCAN_FINDINGS_FOR_MANUSCRIPT.md`: the interpreted census findings;
- `examples/deutsch_truth_tables.csv`: a small custom-table example.

The CSV files in this archive have portable witness paths such as
`witnesses-m3/partition-0002-q2.json`.  The original absolute paths from the
local scan have been normalized only in these archive copies; the numerical
content is unchanged.

## Reproduce the principal scans

From the extracted archive root, install Python 3.10+ dependencies:

```powershell
python -m pip install -r code/requirements-partition-scan.txt
```

Then run the complete three-address orbit scan:

```powershell
python code/partition_query_scan.py --boolean-inputs 3 --orbit-reduce --show-all --csv data/results-m3-orbits.csv --witness-dir witnesses-m3
```

The four-address scan is larger and uses the numerical SCS test for the
unsettled two-query lower bounds:

```powershell
python code/partition_query_scan.py --boolean-inputs 4 --orbit-reduce --solver SCS --tolerance 1e-8 --csv data/results-m4-orbits.csv --witness-dir witnesses-m4
```

No run is required for the author to use this archive: the supplied CSV files
and witnesses are the outputs used for the manuscript.  Running the commands
is useful only as an independent local verification, and solver versions may
change floating-point statuses.

## Interpretation warning

The three-address results are exact.  The four-address result is exact for 395
partitions; the remaining 6,040 rows depend on numerical SDP infeasibility and
are explicitly labelled `numerical_candidate`.  They should not be quoted as
formal theorems without exact primal/dual certificates.
