import Mathlib.Algebra.Ring.Parity
import Mathlib.LinearAlgebra.Matrix.Permutation
import Mathlib.LinearAlgebra.UnitaryGroup
import Mathlib.Logic.Equiv.Fin.Rotate

/-!
# Algebraic kernel of the response-spectrum argument

This file checks two parts of the response-spectrum theorem which do not
depend on a choice of formal quantum-circuit model.

* `response_constraints_force_halves` is the scalar core of the necessity
  proof.  The four constant--balanced orthogonality equations give
  `z₀ = -p₁` and `z₁ = -p₀`; the unitary expectation bounds give
  `|zₓ| ≤ pₓ`.  These facts force equal address weights.
* `cyclicShift_hasNegOneEigenvector_iff_even` proves directly, for the
  permutation matrix implementing cyclic addition, that `-1` is an
  eigenvalue exactly in even positive dimension.

The reduction from an arbitrary query/reference probe to the scalar
constraints belongs to the protocol layer and is deliberately not smuggled
in as an axiom here.
-/

namespace AnswerPartitions

open scoped ComplexConjugate

/-! ## The response-constraint calculation -/

/-- The real scalar kernel used in the necessity direction of the Deutsch
response-spectrum theorem.

`p₀,p₁` are the two (nonnegative) address weights and `z₀,z₁` are
the real unitary expectations after the cross-cell equations have shown that
their imaginary parts vanish. -/
theorem response_constraints_force_halves
    (p₀ p₁ z₀ z₁ : ℝ)
    (hp₀ : 0 ≤ p₀) (hp₁ : 0 ≤ p₁)
    (hnorm : p₀ + p₁ = 1)
    (hz₀ : z₀ = -p₁) (hz₁ : z₁ = -p₀)
    (hbound₀ : |z₀| ≤ p₀) (hbound₁ : |z₁| ≤ p₁) :
    p₀ = 1 / 2 ∧ p₁ = 1 / 2 ∧ z₀ = -1 / 2 ∧ z₁ = -1 / 2 := by
  have hp₁_le_p₀ : p₁ ≤ p₀ := by
    simpa [hz₀, abs_of_nonneg hp₁] using hbound₀
  have hp₀_le_p₁ : p₀ ≤ p₁ := by
    simpa [hz₁, abs_of_nonneg hp₀] using hbound₁
  have heq : p₀ = p₁ := le_antisymm hp₀_le_p₁ hp₁_le_p₀
  constructor
  · linarith
  constructor
  · linarith
  constructor <;> linarith

/-- Complex-valued form of `response_constraints_force_halves`, matching the
notation of the paper.  The equations themselves imply that both expectations
are real; only their complex norms enter the unitary expectation bound. -/
theorem complex_response_constraints_force_halves
    (p₀ p₁ : ℝ) (z₀ z₁ : ℂ)
    (hp₀ : 0 ≤ p₀) (hp₁ : 0 ≤ p₁)
    (hnorm : p₀ + p₁ = 1)
    (hz₀ : z₀ = -(p₁ : ℂ)) (hz₁ : z₁ = -(p₀ : ℂ))
    (hbound₀ : ‖z₀‖ ≤ p₀) (hbound₁ : ‖z₁‖ ≤ p₁) :
    p₀ = 1 / 2 ∧ p₁ = 1 / 2 ∧ z₀ = -(1 / 2 : ℂ) ∧
      z₁ = -(1 / 2 : ℂ) := by
  have hp₁_le_p₀ : p₁ ≤ p₀ := by
    simpa [hz₀, abs_of_nonneg hp₁] using hbound₀
  have hp₀_le_p₁ : p₀ ≤ p₁ := by
    simpa [hz₁, abs_of_nonneg hp₀] using hbound₁
  have heq : p₀ = p₁ := le_antisymm hp₀_le_p₁ hp₁_le_p₀
  have hp₀half : p₀ = 1 / 2 := by linarith
  have hp₁half : p₁ = 1 / 2 := by linarith
  exact ⟨hp₀half, hp₁half, by simpa [hp₁half] using hz₀,
    by simpa [hp₀half] using hz₁⟩

/-! ## The cyclic response matrix -/

/-- The matrix of cyclic addition `|y⟩ ↦ |y+1 (mod d)⟩`.

With mathlib's convention for permutation matrices, multiplying an amplitude
vector by this matrix composes that vector with `finRotate d`; this is
the same cyclic shift up to the harmless choice of active/passive convention.
-/
noncomputable def cyclicShift (d : ℕ) : Matrix (Fin d) (Fin d) ℂ :=
  (finRotate d).permMatrix ℂ

@[simp] theorem cyclicShift_mulVec (d : ℕ) (v : Fin d → ℂ) :
    Matrix.mulVec (cyclicShift d) v = v ∘ finRotate d := by
  simpa [cyclicShift] using Matrix.permMatrix_mulVec (R := ℂ) (finRotate d) (v := v)

/-- A concrete, basis-level formulation that `-1` is an eigenvalue. -/
def HasNegOneEigenvector {d : ℕ} (A : Matrix (Fin d) (Fin d) ℂ) : Prop :=
  ∃ v : Fin d → ℂ, v ≠ 0 ∧ Matrix.mulVec A v = -v

/-- The cyclic response is unitary in every dimension. -/
theorem cyclicShift_mem_unitaryGroup (d : ℕ) :
    cyclicShift d ∈ Matrix.unitaryGroup (Fin d) ℂ := by
  rw [Matrix.mem_unitaryGroup_iff]
  change (finRotate d).permMatrix ℂ *
      Matrix.conjTranspose ((finRotate d).permMatrix ℂ) = 1
  rw [Matrix.conjTranspose_permMatrix, ← Matrix.permMatrix_mul]
  simp

/-- `-1` is an eigenvalue of cyclic addition in positive dimension exactly
when the dimension is even.  This is the spectral assertion used in the
paper's cyclic-response corollary. -/
theorem cyclicShift_hasNegOneEigenvector_iff_even {d : ℕ} (hd : 0 < d) :
    HasNegOneEigenvector (cyclicShift d) ↔ Even d := by
  cases d with
  | zero => simp at hd
  | succ n =>
      constructor
      · rintro ⟨v, hv_ne, hv⟩
        have hstep : ∀ i : Fin (n + 1),
            v (finRotate (n + 1) i) = -v i := by
          intro i
          have hi := congrFun hv i
          simpa only [cyclicShift_mulVec, Function.comp_apply, Pi.neg_apply] using hi
        have hformula : ∀ i : Fin (n + 1),
            v i = (-1 : ℂ) ^ i.val * v 0 := by
          intro i
          induction i using Fin.induction with
          | zero => simp
          | succ i ih =>
              have hs := hstep i.castSucc
              have hrotate : finRotate (n + 1) i.castSucc = i.succ := by
                apply Fin.ext
                simp
              rw [hrotate] at hs
              rw [hs, ih, Fin.val_succ, Fin.val_castSucc, pow_succ]
              ring
        have hv0 : v 0 ≠ 0 := by
          intro hv0
          apply hv_ne
          funext i
          rw [hformula i, hv0, mul_zero]
          rfl
        have hwrap := hstep (Fin.last n)
        rw [finRotate_last, hformula (Fin.last n)] at hwrap
        have hpow : (-1 : ℂ) ^ (n + 1) = 1 := by
          apply mul_right_cancel₀ hv0
          calc
            (-1 : ℂ) ^ (n + 1) * v 0 = (-((-1 : ℂ) ^ n)) * v 0 := by
              rw [pow_succ]
              ring
            _ = v 0 := by simpa only [neg_mul] using hwrap.symm
            _ = 1 * v 0 := by rw [one_mul]
        exact (neg_one_pow_eq_one_iff_even (by norm_num : (-1 : ℂ) ≠ 1)).mp hpow
      · intro heven
        let v : Fin (n + 1) → ℂ := fun i => (-1 : ℂ) ^ i.val
        refine ⟨v, ?_, ?_⟩
        · intro hv
          have hzero := congrFun hv (0 : Fin (n + 1))
          norm_num [v] at hzero
        · ext i
          rw [cyclicShift_mulVec]
          change v (finRotate (n + 1) i) = -v i
          by_cases hi : i = Fin.last n
          · subst i
            rw [finRotate_last]
            change (1 : ℂ) = -((-1 : ℂ) ^ n)
            have hp : (-1 : ℂ) ^ (n + 1) = 1 := heven.neg_one_pow
            simpa [pow_succ] using hp.symm
          · change (-1 : ℂ) ^ (finRotate (n + 1) i).val =
                 -((-1 : ℂ) ^ i.val)
            rw [coe_finRotate_of_ne_last hi, pow_succ]
            ring

end AnswerPartitions
