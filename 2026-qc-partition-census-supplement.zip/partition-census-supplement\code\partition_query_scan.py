#!/usr/bin/env python3
"""Enumerate balanced binary decision partitions for a finite value oracle.

The oracle family is supplied as a table.  Row ``a`` is one possible oracle
instance and column ``x`` is one allowed query address.  The table entry
``f[a, x]`` is returned by the reversible addition oracle

    O_a |x, y> = |x, y + f[a, x] (mod d)>.

For every unlabeled equipartition of an even number n=2k of instances, this
program computes

* D_0: deterministic exact classical query complexity, by exhaustive
  decision-tree dynamic programming; and
* Q_0: an exact quantum query count when symbolic upper and lower
  certificates meet, or otherwise a clearly marked numerical candidate from
  the finite-query Gram-matrix SDP for the same reversible oracle.

The ratio D_0 / Q_0 is reported as the exact-query speedup factor.  Boolean
one-query lower tests and value/pair-parity decision trees are exact.  SDP
answers are numerical and are retained with their raw status and audited
residual rather than presented as machine-checked proofs.
"""

from __future__ import annotations

import argparse
import csv
import itertools
import json
import math
import random
import sys
from collections import Counter
from dataclasses import dataclass
from fractions import Fraction
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable, Iterator, Sequence

import numpy as np


@dataclass(frozen=True)
class OracleFamily:
    values: np.ndarray
    names: tuple[str, ...]
    alphabet_size: int
    description: str
    boolean_cube_dimension: int | None = None

    @property
    def instance_count(self) -> int:
        return int(self.values.shape[0])

    @property
    def query_count(self) -> int:
        return int(self.values.shape[1])


@dataclass(frozen=True)
class FeasibilityResult:
    verdict: bool | None
    solver: str
    status: str
    residual: float | None = None
    witness: QueryWitness | None = None


@dataclass(frozen=True)
class QueryWitness:
    kind: str
    queries: int
    mode_names: tuple[str, ...] = ()
    exact_payload: dict[str, Any] | None = None
    matrices: tuple[tuple[np.ndarray, ...], ...] | None = None


@dataclass(frozen=True)
class PartitionSpec:
    cell_zero: tuple[int, ...]
    orbit_size: int = 1


@dataclass(frozen=True)
class QuantumResult:
    queries: int | None
    lower_bound: int
    status: str
    upper_bound: int | None = None
    solver: str = ""
    solver_status: str = "not_run"
    residual: float | None = None
    certification: str = "unknown"
    witness: QueryWitness | None = None


@dataclass(frozen=True)
class PartitionResult:
    number: int
    cell_zero: tuple[int, ...]
    cell_one: tuple[int, ...]
    orbit_size: int
    classical_queries: int | None
    quantum_queries: int | None
    quantum_lower_bound: int
    quantum_upper_bound: int | None
    quantum_status: str
    solver: str
    solver_status: str
    residual: float | None
    certification: str
    witness_file: str = ""

    @property
    def speedup(self) -> Fraction | None:
        if self.classical_queries is None or self.quantum_queries is None:
            return None
        return Fraction(self.classical_queries, self.quantum_queries)


def all_boolean_truth_tables(addresses: int) -> OracleFamily:
    if addresses < 1:
        raise ValueError("--boolean-inputs must be positive")
    rows = list(itertools.product((0, 1), repeat=addresses))
    values = np.asarray(rows, dtype=int)
    names = tuple("".join(str(bit) for bit in row) for row in rows)
    return OracleFamily(
        values=values,
        names=names,
        alphabet_size=2,
        description=(
            f"all {len(rows)} Boolean truth tables on {addresses} query "
            f"addresses"
        ),
        boolean_cube_dimension=addresses,
    )


def _coerce_rows(
    rows: Sequence[Sequence[int]],
    names: Sequence[str] | None,
    alphabet_size: int | None,
    description: str,
) -> OracleFamily:
    if not rows:
        raise ValueError("the oracle table is empty")
    width = len(rows[0])
    if width == 0 or any(len(row) != width for row in rows):
        raise ValueError("all oracle-table rows must have the same positive width")
    values = np.asarray(rows, dtype=int)
    if np.any(values < 0):
        raise ValueError("oracle values must be nonnegative integers")
    inferred = int(values.max()) + 1
    d = inferred if alphabet_size is None else alphabet_size
    if d < 2 or np.any(values >= d):
        raise ValueError("alphabet size must exceed every table entry and be at least 2")
    if names is None:
        names = [f"a{i}" for i in range(len(rows))]
    if len(names) != len(rows) or len(set(names)) != len(names):
        raise ValueError("instance names must be present, unique, and match the row count")
    return OracleFamily(values, tuple(names), d, description)


def load_json_table(path: Path, alphabet_size: int | None) -> OracleFamily:
    with path.open("r", encoding="utf-8") as handle:
        data = json.load(handle)
    names: list[str] | None = None
    if isinstance(data, list):
        rows = data
    elif isinstance(data, dict):
        if alphabet_size is None and "alphabet_size" in data:
            alphabet_size = int(data["alphabet_size"])
        raw_instances = data.get("instances")
        if raw_instances is not None:
            if not isinstance(raw_instances, list):
                raise ValueError("JSON 'instances' must be a list")
            if raw_instances and isinstance(raw_instances[0], dict):
                names = [str(item["name"]) for item in raw_instances]
                rows = [item["values"] for item in raw_instances]
            else:
                rows = raw_instances
        elif "values" in data:
            rows = data["values"]
            if "names" in data:
                names = [str(name) for name in data["names"]]
        else:
            raise ValueError("JSON must contain 'instances' or 'values'")
    else:
        raise ValueError("JSON oracle table must be a list or object")
    return _coerce_rows(rows, names, alphabet_size, f"oracle table {path.name}")


def load_csv_table(path: Path, alphabet_size: int | None) -> OracleFamily:
    rows: list[list[int]] = []
    names: list[str] = []
    explicit_names: bool | None = None
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        for line_number, fields in enumerate(csv.reader(handle), start=1):
            if not fields or not any(field.strip() for field in fields):
                continue
            if fields[0].lstrip().startswith("#"):
                continue
            fields = [field.strip() for field in fields]
            try:
                numeric = [int(field) for field in fields]
                row_has_name = False
                name = f"a{len(rows)}"
            except ValueError:
                try:
                    numeric = [int(field) for field in fields[1:]]
                except ValueError as exc:
                    raise ValueError(
                        f"{path}:{line_number}: expected integers, optionally "
                        "preceded by one instance name"
                    ) from exc
                row_has_name = True
                name = fields[0]
            if explicit_names is None:
                explicit_names = row_has_name
            elif explicit_names != row_has_name:
                raise ValueError("either every CSV row or no CSV row must have a name")
            names.append(name)
            rows.append(numeric)
    return _coerce_rows(rows, names, alphabet_size, f"oracle table {path.name}")


def load_oracle_table(path: Path, alphabet_size: int | None) -> OracleFamily:
    if path.suffix.lower() == ".json":
        return load_json_table(path, alphabet_size)
    if path.suffix.lower() == ".csv":
        return load_csv_table(path, alphabet_size)
    raise ValueError("--table must name a .json or .csv file")


def validate_family(family: OracleFamily) -> None:
    n = family.instance_count
    if n < 2 or n % 2:
        raise ValueError(f"the number of instances must be even; received n={n}")
    if family.query_count < 1:
        raise ValueError("the oracle must have at least one query address")


def balanced_partition_count(n: int) -> int:
    """Number of unlabeled partitions of n=2k objects into two k-cells."""
    return math.comb(n, n // 2) // 2


def balanced_partitions(
    n: int, sample: int | None = None, seed: int = 1
) -> tuple[Iterator[tuple[int, ...]], int]:
    """Return cell-zero representatives, fixing instance 0 in that cell."""
    k = n // 2
    total = balanced_partition_count(n)
    if sample is None or sample >= total:
        iterator = (
            (0,) + tail for tail in itertools.combinations(range(1, n), k - 1)
        )
        return iterator, total

    if sample < 1:
        raise ValueError("--sample must be positive")
    rng = random.Random(seed)
    chosen: set[tuple[int, ...]] = set()
    population = tuple(range(1, n))
    while len(chosen) < sample:
        chosen.add(tuple(sorted(rng.sample(population, k - 1))))
    representatives = [(0,) + tail for tail in sorted(chosen)]
    return iter(representatives), sample


def _cell_mask(cell: Sequence[int]) -> int:
    mask = 0
    for instance in cell:
        mask |= 1 << instance
    return mask


def _mask_cell(mask: int, instance_count: int) -> tuple[int, ...]:
    return tuple(instance for instance in range(instance_count) if mask & (1 << instance))


@lru_cache(maxsize=None)
def boolean_cube_automorphisms(addresses: int) -> tuple[tuple[int, ...], ...]:
    """Instance permutations induced by coordinate permutations and bit flips."""
    instance_count = 1 << addresses
    automorphisms: list[tuple[int, ...]] = []
    for permutation in itertools.permutations(range(addresses)):
        for flips in itertools.product((0, 1), repeat=addresses):
            mapping: list[int] = []
            for instance in range(instance_count):
                bits = tuple(
                    (instance >> (addresses - 1 - coordinate)) & 1
                    for coordinate in range(addresses)
                )
                image = 0
                for coordinate in range(addresses):
                    image = (image << 1) | (
                        bits[permutation[coordinate]] ^ flips[coordinate]
                    )
                mapping.append(image)
            automorphisms.append(tuple(mapping))
    return tuple(automorphisms)


def _transform_cell_mask(mask: int, mapping: Sequence[int]) -> int:
    image = 0
    pending = mask
    while pending:
        least_bit = pending & -pending
        instance = least_bit.bit_length() - 1
        image |= 1 << mapping[instance]
        pending ^= least_bit
    return image


def balanced_boolean_partition_orbits(addresses: int) -> list[PartitionSpec]:
    """Balanced partition orbits under the Boolean point-oracle automorphisms."""
    instance_count = 1 << addresses
    full_mask = (1 << instance_count) - 1
    iterator, _ = balanced_partitions(instance_count)
    unvisited = {_cell_mask(cell) for cell in iterator}
    automorphisms = boolean_cube_automorphisms(addresses)
    representatives: list[PartitionSpec] = []
    while unvisited:
        seed = next(iter(unvisited))
        orbit: set[int] = set()
        for mapping in automorphisms:
            image = _transform_cell_mask(seed, mapping)
            # Quotient by exchange of the two answer cells.  The representative
            # containing instance zero matches balanced_partitions().
            if image & 1 == 0:
                image = full_mask ^ image
            orbit.add(image)
        canonical = min(
            orbit, key=lambda mask: _mask_cell(mask, instance_count)
        )
        unvisited.difference_update(orbit)
        representatives.append(
            PartitionSpec(
                cell_zero=_mask_cell(canonical, instance_count),
                orbit_size=len(orbit),
            )
        )
    representatives.sort(key=lambda spec: spec.cell_zero)
    return representatives


def labels_from_cell(n: int, cell_zero: Sequence[int]) -> np.ndarray:
    labels = np.ones(n, dtype=np.int8)
    labels[list(cell_zero)] = 0
    return labels


def deterministic_exact_queries(values: np.ndarray, labels: np.ndarray) -> int | None:
    """Optimal worst-case depth of an exact adaptive classical query tree."""
    n, address_count = values.shape
    zero_mask = 0
    one_mask = 0
    for instance, label in enumerate(labels):
        if int(label) == 0:
            zero_mask |= 1 << instance
        else:
            one_mask |= 1 << instance

    @lru_cache(maxsize=None)
    def solve(candidate_mask: int) -> int:
        if candidate_mask & zero_mask == 0 or candidate_mask & one_mask == 0:
            return 0
        best = math.inf
        for address in range(address_count):
            children: dict[int, int] = {}
            pending = candidate_mask
            while pending:
                least_bit = pending & -pending
                instance = least_bit.bit_length() - 1
                value = int(values[instance, address])
                children[value] = children.get(value, 0) | least_bit
                pending ^= least_bit
            if len(children) == 1:
                continue
            child_depths = [solve(mask) for mask in children.values()]
            if any(math.isinf(depth) for depth in child_depths):
                continue
            best = min(best, 1 + max(child_depths))
        return best

    depth = solve((1 << n) - 1)
    return None if math.isinf(depth) else int(depth)


def pair_parity_decision_tree(
    values: np.ndarray, labels: np.ndarray
) -> tuple[int, dict[str, Any]] | None:
    """Construct an exact tree using one-bit or two-bit parity queries.

    A one-bit value query costs one reversible Boolean oracle call.  A parity
    query ``x_i xor x_j`` also costs one call, by the Deutsch algorithm.  An
    adaptive tree of these tests is therefore an explicit exact quantum query
    algorithm, with intermediate measurements deferable in the usual way.
    """
    if np.any((values != 0) & (values != 1)):
        return None
    n, address_count = values.shape
    queries = tuple((address,) for address in range(address_count)) + tuple(
        (left, right)
        for left in range(address_count)
        for right in range(left + 1, address_count)
    )
    zero_mask = 0
    one_mask = 0
    for instance, label in enumerate(labels):
        if int(label) == 0:
            zero_mask |= 1 << instance
        else:
            one_mask |= 1 << instance
    choices: dict[int, tuple[int, ...]] = {}

    @lru_cache(maxsize=None)
    def solve(candidate_mask: int) -> int:
        if candidate_mask & zero_mask == 0 or candidate_mask & one_mask == 0:
            return 0
        best = math.inf
        best_query: tuple[int, ...] | None = None
        for query in queries:
            children = {0: 0, 1: 0}
            pending = candidate_mask
            while pending:
                least_bit = pending & -pending
                instance = least_bit.bit_length() - 1
                outcome = 0
                for address in query:
                    outcome ^= int(values[instance, address])
                children[outcome] |= least_bit
                pending ^= least_bit
            if children[0] == 0 or children[1] == 0:
                continue
            child_depths = (solve(children[0]), solve(children[1]))
            if any(math.isinf(depth) for depth in child_depths):
                continue
            depth = 1 + max(child_depths)
            if depth < best:
                best = depth
                best_query = query
        if best_query is not None:
            choices[candidate_mask] = best_query
        return best

    full_mask = (1 << n) - 1
    depth = solve(full_mask)
    if math.isinf(depth):
        return None

    def build(candidate_mask: int) -> dict[str, Any]:
        if candidate_mask & zero_mask == 0:
            return {"output": 1}
        if candidate_mask & one_mask == 0:
            return {"output": 0}
        query = choices[candidate_mask]
        child_masks = {0: 0, 1: 0}
        pending = candidate_mask
        while pending:
            least_bit = pending & -pending
            instance = least_bit.bit_length() - 1
            outcome = 0
            for address in query:
                outcome ^= int(values[instance, address])
            child_masks[outcome] |= least_bit
            pending ^= least_bit
        return {
            "query": {
                "kind": "value" if len(query) == 1 else "pair_parity",
                "addresses": list(query),
            },
            "branches": {
                "0": build(child_masks[0]),
                "1": build(child_masks[1]),
            },
        }

    return int(depth), build(full_mask)


def query_mode_matrices(values: np.ndarray, alphabet_size: int) -> tuple[np.ndarray, list[str]]:
    """Relative-phase matrices after Fourier-diagonalizing the response."""
    n, address_count = values.shape
    phase_vectors: list[np.ndarray] = [np.ones(n, dtype=complex)]
    mode_names = ["idle"]
    if alphabet_size == 2:
        for address in range(address_count):
            phase_vectors.append((1 - 2 * values[:, address]).astype(complex))
            mode_names.append(f"x={address},s=1")
    else:
        omega = np.exp(2j * np.pi / alphabet_size)
        for address in range(address_count):
            for frequency in range(1, alphabet_size):
                phase_vectors.append(
                    omega ** (frequency * values[:, address].astype(int))
                )
                mode_names.append(f"x={address},s={frequency}")
    deltas = np.asarray(
        [np.conjugate(vector)[:, None] * vector[None, :] for vector in phase_vectors]
    )
    if np.max(np.abs(deltas.imag)) < 1e-13:
        deltas = deltas.real
    return deltas, mode_names


def _fraction_rank(rows: Sequence[Sequence[Fraction]]) -> int:
    matrix = [list(row) for row in rows]
    if not matrix:
        return 0
    row_count = len(matrix)
    column_count = len(matrix[0])
    pivot_row = 0
    for column in range(column_count):
        pivot = next(
            (row for row in range(pivot_row, row_count) if matrix[row][column]),
            None,
        )
        if pivot is None:
            continue
        matrix[pivot_row], matrix[pivot] = matrix[pivot], matrix[pivot_row]
        scale = matrix[pivot_row][column]
        matrix[pivot_row] = [entry / scale for entry in matrix[pivot_row]]
        for row in range(row_count):
            if row == pivot_row or not matrix[row][column]:
                continue
            factor = matrix[row][column]
            matrix[row] = [
                entry - factor * pivot_entry
                for entry, pivot_entry in zip(matrix[row], matrix[pivot_row])
            ]
        pivot_row += 1
        if pivot_row == row_count:
            break
    return pivot_row


def _unique_fraction_solution(
    coefficients: Sequence[Sequence[Fraction]], right_hand_side: Sequence[Fraction]
) -> list[Fraction] | None:
    """Solve an overdetermined full-column-rank rational system."""
    variable_count = len(coefficients[0])
    matrix = [list(row) + [rhs] for row, rhs in zip(coefficients, right_hand_side)]
    row_count = len(matrix)
    pivot_row = 0
    pivot_columns: list[int] = []
    for column in range(variable_count):
        pivot = next(
            (row for row in range(pivot_row, row_count) if matrix[row][column]),
            None,
        )
        if pivot is None:
            continue
        matrix[pivot_row], matrix[pivot] = matrix[pivot], matrix[pivot_row]
        scale = matrix[pivot_row][column]
        matrix[pivot_row] = [entry / scale for entry in matrix[pivot_row]]
        for row in range(row_count):
            if row == pivot_row or not matrix[row][column]:
                continue
            factor = matrix[row][column]
            matrix[row] = [
                entry - factor * pivot_entry
                for entry, pivot_entry in zip(matrix[row], matrix[pivot_row])
            ]
        pivot_columns.append(column)
        pivot_row += 1
    for row in matrix:
        if not any(row[column] for column in range(variable_count)) and row[-1]:
            return None
    if len(pivot_columns) != variable_count:
        return None
    solution = [Fraction(0) for _ in range(variable_count)]
    for row, column in enumerate(pivot_columns):
        solution[column] = matrix[row][-1]
    return solution


def exact_one_query_boolean_weights(
    values: np.ndarray, labels: np.ndarray
) -> list[Fraction] | None:
    """Exact rational one-query test for a Boolean reversible value oracle.

    The modes are the invariant response mode followed by one phase mode for
    each query address.  Feasibility is a rational LP.  Since the simplex is
    bounded, a feasible system has a basic feasible solution, which is found
    by enumerating column bases and solving them over ``Fraction``.
    """
    if np.any((values != 0) & (values != 1)):
        raise ValueError("the exact Boolean one-query test needs entries 0 or 1")
    n, address_count = values.shape
    mode_count = address_count + 1
    equations: list[list[Fraction]] = [
        [Fraction(1) for _ in range(mode_count)]
    ]
    right_hand_side = [Fraction(1)]
    seen_cross_rows: set[tuple[int, ...]] = set()
    for left in range(n):
        for right in range(left + 1, n):
            if labels[left] == labels[right]:
                continue
            row = (1,) + tuple(
                1 if values[left, address] == values[right, address] else -1
                for address in range(address_count)
            )
            if row in seen_cross_rows:
                continue
            seen_cross_rows.add(row)
            equations.append([Fraction(entry) for entry in row])
            right_hand_side.append(Fraction(0))

    rank = _fraction_rank(equations)
    for basis in itertools.combinations(range(mode_count), rank):
        restricted = [[row[column] for column in basis] for row in equations]
        solution = _unique_fraction_solution(restricted, right_hand_side)
        if solution is None or any(weight < 0 for weight in solution):
            continue
        weights = [Fraction(0) for _ in range(mode_count)]
        for column, weight in zip(basis, solution):
            weights[column] = weight
        return weights
    return None


def _import_cvxpy():
    try:
        import cvxpy as cp
    except ImportError as exc:
        raise RuntimeError(
            "quantum classification requires CVXPY; install dependencies with "
            "'python -m pip install -r requirements-partition-scan.txt'"
        ) from exc
    return cp


def _sum_expressions(expressions: Sequence):
    result = expressions[0]
    for expression in expressions[1:]:
        result = result + expression
    return result


def _audit_sdp_solution(
    matrix_values: list[list[np.ndarray]],
    deltas: np.ndarray,
    labels: np.ndarray,
) -> float:
    n = len(labels)
    worst = 0.0
    for level in matrix_values:
        for matrix in level:
            hermitian = (matrix + matrix.conj().T) / 2
            worst = max(worst, max(0.0, -float(np.linalg.eigvalsh(hermitian).min())))
    initial = sum(matrix_values[0])
    worst = max(worst, float(np.max(np.abs(initial - np.ones((n, n))))))
    for query in range(len(matrix_values) - 1):
        post = sum(
            deltas[mode] * matrix_values[query][mode]
            for mode in range(len(deltas))
        )
        following = sum(matrix_values[query + 1])
        worst = max(worst, float(np.max(np.abs(following - post))))
    final = sum(
        deltas[mode] * matrix_values[-1][mode]
        for mode in range(len(deltas))
    )
    cross = labels[:, None] != labels[None, :]
    if np.any(cross):
        worst = max(worst, float(np.max(np.abs(final[cross]))))
    return worst


def exact_quantum_feasible(
    deltas: np.ndarray,
    mode_names: Sequence[str],
    labels: np.ndarray,
    queries: int,
    solver_name: str,
    tolerance: float,
    verbose: bool = False,
    capture_witness: bool = False,
) -> FeasibilityResult:
    """Test exact T-query resolvability using the Gram-matrix SDP."""
    if queries < 1:
        return FeasibilityResult(False, "", "balanced tasks need at least one query")
    cp = _import_cvxpy()
    n = len(labels)
    mode_count = len(deltas)
    real_problem = not np.iscomplexobj(deltas)
    matrices = []
    constraints = []
    for _ in range(queries):
        level = []
        for _ in range(mode_count):
            variable = cp.Variable((n, n), symmetric=True) if real_problem else cp.Variable((n, n), hermitian=True)
            constraints.append(variable >> 0)
            level.append(variable)
        matrices.append(level)

    constraints.append(_sum_expressions(matrices[0]) == np.ones((n, n)))

    def post_query(level):
        return _sum_expressions(
            [cp.multiply(deltas[mode], level[mode]) for mode in range(mode_count)]
        )

    for query in range(queries - 1):
        constraints.append(
            _sum_expressions(matrices[query + 1]) == post_query(matrices[query])
        )
    final_gram = post_query(matrices[-1])
    for left in range(n):
        for right in range(left + 1, n):
            if labels[left] != labels[right]:
                constraints.append(final_gram[left, right] == 0)

    problem = cp.Problem(cp.Minimize(0), constraints)
    installed = set(cp.installed_solvers())
    requested = solver_name.upper()
    if requested == "AUTO":
        candidates = [name for name in ("CLARABEL", "CVXOPT", "SCS") if name in installed]
    else:
        if requested not in installed:
            raise RuntimeError(
                f"requested solver {requested} is not installed; available: "
                + ", ".join(sorted(installed))
            )
        candidates = [requested]
    if not candidates:
        raise RuntimeError(
            "no SDP-capable CVXPY solver is installed; install CLARABEL, CVXOPT, or SCS"
        )

    diagnostics: list[str] = []
    for solver in candidates:
        options: dict[str, object] = {
            "solver": solver,
            "verbose": verbose,
            "warm_start": False,
        }
        tightened = max(tolerance / 10, 1e-10)
        if solver == "CLARABEL":
            options.update(
                tol_gap_abs=tightened,
                tol_gap_rel=tightened,
                tol_feas=tightened,
                max_iter=1000,
            )
        elif solver == "SCS":
            options.update(eps=tightened, max_iters=200000)
        elif solver == "CVXOPT":
            options.update(abstol=tightened, reltol=tightened, feastol=tightened)
        try:
            problem.solve(**options)
        except Exception as exc:  # solver-specific failures should permit fallback
            diagnostics.append(f"{solver}: {type(exc).__name__}: {exc}")
            continue
        status = str(problem.status)
        if status == str(cp.INFEASIBLE):
            return FeasibilityResult(False, solver, status)
        if status in (str(cp.OPTIMAL), str(cp.OPTIMAL_INACCURATE)):
            raw_values = [[variable.value for variable in level] for level in matrices]
            if any(value is None for level in raw_values for value in level):
                diagnostics.append(f"{solver}: {status} but returned no matrix values")
                continue
            residual = _audit_sdp_solution(raw_values, deltas, labels)
            residual_limit = max(50 * tolerance, 1e-6)
            if residual <= residual_limit:
                witness = None
                if capture_witness:
                    witness = QueryWitness(
                        kind="numerical_gram_sdp",
                        queries=queries,
                        mode_names=tuple(mode_names),
                        matrices=tuple(
                            tuple(np.asarray(value) for value in level)
                            for level in raw_values
                        ),
                    )
                return FeasibilityResult(True, solver, status, residual, witness)
            diagnostics.append(
                f"{solver}: {status}, audited residual {residual:.3g} exceeds "
                f"{residual_limit:.3g}"
            )
            continue
        diagnostics.append(f"{solver}: {status}")
    return FeasibilityResult(None, ",".join(candidates), "; ".join(diagnostics))


def exact_quantum_queries(
    family: OracleFamily,
    labels: np.ndarray,
    classical_queries: int | None,
    max_queries: int | None,
    solver_name: str,
    tolerance: float,
    verbose_solver: bool,
    capture_witness: bool = False,
) -> QuantumResult:
    if max_queries is not None and max_queries < 1:
        raise ValueError("max_queries must be positive")
    if classical_queries is None:
        return QuantumResult(
            queries=None,
            lower_bound=1,
            status="impossible: cross-cell instances share all values",
            upper_bound=None,
            solver_status="not_run",
            certification="exact_impossibility",
        )

    deltas, mode_names = query_mode_matrices(
        family.values, family.alphabet_size
    )

    # A value test x_i and, when the response alphabet has an order-two
    # character, a Deutsch test x_i xor x_j each cost one oracle call.  The
    # resulting adaptive tree is a symbolic exact upper-bound certificate.
    pair_tree = None
    if family.alphabet_size % 2 == 0:
        pair_tree = pair_parity_decision_tree(family.values, labels)
    upper_queries = classical_queries
    upper_source = "classical decision tree"
    upper_witness: QueryWitness | None = None
    if pair_tree is not None and pair_tree[0] <= upper_queries:
        upper_queries, tree = pair_tree
        upper_source = "exact value/pair-parity decision tree"
        upper_witness = QueryWitness(
            kind="exact_pair_parity_tree",
            queries=upper_queries,
            exact_payload={"tree": tree},
        )

    # Only query counts strictly below the constructive upper bound need to
    # be excluded.  A user cap may stop that lower-bound search early.
    search_limit = upper_queries - 1
    search_cap = (
        search_limit
        if max_queries is None
        else min(max_queries, search_limit)
    )
    last_solver = ""
    last_solver_status = "not_run"
    last_residual: float | None = None
    used_numerical_infeasibility = False
    for queries in range(1, search_cap + 1):
        if queries == 1 and family.alphabet_size == 2:
            weights = exact_one_query_boolean_weights(family.values, labels)
            exact_witness = None
            if weights is not None:
                exact_witness = QueryWitness(
                    kind="exact_boolean_one_query",
                    queries=1,
                    mode_names=tuple(mode_names),
                    exact_payload={
                        "weights": [str(weight) for weight in weights]
                    },
                )
            feasibility = FeasibilityResult(
                weights is not None,
                "Fraction",
                (
                    "exact_rational_lp_feasible"
                    if weights is not None
                    else "exact_rational_lp_infeasible"
                ),
                0.0 if weights is not None else None,
                exact_witness,
            )
        else:
            feasibility = exact_quantum_feasible(
                deltas,
                mode_names,
                labels,
                queries,
                solver_name,
                tolerance,
                verbose_solver,
                capture_witness,
            )
        last_solver = feasibility.solver
        last_solver_status = feasibility.status
        last_residual = feasibility.residual
        if feasibility.verdict is True:
            return QuantumResult(
                queries=queries,
                lower_bound=queries,
                upper_bound=queries,
                status=(
                    "exact rational one-query LP feasible"
                    if feasibility.solver == "Fraction"
                    else f"SDP numerically feasible at T={queries}"
                ),
                solver=last_solver,
                solver_status=last_solver_status,
                residual=last_residual,
                certification=(
                    "exact"
                    if feasibility.solver == "Fraction"
                    else "numerical_candidate"
                ),
                witness=feasibility.witness,
            )
        if feasibility.verdict is None:
            return QuantumResult(
                queries=None,
                lower_bound=queries,
                upper_bound=upper_queries,
                status=(
                    f"numerically unresolved at T={queries}: "
                    f"{feasibility.status}; {upper_source} gives "
                    f"Q<={upper_queries}"
                ),
                solver=last_solver,
                solver_status=last_solver_status,
                residual=last_residual,
                certification="unresolved",
                witness=upper_witness,
            )
        if feasibility.solver != "Fraction":
            used_numerical_infeasibility = True

    if search_cap == search_limit:
        return QuantumResult(
            queries=upper_queries,
            lower_bound=upper_queries,
            upper_bound=upper_queries,
            status=(
                f"all smaller T numerically infeasible; {upper_source} "
                "gives the upper bound"
                if used_numerical_infeasibility
                else f"all smaller T exactly infeasible; {upper_source} "
                "gives the upper bound"
            ),
            solver=last_solver,
            solver_status=last_solver_status,
            residual=last_residual,
            certification=(
                "numerical_candidate"
                if used_numerical_infeasibility
                else "exact"
            ),
            witness=upper_witness,
        )
    return QuantumResult(
        queries=None,
        lower_bound=search_cap + 1,
        upper_bound=upper_queries,
        status=(
            f"not searched beyond T={search_cap}; {upper_source} gives "
            f"Q<={upper_queries}"
        ),
        solver=last_solver,
        solver_status=last_solver_status,
        residual=last_residual,
        certification="cap_unresolved",
        witness=upper_witness,
    )


def cell_text(cell: Sequence[int], names: Sequence[str]) -> str:
    return "{" + ",".join(names[index] for index in cell) + "}"


def save_query_witness(
    directory: Path,
    family: OracleFamily,
    partition_number: int,
    cell_zero: Sequence[int],
    labels: np.ndarray,
    orbit_size: int,
    quantum: QuantumResult,
    tolerance: float | None = None,
) -> str:
    """Save a symbolic certificate or audited numerical Gram witness."""
    witness = quantum.witness
    if witness is None:
        return ""
    directory.mkdir(parents=True, exist_ok=True)
    query_count_for_file = (
        quantum.queries if quantum.queries is not None else witness.queries
    )
    query_text = str(query_count_for_file)
    stem = f"partition-{partition_number:04d}-q{query_text}"
    metadata_path = directory / f"{stem}.json"
    metadata: dict[str, Any] = {
        "schema": "partition-query-witness-v1",
        "kind": witness.kind,
        "queries": witness.queries,
        "partition_number": partition_number,
        "cell_zero_indices": list(cell_zero),
        "cell_zero_names": [family.names[index] for index in cell_zero],
        "labels": labels.astype(int).tolist(),
        "orbit_size": orbit_size,
        "oracle": {
            "description": family.description,
            "alphabet_size": family.alphabet_size,
            "values": family.values.astype(int).tolist(),
            "instance_names": list(family.names),
        },
        "classification": {
            "status": quantum.status,
            "certification": quantum.certification,
            "lower_bound": quantum.lower_bound,
            "constructive_upper_bound": quantum.upper_bound,
            "solver": quantum.solver,
            "solver_status": quantum.solver_status,
            "max_residual": quantum.residual,
            "requested_tolerance": tolerance,
        },
        "mode_names": list(witness.mode_names),
    }
    if witness.exact_payload is not None:
        metadata["exact_payload"] = witness.exact_payload
    if witness.matrices is not None:
        archive_path = directory / f"{stem}.npz"
        matrix_array = np.stack(
            [np.stack(level, axis=0) for level in witness.matrices], axis=0
        )
        deltas, derived_mode_names = query_mode_matrices(
            family.values, family.alphabet_size
        )
        np.savez_compressed(
            archive_path,
            matrices=matrix_array,
            deltas=deltas,
            labels=labels.astype(np.int8),
            oracle_values=family.values.astype(int),
            mode_names=np.asarray(derived_mode_names),
        )
        metadata["matrix_archive"] = archive_path.name
        metadata["matrix_shape"] = list(matrix_array.shape)
    with metadata_path.open("w", encoding="utf-8") as handle:
        json.dump(metadata, handle, indent=2, sort_keys=True)
        handle.write("\n")
    return str(metadata_path.resolve())


def scan_partitions(
    family: OracleFamily,
    partitions: Iterable[PartitionSpec],
    analyzed_count: int,
    max_quantum_queries: int | None,
    solver_name: str,
    tolerance: float,
    verbose_solver: bool,
    progress_every: int,
    witness_dir: Path | None = None,
) -> list[PartitionResult]:
    n = family.instance_count
    universe = set(range(n))
    results: list[PartitionResult] = []
    for number, specification in enumerate(partitions, start=1):
        cell_zero = specification.cell_zero
        cell_one = tuple(sorted(universe.difference(cell_zero)))
        labels = labels_from_cell(n, cell_zero)
        classical = deterministic_exact_queries(family.values, labels)
        quantum = exact_quantum_queries(
            family,
            labels,
            classical,
            max_quantum_queries,
            solver_name,
            tolerance,
            verbose_solver,
            capture_witness=witness_dir is not None,
        )
        witness_file = ""
        if witness_dir is not None:
            witness_file = save_query_witness(
                witness_dir,
                family,
                number,
                cell_zero,
                labels,
                specification.orbit_size,
                quantum,
                tolerance,
            )
        results.append(
            PartitionResult(
                number=number,
                cell_zero=cell_zero,
                cell_one=cell_one,
                orbit_size=specification.orbit_size,
                classical_queries=classical,
                quantum_queries=quantum.queries,
                quantum_lower_bound=quantum.lower_bound,
                quantum_upper_bound=quantum.upper_bound,
                quantum_status=quantum.status,
                solver=quantum.solver,
                solver_status=quantum.solver_status,
                residual=quantum.residual,
                certification=quantum.certification,
                witness_file=witness_file,
            )
        )
        if progress_every and (number % progress_every == 0 or number == analyzed_count):
            print(f"analyzed {number}/{analyzed_count} partitions", file=sys.stderr)
    return results


def format_query_count(value: int | None) -> str:
    return "impossible/unknown" if value is None else str(value)


def write_csv(path: Path, family: OracleFamily, results: Sequence[PartitionResult]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(
            [
                "partition",
                "canonical_mask",
                "orbit_size",
                "cell_0",
                "cell_1",
                "D_exact",
                "Q_exact_candidate",
                "Q_lower_bound",
                "Q_constructive_upper_bound",
                "speedup_candidate",
                "speedup_decimal",
                "quantum_status",
                "certification",
                "solver",
                "solver_status",
                "max_residual",
                "witness_file",
            ]
        )
        mask_width = max(1, (family.instance_count + 3) // 4)
        for result in results:
            factor = result.speedup
            writer.writerow(
                [
                    result.number,
                    f"0x{_cell_mask(result.cell_zero):0{mask_width}x}",
                    result.orbit_size,
                    cell_text(result.cell_zero, family.names),
                    cell_text(result.cell_one, family.names),
                    "" if result.classical_queries is None else result.classical_queries,
                    "" if result.quantum_queries is None else result.quantum_queries,
                    result.quantum_lower_bound,
                    (
                        ""
                        if result.quantum_upper_bound is None
                        else result.quantum_upper_bound
                    ),
                    "" if factor is None else str(factor),
                    "" if factor is None else f"{float(factor):.12g}",
                    result.quantum_status,
                    result.certification,
                    result.solver,
                    result.solver_status,
                    "" if result.residual is None else f"{result.residual:.6g}",
                    result.witness_file,
                ]
            )


def wilson_interval(successes: int, trials: int, z: float = 1.95996398454) -> tuple[float, float]:
    if trials == 0:
        return 0.0, 0.0
    proportion = successes / trials
    denominator = 1 + z * z / trials
    center = (proportion + z * z / (2 * trials)) / denominator
    half_width = (
        z
        * math.sqrt(proportion * (1 - proportion) / trials + z * z / (4 * trials * trials))
        / denominator
    )
    return max(0.0, center - half_width), min(1.0, center + half_width)


def print_summary(
    family: OracleFamily,
    results: Sequence[PartitionResult],
    total_partitions: int,
    sampled: bool,
    orbit_reduced: bool,
    show_all: bool,
) -> None:
    print(f"Oracle family: {family.description}")
    print(
        f"Instances n={family.instance_count}=2*{family.instance_count // 2}; "
        f"query addresses={family.query_count}; response alphabet d={family.alphabet_size}"
    )
    print(f"Unlabeled balanced partitions: {total_partitions}")
    represented = sum(result.orbit_size for result in results)
    if orbit_reduced:
        print(
            f"Orbit representatives analyzed: {len(results)} "
            f"(covering {represented}/{total_partitions} partitions; complete)"
        )
    else:
        print(
            f"Partitions analyzed: {len(results)}"
            + (" (uniform sample)" if sampled else " (complete)")
        )

    impossible = sum(
        result.orbit_size
        for result in results
        if result.classical_queries is None
    )
    unresolved = sum(
        result.orbit_size
        for result in results
        if result.classical_queries is not None and result.quantum_queries is None
    )
    speedups = [result for result in results if result.speedup is not None and result.speedup > 1]
    no_speedup = [result for result in results if result.speedup == 1]
    speedup_count = sum(result.orbit_size for result in speedups)
    no_speedup_count = sum(result.orbit_size for result in no_speedup)
    if orbit_reduced:
        print(
            f"Quantum speedup candidates: {speedup_count} "
            f"(in {len(speedups)} orbits)"
        )
        print(
            f"No-speedup candidates: {no_speedup_count} "
            f"(in {len(no_speedup)} orbits)"
        )
    else:
        print(f"Quantum speedup candidates: {speedup_count}")
        print(f"No-speedup candidates: {no_speedup_count}")
    if impossible:
        print(f"Operationally impossible partitions: {impossible}")
    if unresolved:
        print(f"Numerically/cap unresolved partitions: {unresolved}")

    pair_histogram: Counter[tuple[int, int]] = Counter()
    for result in results:
        if result.classical_queries is not None and result.quantum_queries is not None:
            pair_histogram[
                (result.classical_queries, result.quantum_queries)
            ] += result.orbit_size
    print("\nComplexity histogram (D_exact, Q_exact candidate):")
    for pair, count in sorted(pair_histogram.items()):
        factor = Fraction(pair[0], pair[1])
        print(f"  D={pair[0]}, Q={pair[1]}, factor={factor}: {count}")

    certification_histogram: Counter[str] = Counter()
    for result in results:
        certification_histogram[result.certification] += result.orbit_size
    print("\nCertification histogram:")
    for certification, count in sorted(certification_histogram.items()):
        print(f"  {certification}: {count}")

    classified = len(speedups) + len(no_speedup)
    if sampled and classified == len(results):
        low, high = wilson_interval(len(speedups), len(results))
        fraction = len(speedups) / len(results)
        print(
            "\nSample estimate for the fraction admitting an exact quantum speedup: "
            f"{fraction:.4%} (95% Wilson interval {low:.4%}--{high:.4%})"
        )
        print(
            "Estimated speedup-partition count: "
            f"{round(fraction * total_partitions):,} of {total_partitions:,}"
        )
    elif sampled:
        lower = len(speedups) / len(results)
        upper = (len(speedups) + unresolved) / len(results)
        print(
            "\nA sampling confidence interval is not reported because some "
            "sampled partitions are unresolved or operationally impossible."
        )
        print(
            "Observed speedup-fraction bounds in the full sample: "
            f"{lower:.4%}--{upper:.4%}"
        )

    displayed = list(results) if show_all else speedups[:20]
    heading = "All partitions" if show_all else "Speedup partitions (first 20)"
    print(f"\n{heading}:")
    if not displayed:
        print("  none")
    for result in displayed:
        factor = result.speedup
        factor_text = "?" if factor is None else str(factor)
        print(
            f"  #{result.number}: {cell_text(result.cell_zero, family.names)} | "
            f"{cell_text(result.cell_one, family.names)}; "
            f"D={format_query_count(result.classical_queries)}, "
            f"Q={format_query_count(result.quantum_queries)}, factor={factor_text}"
            + (
                f", orbit={result.orbit_size}"
                if orbit_reduced
                else ""
            )
        )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Enumerate balanced binary partitions of a finite reversible value-oracle "
            "family and compare exact classical and quantum query complexities."
        )
    )
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument(
        "--boolean-inputs",
        type=int,
        metavar="M",
        help="use all 2^M Boolean truth tables on M query addresses",
    )
    source.add_argument(
        "--table",
        type=Path,
        help="load an oracle-instance table from JSON or CSV",
    )
    parser.add_argument(
        "--alphabet-size",
        type=int,
        help="response modulus d for a loaded table (default: max entry plus one)",
    )
    parser.add_argument(
        "--max-quantum-queries",
        type=int,
        help=(
            "largest T tested while excluding smaller query counts; by default "
            "continue to a constructive upper bound"
        ),
    )
    parser.add_argument(
        "--solver",
        default="AUTO",
        help="CVXPY SDP solver: AUTO, CLARABEL, CVXOPT, or SCS (default: AUTO)",
    )
    parser.add_argument("--tolerance", type=float, default=1e-7)
    parser.add_argument(
        "--sample",
        type=int,
        help="uniformly sample this many balanced partitions instead of enumerating all",
    )
    parser.add_argument(
        "--orbit-reduce",
        action="store_true",
        help=(
            "for --boolean-inputs, analyze one representative under coordinate "
            "permutations and independent input-bit flips"
        ),
    )
    parser.add_argument("--seed", type=int, default=1)
    parser.add_argument(
        "--max-partitions",
        type=int,
        default=10000,
        help="refuse a complete scan above this count unless --force is supplied",
    )
    parser.add_argument("--force", action="store_true")
    parser.add_argument("--csv", type=Path, help="write per-partition results to CSV")
    parser.add_argument(
        "--witness-dir",
        type=Path,
        help="save exact symbolic or audited numerical query witnesses here",
    )
    parser.add_argument("--show-all", action="store_true")
    parser.add_argument("--verbose-solver", action="store_true")
    parser.add_argument("--progress-every", type=int, default=25)
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    try:
        if args.boolean_inputs is not None:
            family = all_boolean_truth_tables(args.boolean_inputs)
        else:
            family = load_oracle_table(args.table, args.alphabet_size)
        validate_family(family)
        if args.max_quantum_queries is not None and args.max_quantum_queries < 1:
            raise ValueError("--max-quantum-queries must be positive")
        if args.tolerance <= 0:
            raise ValueError("--tolerance must be positive")
        if args.max_partitions < 1:
            raise ValueError("--max-partitions must be positive")
        if args.orbit_reduce and args.boolean_inputs is None:
            raise ValueError("--orbit-reduce is available only with --boolean-inputs")
        if args.orbit_reduce and args.sample is not None:
            raise ValueError("--orbit-reduce and --sample cannot be combined")
        total = balanced_partition_count(family.instance_count)
        sampled = args.sample is not None and args.sample < total
        if not sampled and total > args.max_partitions and not args.force:
            parser.error(
                f"complete enumeration contains {total:,} partitions, exceeding "
                f"--max-partitions={args.max_partitions:,}; use --sample, increase "
                "the guard, or add --force"
            )
        if args.orbit_reduce:
            partitions: Iterable[PartitionSpec] = balanced_boolean_partition_orbits(
                args.boolean_inputs
            )
            analyzed_count = len(partitions)
        else:
            raw_partitions, analyzed_count = balanced_partitions(
                family.instance_count, args.sample, args.seed
            )
            partitions = (
                PartitionSpec(cell_zero=cell) for cell in raw_partitions
            )
        results = scan_partitions(
            family,
            partitions,
            analyzed_count,
            args.max_quantum_queries,
            args.solver,
            args.tolerance,
            args.verbose_solver,
            args.progress_every,
            args.witness_dir,
        )
        print_summary(
            family,
            results,
            total,
            sampled,
            args.orbit_reduce,
            args.show_all,
        )
        if args.csv:
            write_csv(args.csv, family, results)
            print(f"\nCSV written to {args.csv.resolve()}")
        if args.witness_dir:
            written = sum(bool(result.witness_file) for result in results)
            print(
                f"Witness metadata written for {written}/{len(results)} "
                f"representatives to {args.witness_dir.resolve()}"
            )
        return 0
    except (ValueError, RuntimeError) as exc:
        parser.exit(2, f"error: {exc}\n")


if __name__ == "__main__":
    raise SystemExit(main())
