import Mathlib
import AnswerPartitions.Parity

/-!
# Exact balanced four-bit census

Four-bit Boolean tasks are encoded by 16-bit truth-table masks.  This is much
faster to evaluate than enumerating higher-order functions directly.  Mask bit
`inputIndex x` is the answer on input `x`.

The two executable tree models remain deliberately distinct:

* `deterministicDepth` permits only ordinary point queries;
* `certificateDepth` also permits a two-coordinate parity as one atomic node.

The latter is an exact upper-certificate model built from the Deutsch
subroutine; depth three in that model is **not** asserted to be a quantum lower
bound.  Only the 395 tasks with depth at most two are promoted to exact query
rows below.
-/

namespace AnswerPartitions.CensusFourExact

open AnswerPartitions

abbrev Coord := Fin 4
abbrev Input := BitString 4

/-- Binary index of a four-bit input (little-endian coordinate convention). -/
def inputIndex (x : Input) : Nat :=
  ∑ i : Coord, if x i then 2 ^ i.val else 0

/-- Interpret a natural number as a 16-bit Boolean truth table. -/
def maskTask (mask : Nat) : Input → Bool :=
  fun x => mask.testBit (inputIndex x)

/-- Encode a concrete task as a truth-table mask. -/
def encodeTask (f : Input → Bool) : Nat :=
  ∑ x : Input, if f x then 2 ^ inputIndex x else 0

def zeroInput : Input := zeroBits 4

/-- A normalized balanced truth-table mask: eight `true` values and `0000`
in the false answer cell. -/
def IsNormalizedBalancedMask (mask : Nat) : Prop :=
  ((Finset.univ : Finset Input).filter fun x => maskTask mask x = true).card = 8 ∧
    maskTask mask zeroInput = false

instance (mask : Nat) : Decidable (IsNormalizedBalancedMask mask) := by
  unfold IsNormalizedBalancedMask
  infer_instance

/-- All unlabeled balanced four-bit partitions, represented by the answer cell
not containing `0000`. -/
def normalizedBalancedMasks : Finset Nat :=
  (Finset.range (2 ^ 16)).filter IsNormalizedBalancedMask

/-! ## Query-tree evaluators -/

inductive BitQuery where
  | q0 | q1 | q2 | q3
  deriving DecidableEq, Fintype, Repr

def BitQuery.eval : BitQuery → Input → Bool
  | .q0, x => x 0
  | .q1, x => x 1
  | .q2, x => x 2
  | .q3, x => x 3

inductive CertificateQuery where
  | q0 | q1 | q2 | q3
  | parity01 | parity02 | parity03 | parity12 | parity13 | parity23
  deriving DecidableEq, Fintype, Repr

def CertificateQuery.eval : CertificateQuery → Input → Bool
  | .q0, x => x 0
  | .q1, x => x 1
  | .q2, x => x 2
  | .q3, x => x 3
  | .parity01, x => Bool.xor (x 0) (x 1)
  | .parity02, x => Bool.xor (x 0) (x 2)
  | .parity03, x => Bool.xor (x 0) (x 3)
  | .parity12, x => Bool.xor (x 1) (x 2)
  | .parity13, x => Bool.xor (x 1) (x 3)
  | .parity23, x => Bool.xor (x 2) (x 3)

/- The following masks are the truth tables of the corresponding queries in
the little-endian convention of `inputIndex`.  Keeping them as machine-sized
integers makes the exhaustive evaluator several orders of magnitude smaller
than repeatedly filtering `Finset Input` states. -/
def BitQuery.mask : BitQuery → Nat
  | .q0 => 43690
  | .q1 => 52428
  | .q2 => 61680
  | .q3 => 65280

def CertificateQuery.mask : CertificateQuery → Nat
  | .q0 => 43690
  | .q1 => 52428
  | .q2 => 61680
  | .q3 => 65280
  | .parity01 => 26214
  | .parity02 => 23130
  | .parity03 => 21930
  | .parity12 => 15420
  | .parity13 => 13260
  | .parity23 => 4080

/-- The machine masks implement exactly the semantic point queries. -/
theorem BitQuery.mask_eq_encodeTask (q : BitQuery) :
    q.mask = encodeTask (BitQuery.eval q) := by
  cases q <;> decide

/-- The machine masks implement exactly the semantic point/parity queries. -/
theorem CertificateQuery.mask_eq_encodeTask (q : CertificateQuery) :
    q.mask = encodeTask (CertificateQuery.eval q) := by
  cases q <;> decide

def fullInputState : Nat := 2 ^ 16 - 1

/-- The task is constant on an information state when its true part is empty
or is the entire state. -/
def constantOnState (mask state : Nat) : Bool :=
  let trueState := mask &&& state
  trueState == 0 || trueState == state

/-- Exact finite recursion for a query tree of depth at most `d`. -/
def canSolveWithin {Q : Type} [Fintype Q] [DecidableEq Q]
    (queryMask : Q → Nat) (mask state : Nat) : Nat → Bool
  | 0 => constantOnState mask state
  | d + 1 =>
      constantOnState mask state ||
        decide (((Finset.univ : Finset Q).filter fun q =>
          let trueState := state &&& queryMask q
          let falseState := state ^^^ trueState
          canSolveWithin queryMask mask falseState d = true ∧
          canSolveWithin queryMask mask trueState d = true).card ≠ 0)

def bitSolvableWithin (mask : Nat) (d : Nat) : Bool :=
  canSolveWithin BitQuery.mask mask fullInputState d

def certificateSolvableWithin (mask : Nat) (d : Nat) : Bool :=
  canSolveWithin CertificateQuery.mask mask fullInputState d

def deterministicDepth (mask : Nat) : Nat :=
  if bitSolvableWithin mask 0 then 0
  else if bitSolvableWithin mask 1 then 1
  else if bitSolvableWithin mask 2 then 2
  else if bitSolvableWithin mask 3 then 3
  else 4

def certificateDepth (mask : Nat) : Nat :=
  if certificateSolvableWithin mask 0 then 0
  else if certificateSolvableWithin mask 1 then 1
  else if certificateSolvableWithin mask 2 then 2
  else if certificateSolvableWithin mask 3 then 3
  else 4

def depthHistogram (depth : Nat → Nat) : List (Nat × Nat) :=
  let depths := normalizedBalancedMasks.val.map depth
  [0, 1, 2, 3, 4].map fun d =>
    (d, depths.count d)

/-! ## Exact one-query obstruction -/

instance essentialCoordinateDecidable (mask : Nat) (i : Coord) :
    Decidable (EssentialCoordinate (maskTask mask) i) :=
  Fintype.decidableExistsFintype

def essentialCoordinates (mask : Nat) : Finset Coord :=
  Finset.univ.filter fun i => EssentialCoordinate (maskTask mask) i

/-- Three essential coordinates contradict the exact Boolean one-query weight
criterion. -/
theorem no_boolean_one_query_of_three_essential {mask : Nat}
    (h : 3 ≤ (essentialCoordinates mask).card) :
    ¬ Nonempty (BooleanOneQueryWeightCertificate (maskTask mask)) := by
  rintro ⟨cert⟩
  have hle := oneQuery_essentialCoordinates_card_le_two cert
    (essentialCoordinates mask) (by
      intro i hi
      exact (Finset.mem_filter.mp hi).2)
  omega

/-- Masks of the four point queries and six two-point parities. -/
def oneQueryMasks : Finset Nat :=
  (Finset.univ : Finset CertificateQuery).image fun q =>
    encodeTask (CertificateQuery.eval q)

def lowEssentialMasks : Finset Nat :=
  normalizedBalancedMasks.filter fun mask =>
    (essentialCoordinates mask).card ≤ 2

def oneQueryRows : List (Nat × Nat) :=
  let depths := oneQueryMasks.val.map deterministicDepth
  [1, 2].map fun d =>
    (d, depths.count d)

/-- Depth-two upper certificates whose three essential variables also give an
exact one-query lower obstruction. -/
def depthTwoNonOneQueryMasks : Finset Nat :=
  normalizedBalancedMasks.filter fun mask =>
    certificateDepth mask = 2 ∧ 3 ≤ (essentialCoordinates mask).card

def exactTwoQueryRows : List (Nat × Nat × Nat) :=
  let depths := depthTwoNonOneQueryMasks.val.map deterministicDepth
  [2, 3, 4].map fun d =>
    (d, 2, depths.count d)

/-! ## Native audit -/

structure CensusSummary where
  balancedCount : Nat
  deterministicHistogram : List (Nat × Nat)
  certificateHistogram : List (Nat × Nat)
  atomicCount : Nat
  atomicRows : List (Nat × Nat)
  exactTwoCount : Nat
  exactTwoRows : List (Nat × Nat × Nat)
  deriving DecidableEq, Repr

def censusSummary : CensusSummary where
  balancedCount := normalizedBalancedMasks.card
  deterministicHistogram := depthHistogram deterministicDepth
  certificateHistogram := depthHistogram certificateDepth
  atomicCount := oneQueryMasks.card
  atomicRows := oneQueryRows
  exactTwoCount := depthTwoNonOneQueryMasks.card
  exactTwoRows := exactTwoQueryRows

def expectedCensusSummary : CensusSummary where
  balancedCount := 6435
  deterministicHistogram := [(0, 0), (1, 4), (2, 54), (3, 1784), (4, 4593)]
  certificateHistogram := [(0, 0), (1, 10), (2, 385), (3, 6040), (4, 0)]
  atomicCount := 10
  atomicRows := [(1, 4), (2, 6)]
  exactTwoCount := 385
  exactTwoRows := [(2, 2, 48), (3, 2, 248), (4, 2, 89)]

set_option maxRecDepth 100000 in
/-- One exhaustive native computation checks the complete exact subset and the
restricted-tree statistics without promoting the remaining rows to quantum
lower bounds. -/
theorem census_audit :
    censusSummary = expectedCensusSummary ∧
      lowEssentialMasks = oneQueryMasks := by
  native_decide

theorem normalized_balanced_task_count : normalizedBalancedMasks.card = 6435 := by
  simpa [censusSummary, expectedCensusSummary] using
    congrArg CensusSummary.balancedCount census_audit.1

theorem deterministic_depth_histogram :
    depthHistogram deterministicDepth =
      [(0, 0), (1, 4), (2, 54), (3, 1784), (4, 4593)] := by
  simpa [censusSummary, expectedCensusSummary] using
    congrArg CensusSummary.deterministicHistogram census_audit.1

theorem certificate_depth_histogram :
    depthHistogram certificateDepth =
      [(0, 0), (1, 10), (2, 385), (3, 6040), (4, 0)] := by
  simpa [censusSummary, expectedCensusSummary] using
    congrArg CensusSummary.certificateHistogram census_audit.1

/-- The only balanced tasks with at most two essential coordinates are the ten
atomic point/parity tasks. -/
theorem lowEssentialMasks_eq_oneQueryMasks : lowEssentialMasks = oneQueryMasks := by
  exact census_audit.2

/-- Exact depth rows inside the recorded point/parity certificate model for the
ten tasks passing the Boolean one-query weight criterion. -/
theorem one_query_rows_exact : oneQueryRows = [(1, 4), (2, 6)] := by
  simpa [censusSummary, expectedCensusSummary] using
    congrArg CensusSummary.atomicRows census_audit.1

/-- There are 385 tasks with an exact two-query upper certificate and an exact
one-query obstruction. -/
theorem depth_two_non_one_query_count : depthTwoNonOneQueryMasks.card = 385 := by
  simpa [censusSummary, expectedCensusSummary] using
    congrArg CensusSummary.exactTwoCount census_audit.1

/-- Exact depth rows for the 385 tasks with a two-node certificate and a formal
obstruction to the recorded Boolean one-query weight criterion.  Interpreting
the second coordinate as unrestricted quantum query complexity additionally
uses the analytic bridge stated in the paper but not formalized here. -/
theorem exact_two_query_rows :
    exactTwoQueryRows = [(2, 2, 48), (3, 2, 248), (4, 2, 89)] := by
  simpa [censusSummary, expectedCensusSummary] using
    congrArg CensusSummary.exactTwoRows census_audit.1

theorem depth_two_tasks_have_no_one_query_certificate {mask : Nat}
    (hm : mask ∈ depthTwoNonOneQueryMasks) :
    ¬ Nonempty (BooleanOneQueryWeightCertificate (maskTask mask)) := by
  exact no_boolean_one_query_of_three_essential
    (Finset.mem_filter.mp hm).2.2

/-- The number `6040` is only a restricted-certificate depth-three count. -/
theorem remaining_certificate_depth_three_count :
    (normalizedBalancedMasks.val.map certificateDepth).count 3 = 6040 := by
  simpa [depthHistogram] using
    congrArg (fun xs => xs[3]!) certificate_depth_histogram

end AnswerPartitions.CensusFourExact
