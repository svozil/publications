import AnswerPartitions.Basic
import AnswerPartitions.BlockDiscrimination
import AnswerPartitions.Deutsch
import AnswerPartitions.ControlledResponse
import AnswerPartitions.ResponseSpectrum
import AnswerPartitions.Parity
import AnswerPartitions.CensusThree
import AnswerPartitions.CensusFourExact
import AnswerPartitions.CensusFourEncoding
import AnswerPartitions.BernsteinVazirani

/-!
# Answer partitions and oracle access

Machine-checked companion formalization for
"Answer Partitions and Oracle Access Determine Quantum Query Complexity".
-/
