# Formalization findings

## Outcome

The encoded finite and algebraic claims are mutually consistent; no
counterexample was found to the statements brought into Lean. The
formalization also makes the paper’s central distinction precise: the answer
map supplies a fiber partition, while orthogonality and query cost require
additional oracle/protocol data.

There are two proof-trust levels in the project. The ordinary algebraic proofs
produce terms checked by Lean’s kernel. The exhaustive census theorems use
`native_decide`: Lean compiles and runs the decision procedure, then introduces
a generated axiom recording that the closed Boolean computation returned
`true`. Those theorems therefore also trust Lean’s compiler/native evaluator
(including compiled implementations), not only kernel reduction. This is an
explicit audit boundary, not a hidden `sorry`.

An explicit `#print axioms` audit found one generated native-decision axiom in
each of `depth_census_audit`, `orbit_census_audit`, and the four-bit
`census_audit`. Other sampled central theorems depend only on Lean/mathlib’s
standard `propext`, `Classical.choice`, and `Quot.sound` foundations (and one
elementary partition theorem depends on no axioms at all).

The project intentionally does not turn the paper’s unresolved four-bit SDP
rows into theorems. Those rows depend on numerical infeasibility reports, not
exact dual certificates.

## What is machine checked

| Paper claim | Lean status | Main declarations |
|---|---|---|
| Answer cells are fibers and form an equivalence partition | Full | `answerCell`, `sameAnswer_equivalence`, `cells_eq_or_disjoint` |
| Cross-cell Gram zeros iff distinct output-cell spans are orthogonal | Full, pure-state geometry | `blockOrthogonal_iff_cellSpans` |
| Fixed input/output unitary changes preserve one-query Gram geometry | Full, pure-state geometry | `pureOneQueryResolves_fixedEquivalentFamily_iff` |
| Deutsch constant/balanced outputs are orthogonal across cells but overlap within cells | Full | `deutsch_blockOrthogonal`, `deutsch_constant_instances_overlap`, `deutsch_balanced_instances_overlap` |
| Response constraints force `p₀=p₁=1/2`, `z₀=z₁=-1/2` | Full scalar proof | `response_constraints_force_halves`, `complex_response_constraints_force_halves` |
| Cyclic response is unitary and has eigenvalue `-1` iff positive `d` is even | Full, direct matrix proof | `cyclicShift_mem_unitaryGroup`, `cyclicShift_hasNegOneEigenvector_iff_even` |
| Boolean one-query overlap is zero iff differing-coordinate weight is `1/2` | Full inside the encoded weight reduction | `booleanPhaseOverlap_eq_zero_iff` |
| A one-query Boolean weight certificate has at most two essential coordinates | Full inside the encoded weight reduction | `oneQuery_essentialCoordinates_card_le_two` |
| One-query parity requires `N ≤ 2` | Full inside the encoded weight reduction | `parity_oneQuery_weightCriterion_implies_le_two`, `parity_three_no_oneQuery_weightCertificate` |
| All 35 balanced three-bit tasks and six orbits under the declared symmetry action | Exhaustive native computation | `depth_census_audit`, `orbit_census_audit` and their projections |
| Weighted-distance witnesses or contradictions for the six three-bit representatives | Full over rational weights; no general quantum-semantics bridge | declarations near the end of `CensusThree.lean` |
| Four-bit task/mask representation is exhaustive and canonical | Full, ordinary kernel-checked proofs | `taskMaskEquiv`, `normalizedTaskMaskEquiv`, `maskTask_encodeTask`, `encodeTask_maskTask` |
| All 6,435 normalized balanced four-bit tasks have the reported deterministic and restricted certificate-depth histograms | Exhaustive native computation | `census_audit`, `deterministic_depth_histogram`, `certificate_depth_histogram` |
| Ten atomic cases and 385 further depth-two certificate cases have the reported deterministic-depth rows | Full inside the encoded weight/certificate model, with native census trust | `one_query_rows_exact`, `depth_two_non_one_query_count`, `exact_two_query_rows` |
| A surviving BV answer cell has `2^k` outcomes | Full combinatorial statement | `survivingBVFiberEquiv`, `survivingBVFiber_card` |
| The declared rational leaky-BV distribution is normalized and has the claimed support | Full for the declared distribution, not derived from a circuit | `leakyBVProbability_sum` and support lemmas |
| Fewer than `m=n-k` linear equations cannot identify the surviving label | Full linear-algebraic core | `linearTranscript_collision`, `no_linearTranscript_decoder` |

## Important formalization boundaries

1. **Density operators and PVMs.** The project proves the pure-state geometric
   core of block discrimination and allows the ambient Hilbert space to include
   a reference. It does not formalize partial trace, purification, support
   projectors, and the complete density-operator/PVM equivalence as one theorem.

2. **Response-spectrum theorem.** The scalar necessity calculation, its
   equality case, the controlled-response sufficiency direction, and the cyclic
   spectral corollary are checked. A single end-to-end theorem quantifying over
   every mixed probe/reference protocol needs the density-matrix layer above.

3. **Certificate model versus quantum queries.** Exact bit queries and
   bit/pair-parity trees are executable certificate models. The code does not
   define a general quantum-query semantics or prove that every certificate
   node has the asserted query cost, that certificates compose coherently, or
   that every general quantum protocol is bounded by this model. In particular,
   interpreting a pair parity as one Deutsch query and deferring intermediate
   measurements are mathematical bridges outside the current Lean theorem set.

4. **Three-bit census scope.** The tree census itself is exact finite
   computation, subject to the `native_decide` trust boundary. The one-query
   feasibility predicate in `CensusThree.lean` is typed over `ℚ`; the project
   does not prove that restricting a real/complex probe to rational weights is
   without loss of generality. The orbit theorem does cover the 35 normalized
   tasks under the explicitly defined action—coordinate permutations, input
   complements, and answer exchange. Only the identification of those six Lean
   definitions with the paper’s named table representatives remains an
   external, human-reviewed correspondence.

5. **General parity complexity.** The one-query obstruction is proved. The
   equality `Q_E(Par_N)=ceil(N/2)` is not reproved because its lower bound needs
   the polynomial-method theorem connecting `T` queries to acceptance degree
   at most `2T`.

6. **Bernstein–Vazirani channel.** `leakyBVProbability` is a declared finite
   rational distribution with the support and weights predicted by the paper;
   Lean proves its normalization but does not derive it from the quantum
   circuit. The separate transcript lower bound applies to linear maps. The
   partial-trace/Hadamard identity and an averaging lower bound for arbitrary
   randomized adaptive value-query protocols are not formalized.

7. **Four-bit numerical candidates.** `CensusFourEncoding.lean` proves an
   encode/decode equivalence between all four-bit Boolean functions and the
   16-bit masks, and a restricted equivalence for normalized balanced tasks.
   The depth-two results are nevertheless certificate-model results subject to
   item 3. The 43 unresolved orbit representatives (6,040 partitions),
   candidate rows
   `(D,Q_E)=(3,3),(4,3)`, and totals derived from them remain outside the exact
   quantum theorem set. Floating-point SDP agreement is robustness evidence,
   not an exact lower bound.

## Concrete review findings

- The manuscript PDF metadata, manuscript title, and integrated supplement now
  consistently use “Answer Partitions and Oracle Access Determine Quantum
  Query Complexity.”
- The paper correctly labels the unresolved four-bit assignments as numerical
  candidates. This qualification is mathematically essential.
- The BV section changes from singleton identification to the surviving
  partition indexed by `a_{\bar S}`. The paper says so explicitly; the Lean
  definition `survivingBVAnswer` makes that task change impossible to overlook.
- The finite census supports no asymptotic conclusion. Its percentages are
  finite-model facts under the fixed reversible Boolean value oracle.
- No handwritten `sorry`, `admit`, or declared project axiom is intended in the
  delivered source. The `native_decide` census proofs nevertheless create
  generated native-evaluation axioms, as described above.

## Suggested next proof work

1. Formalize finite-dimensional density matrices, partial trace, purification,
   and support projectors to close Proposition 1 end to end.
2. Prove the certificate-to-quantum-semantics bridge, including coherent
   composition of pair-parity/Deutsch nodes.
3. Extract exact rational dual infeasibility certificates for the unresolved
   four-bit two-query SDPs.
4. Import or prove the polynomial method for the full parity lower bound.
5. Derive the BV distribution from the partial-trace/Hadamard circuit identity,
   then formalize the arbitrary-protocol classical lower bound.
