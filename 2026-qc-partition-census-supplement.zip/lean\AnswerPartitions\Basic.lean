import Mathlib.Data.Set.Basic
import Mathlib.Data.Set.Disjoint

/-!
# Finite answer partitions

The paper's kinematic data are represented by an answer map `g : Ω → J`.
Its cells are the fibers of `g`.  No oracle or query-cost claim is built into
this definition.
-/

namespace AnswerPartitions

universe u v

/-- The answer cell with label `j`, i.e. `g⁻¹({j})`. -/
def answerCell {Ω : Type u} {J : Type v} (g : Ω → J) (j : J) : Set Ω :=
  {a | g a = j}

@[simp] theorem mem_answerCell {Ω : Type u} {J : Type v}
    (g : Ω → J) (j : J) (a : Ω) : a ∈ answerCell g j ↔ g a = j :=
  Iff.rfl

/-- Two instances lie in the same answer cell exactly when their answers agree. -/
def SameAnswer {Ω : Type u} {J : Type v} (g : Ω → J) (a a' : Ω) : Prop :=
  g a = g a'

theorem sameAnswer_equivalence {Ω : Type u} {J : Type v} (g : Ω → J) :
    Equivalence (SameAnswer g) := by
  constructor
  · intro a
    rfl
  · intro a a' h
    exact h.symm
  · intro a a' a'' h₁ h₂
    exact h₁.trans h₂

/-- The set of nonempty answer cells, indexed without quotienting the labels. -/
def answerPartition {Ω : Type u} {J : Type v} (g : Ω → J) : Set (Set Ω) :=
  answerCell g '' Set.range g

theorem answerCell_nonempty_iff {Ω : Type u} {J : Type v}
    (g : Ω → J) (j : J) : (answerCell g j).Nonempty ↔ j ∈ Set.range g := by
  constructor
  · rintro ⟨a, ha⟩
    exact ⟨a, ha⟩
  · rintro ⟨a, rfl⟩
    exact ⟨a, rfl⟩

theorem cells_eq_or_disjoint {Ω : Type u} {J : Type v}
    (g : Ω → J) (j k : J) :
    answerCell g j = answerCell g k ∨ Disjoint (answerCell g j) (answerCell g k) := by
  by_cases h : j = k
  · exact Or.inl (congrArg (answerCell g) h)
  · right
    rw [Set.disjoint_left]
    intro a haj hak
    exact h ((mem_answerCell g j a).mp haj |>.symm.trans ((mem_answerCell g k a).mp hak))

theorem mem_some_answerCell {Ω : Type u} {J : Type v}
    (g : Ω → J) (a : Ω) : a ∈ answerCell g (g a) :=
  rfl

end AnswerPartitions
