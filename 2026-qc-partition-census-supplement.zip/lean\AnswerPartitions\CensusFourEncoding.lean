import AnswerPartitions.CensusFourExact

/-!
# Canonicity of the four-bit truth-table encoding

`CensusFourExact` evaluates tasks through a natural-number truth-table mask.
This file proves that this representation is exhaustive and canonical on the
intended 16-bit range.  In particular, encoding and then decoding any Boolean
task on four bits returns the original task, and normalized balanced tasks are
equivalent to membership in `normalizedBalancedMasks`.

The only finite computations below are small kernel reductions (`by decide`)
showing that `inputIndex` enumerates the sixteen inputs without repetition.
There are no project-declared axioms, omitted proofs, or native-code proof
oracles in this module.
-/

namespace AnswerPartitions.CensusFourEncoding

open AnswerPartitions
open AnswerPartitions.CensusFourExact

/-- The 16 input indices are pairwise distinct. -/
theorem inputIndex_injective : Function.Injective inputIndex := by
  decide

/-- Every four-bit input index lies in the intended 16-bit mask range. -/
theorem inputIndex_lt_sixteen : ∀ x : Input, inputIndex x < 16 := by
  decide

/-- `inputIndex` visits every index from zero through fifteen. -/
theorem inputIndex_fin_surjective :
    Function.Surjective
      (fun x : Input => (⟨inputIndex x, inputIndex_lt_sixteen x⟩ : Fin 16)) := by
  decide

/-- Inputs on which a task has Boolean value `true`. -/
def trueInputs (f : Input → Bool) : Finset Input :=
  Finset.univ.filter fun x => f x = true

/-- Indices of the inputs on which a task has Boolean value `true`. -/
def trueIndices (f : Input → Bool) : Finset Nat :=
  (trueInputs f).image inputIndex

/-- `encodeTask` is exactly the binary number having `trueIndices` as its set
of active bit positions. -/
theorem encodeTask_eq_sum_trueIndices (f : Input → Bool) :
    encodeTask f = ∑ k ∈ trueIndices f, 2 ^ k := by
  rw [trueIndices, Finset.sum_image inputIndex_injective.injOn]
  unfold encodeTask trueInputs
  rw [Finset.sum_filter]

/-- The bit indices of the encoded task are exactly the indices of its true
truth-table entries. -/
theorem bitIndices_encodeTask (f : Input → Bool) :
    (encodeTask f).bitIndices.toFinset = trueIndices f := by
  rw [encodeTask_eq_sum_trueIndices, Finset.toFinset_bitIndices_sum_two_pow]

theorem inputIndex_mem_trueIndices_iff (f : Input → Bool) (x : Input) :
    inputIndex x ∈ trueIndices f ↔ f x = true := by
  constructor
  · intro h
    obtain ⟨y, hy, hidx⟩ := Finset.mem_image.mp h
    have hyx : y = x := inputIndex_injective hidx
    subst y
    exact (Finset.mem_filter.mp hy).2
  · intro h
    exact Finset.mem_image.mpr
      ⟨x, Finset.mem_filter.mpr ⟨Finset.mem_univ _, h⟩, rfl⟩

/-- Exhaustiveness: every Boolean task on four bits is recovered exactly by
decoding its truth-table mask. -/
theorem maskTask_encodeTask (f : Input → Bool) :
    maskTask (encodeTask f) = f := by
  funext x
  apply Bool.eq_iff_iff.mpr
  change (encodeTask f).testBit (inputIndex x) = true ↔ f x = true
  rw [← Nat.mem_bitIndices]
  have h := inputIndex_mem_trueIndices_iff f x
  rwa [← bitIndices_encodeTask f, List.mem_toFinset] at h

/-- Encoded four-bit tasks always fit in the low sixteen bits. -/
theorem encodeTask_lt_two_pow (f : Input → Bool) :
    encodeTask f < 2 ^ 16 := by
  rw [encodeTask_eq_sum_trueIndices]
  apply Nat.geomSum_lt (by omega)
  intro k hk
  obtain ⟨x, -, rfl⟩ := Finset.mem_image.mp hk
  exact inputIndex_lt_sixteen x

/-- Canonicity: two masks in the intended 16-bit range that decode to the same
task are equal. -/
theorem maskTask_injective_below {m n : Nat}
    (hm : m < 2 ^ 16) (hn : n < 2 ^ 16)
    (h : maskTask m = maskTask n) : m = n := by
  apply Nat.eq_of_testBit_eq
  intro k
  by_cases hk : k < 16
  · obtain ⟨x, hx⟩ := inputIndex_fin_surjective ⟨k, hk⟩
    have hval : inputIndex x = k := congrArg Fin.val hx
    have hpoint := congrFun h x
    change m.testBit (inputIndex x) = n.testBit (inputIndex x) at hpoint
    simpa [hval] using hpoint
  · have h16 : 16 ≤ k := Nat.le_of_not_gt hk
    have hpow : 2 ^ 16 ≤ 2 ^ k := Nat.pow_le_pow_right (by omega) h16
    rw [Nat.testBit_eq_false_of_lt (hm.trans_le hpow),
      Nat.testBit_eq_false_of_lt (hn.trans_le hpow)]

/-- Decoding and then re-encoding a mask below `2^16` returns that mask. -/
theorem encodeTask_maskTask {mask : Nat} (hmask : mask < 2 ^ 16) :
    encodeTask (maskTask mask) = mask := by
  apply maskTask_injective_below (encodeTask_lt_two_pow _) hmask
  exact maskTask_encodeTask (maskTask mask)

/-- A genuine equivalence between four-bit Boolean tasks and 16-bit masks. -/
def taskMaskEquiv : (Input → Bool) ≃ Fin (2 ^ 16) where
  toFun f := ⟨encodeTask f, encodeTask_lt_two_pow f⟩
  invFun mask := maskTask mask.val
  left_inv := maskTask_encodeTask
  right_inv mask := Fin.ext (encodeTask_maskTask mask.isLt)

/-- Task-level version of the normalized balanced-mask predicate. -/
def IsNormalizedBalancedTask (f : Input → Bool) : Prop :=
  ((Finset.univ : Finset Input).filter fun x => f x = true).card = 8 ∧
    f zeroInput = false

theorem isNormalizedBalancedMask_encodeTask_iff (f : Input → Bool) :
    IsNormalizedBalancedMask (encodeTask f) ↔ IsNormalizedBalancedTask f := by
  unfold IsNormalizedBalancedMask IsNormalizedBalancedTask
  rw [maskTask_encodeTask]

/-- Normalized balanced four-bit Boolean tasks are in bijection with the
finite mask family used by the exhaustive census. -/
def normalizedTaskMaskEquiv :
    {f : Input → Bool // IsNormalizedBalancedTask f} ≃
      {mask : Nat // mask ∈ normalizedBalancedMasks} where
  toFun f :=
    ⟨encodeTask f, Finset.mem_filter.mpr
      ⟨Finset.mem_range.mpr (encodeTask_lt_two_pow f),
        (isNormalizedBalancedMask_encodeTask_iff f).2 f.property⟩⟩
  invFun mask := ⟨maskTask mask.val, by
    have hm := (Finset.mem_filter.mp mask.property).2
    simpa [IsNormalizedBalancedMask, IsNormalizedBalancedTask] using hm⟩
  left_inv f := Subtype.ext (maskTask_encodeTask f)
  right_inv mask := Subtype.ext
    (encodeTask_maskTask (Finset.mem_range.mp
      (Finset.mem_filter.mp mask.property).1))

end AnswerPartitions.CensusFourEncoding
