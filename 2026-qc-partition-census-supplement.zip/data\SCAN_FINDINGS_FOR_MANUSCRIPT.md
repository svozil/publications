# Exhaustive small-oracle scan: findings and limits

## What was classified

The scan fixes the standard reversible Boolean value oracle

```text
O_b |i,y> = |i,y xor b_i>
```

and considers every balanced, unlabeled two-answer decision problem on the
hidden strings `b in {0,1}^m`.  Thus the experiment varies the target
partition while holding the oracle interface fixed.  Classical cost is exact
deterministic query depth and quantum cost is exact, zero-error query count.

Coordinate permutations and independent coordinate complements preserve
this oracle model.  Quotienting by those transformations, and by exchange of
the two answer cells, reduces the 35 partitions for `m=3` to 6 orbits and the
6,435 partitions for `m=4` to 58 orbits.  All statistics below are weighted by
orbit size, so they count the original partitions rather than orbit
representatives.

## Exact three-address result

All 35 balanced partitions are classified exactly:

| `(D_exact,Q_exact)` | Number of partitions |
|---:|---:|
| `(1,1)` | 3 |
| `(2,1)` | 3 |
| `(2,2)` | 12 |
| `(3,2)` | 17 |

Consequently 20 of the 35 partitions have an exact quantum advantage: three
have factor 2 and seventeen have factor `3/2`.  The other fifteen have no
exact-query advantage.

No floating-point inference is needed here.  One-query feasibility or
infeasibility is solved as an exact rational problem.  The two-query upper
bounds are explicit adaptive trees whose nodes obtain either one hidden bit
or the parity of two hidden bits.  A two-bit parity is obtainable with one
Deutsch query.

Two representative constructions are especially transparent:

- Three-bit majority has zero cell `{000,001,010,100}`.  First obtain
  `b1 xor b2`.  If it is zero, query `b1`; if it is one, query `b3`.  The
  second result is the majority value.
- For `F(b1,b2,b3)=b1 xor (b2 and b3)`, with zero cell
  `{000,001,010,111}`, first query `b2`.  If `b2=0`, query `b1`; if `b2=1`,
  obtain `b1 xor b3` with one Deutsch query.  This decides `F` in two calls.

Both functions have real multilinear degree three, so the polynomial lower
bound `degree(F) <= 2 Q_exact(F)` excludes one query.  Their two-query
algorithms are therefore optimal.  The saved JSON files contain the complete
decision trees, not merely their query counts.

## Four-address result

The exact symbolic machinery settles 395 of the 6,435 partitions:

| `(D_exact,Q_exact)` | Exactly certified partitions |
|---:|---:|
| `(1,1)` | 4 |
| `(2,1)` | 6 |
| `(2,2)` | 48 |
| `(3,2)` | 248 |
| `(4,2)` | 89 |

Among this exact subset, 343 partitions have a speedup and 52 do not.

For the remaining 6,040 partitions, SCS at requested tolerances `1e-7` and
`1e-8` gave the same result for every one of the 43 remaining orbits: the
two-query Gram SDP was reported infeasible.  An exact value/pair-parity tree
uses three queries.  If the numerical lower bounds are correct, the remaining
histogram is

| `(D_exact,Q_exact candidate)` | Partitions |
|---:|---:|
| `(3,3)` | 1,536 |
| `(4,3)` | 4,504 |

This would yield 4,847 speedup partitions and 1,588 no-speedup partitions in
total.  These two four-address rows, and totals depending on them, remain
**numerical candidates**.  Repeating one solver at a tighter tolerance is a
stability check, not an exact infeasibility proof.  Clarabel failed internally
on these 16-instance SDPs and therefore supplied neither confirmation nor a
contradiction.  Exact dual certificates would be needed before presenting the
6,040 classifications as theorems.

### Cross-validation with Montanaro--Jozsa--Mitchison

The 58 representatives were mapped to the NPN truth-table identifiers in
Appendix A of Montanaro, Jozsa, and Mitchison, *Algorithmica* 71, 775--796
(2015). After removing dummy variables, all 15 representatives certified here
with one or two queries agree with their corresponding published entries.
For the 43 remaining representatives their numerical two-query success
probabilities range from 0.900 to 0.986, consistently below one. The full
mapping is stored in `m4-mjm-crosscheck.csv`.

This agreement is a useful independent check of enumeration, orbit reduction,
and numerical status. It is not an exact lower-bound proof: their table and
the present SCS output are both floating-point calculations.

## Interpretation for the manuscript

The partition picture is useful, but only as the definition of the decision
problem.  It says which oracle instances must receive the same answer.  It
does not say how cheaply the fixed oracle can separate the two cells.

The small exact examples sharpen the operational point.  A speedup occurs
when the answer partition can be assembled from distinctions that one oracle
call makes available coherently—for example a two-address parity—possibly
with later distinctions conditioned on the earlier result.  Merely writing a
projector or observable whose eigenspaces are the two answer cells does not
provide access to that observable and does not bound query complexity.

The finite data support a sober conclusion: for these small balanced exact
problems, advantages are common but modest, and they arise from the relation
between the target and the oracle's one-query Gram transformations.  They do
not establish that “globality” of a partition is by itself a speedup
criterion.  Nor do proportions at `m=3` or `m=4` establish an asymptotic law.
Any manuscript claim should keep four qualifications explicit:

1. the oracle is the standard reversible value oracle;
2. only balanced binary target partitions are counted;
3. the comparison is deterministic exact versus quantum exact query cost;
4. asymptotic speedup concerns families of problems as `m` grows, not a
   single finite partition.

The strongest next mathematical step is to extract exact primal or dual
certificates for the four-address two-query SDPs.  The strongest next
complexity step is to study structured asymptotic families and bounded-error
query complexity rather than extrapolating percentages from the finite scan.
