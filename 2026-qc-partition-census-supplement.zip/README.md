# Finite oracle-partition census: reproducibility archive

This archive is the Supplemental Material for *Answer Partitions, Oracle Response Spectra, and Exact Quantum Query Advantage* (K. Svozil, Physical Review A,
manuscript XU11228A; submitted as *Answer Partitions and Oracle Access
Determine Quantum Query Complexity*). Version of 6 November 2026.
It contains the Python implementation, tests, generated CSV output, exact and
audited numerical witnesses, exact rational dual certificates with a
standalone verifier, a Lean 4 companion formalization, and an explanatory
supplement.

**Change from the July 2026 version.** The 43 four-address orbit
representatives (6,040 partitions) that were labelled `numerical_candidate`
are now settled exactly by rational dual certificates (`dual-certificates/`).
In `data/results-m4-orbits.csv`, `data/m4-mjm-crosscheck.csv`, and
`witnesses-m4/`, these rows now carry `exact_dual_certificate`, and every row
states the source of its lower bound (`Q_lower_bound_source`). No numerical
candidate remains.

## Contents

- `supplementary_partition_census.tex` and `supplementary_partition_census.pdf`:
  detailed mathematical and code documentation;
- `code/partition_query_scan.py`: the scanner;
- `code/test_partition_query_scan.py`: unit tests;
- `code/requirements-partition-scan.txt`: Python dependencies;
- `data/`: the three-address and four-address orbit scans, the one-query
  screen, and the cross-validation against the published Montanaro--Jozsa--
  Mitchison NPN identifiers;
- `witnesses-m3/` and `witnesses-m4/`: JSON certificates and compressed SDP
  witnesses for the canonical orbit representatives;
- `dual-certificates/`: the 43 exact rational dual certificates proving the
  two-query lower bounds, the standalone verifier `verify_cert.py`, and the
  scripts used to find them (see `dual-certificates/README.md`);
- `data/results-m4-orbits-scs-1e-8.csv` and `witnesses-m4-scs-1e-8/`: the
  tighter-tolerance SCS rerun of the July version, kept unchanged as the
  numerical record; its lower-bound entries of 3 for the 43 orbits were
  numerical when written and are superseded by `dual-certificates/`;
- `data/PARTITION_QUERY_SCAN.md`: the command reference;
- `data/SCAN_FINDINGS_FOR_MANUSCRIPT.md`: the interpreted census findings;
- `lean/`: the Lean 4 source, build configuration, and formalization report;
- `examples/deutsch_truth_tables.csv`: a small custom-table example.

The principal CSV files in this archive have portable witness paths such as
`witnesses-m3/partition-0002-q2.json`.  The original absolute paths from the
local scan have been normalized only in these archive copies; the numerical
content is unchanged. The separately preserved `scs-1e-8` validation CSV is
the raw terminal output and therefore retains its original absolute witness
paths.

## Reproduce the principal scans

From the extracted archive root, install Python 3.10+ dependencies:

```powershell
python -m pip install -r code/requirements-partition-scan.txt
```

Then run the complete three-address orbit scan:

```powershell
python code/partition_query_scan.py --boolean-inputs 3 --orbit-reduce --show-all --csv data/results-m3-orbits.csv --witness-dir witnesses-m3
```

The four-address scan is larger and uses the numerical SCS test for the
unsettled two-query lower bounds:

```powershell
python code/partition_query_scan.py --boolean-inputs 4 --orbit-reduce --solver SCS --tolerance 1e-8 --csv data/results-m4-orbits.csv --witness-dir witnesses-m4
```

No run is required for the author to use this archive: the supplied CSV files
and witnesses are the outputs used for the manuscript.  Running the commands
is useful only as an independent local verification, and solver versions may
change floating-point statuses.

## Reproduce the Lean checks

The `lean/` directory is a standalone Lean 4 project pinned to Lean `4.30.0`
and mathlib `v4.30.0`. From the extracted archive root, run:

```powershell
cd lean
lake update
lake build
```

The formalization checks the answer-fiber and pure-state block-orthogonality
results, the Deutsch and response-spectrum calculations, Boolean one-query
weight obstructions, the complete normalized three-address census, the
four-address task/mask equivalence, the complete deterministic and restricted
certificate-tree histograms for all 6,435 normalized four-address tasks, and
the finite combinatorial core of the Bernstein--Vazirani example.

The census audits use Lean's `native_decide`, so those closed computations
additionally trust Lean's compiler and native evaluator. More importantly,
the bit/pair-parity trees are a formally checked certificate model; the
project does not yet formalize the general quantum-query semantics theorem
that identifies every such certificate depth with unrestricted exact quantum
query complexity. The two-query lower bounds for the 6,040 remaining cases
are proved by the dual certificates in `dual-certificates/`, which are checked
by an exact-arithmetic Python verifier rather than in Lean. See
`lean/README.md` and `lean/FINDINGS.md` for the precise claim and trust
boundaries.

## Check the dual certificates

```powershell
cd dual-certificates
python verify_cert.py certificates_N4.json
```

The verifier needs only the Python standard library and takes a few seconds.

## Status of the results

The three-address results are exact.  The four-address results are exact for
all 6,435 partitions: 395 are settled by exact one-query obstructions and
explicit trees, and the remaining 43 orbit rows, covering 6,040 partitions, by
explicit three-query trees together with the rational dual certificates in
`dual-certificates/` (certified two-query success bounds 0.90005-0.98611).
The file `data/m4-mjm-crosscheck.csv` records the independent cross-check
against the published numerical values of Montanaro, Jozsa, and Mitchison;
that agreement is robustness evidence, while the exact lower bounds come from
the certificates.
