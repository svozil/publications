# Finite oracle-partition census: reproducibility archive

This archive accompanies *Answer Partitions and Oracle Access Determine
Quantum Query Complexity*.
It contains the Python implementation, tests, generated CSV output, exact and
audited numerical witnesses, a Lean 4 companion formalization, and a
standalone explanatory supplement.

## Contents

- `supplementary_partition_census.tex` and `supplementary_partition_census.pdf`:
  detailed mathematical and code documentation;
- `code/partition_query_scan.py`: the scanner;
- `code/test_partition_query_scan.py`: unit tests;
- `code/requirements-partition-scan.txt`: Python dependencies;
- `data/`: the three-address and four-address orbit scans, the one-query
  screen, and the cross-validation against the published Montanaro--Jozsa--
  Mitchison NPN identifiers;
- `witnesses-m3/` and `witnesses-m4/`: JSON certificates and compressed SDP
  witnesses for the canonical orbit representatives;
- `data/results-m4-orbits-scs-1e-8.csv` and `witnesses-m4-scs-1e-8/`: the
  independent tighter-tolerance rerun reported in the revised manuscript;
- `data/PARTITION_QUERY_SCAN.md`: the command reference;
- `data/SCAN_FINDINGS_FOR_MANUSCRIPT.md`: the interpreted census findings;
- `lean/`: the Lean 4 source, build configuration, and formalization report;
- `examples/deutsch_truth_tables.csv`: a small custom-table example.

The principal CSV files in this archive have portable witness paths such as
`witnesses-m3/partition-0002-q2.json`.  The original absolute paths from the
local scan have been normalized only in these archive copies; the numerical
content is unchanged. The separately preserved `scs-1e-8` validation CSV is
the raw terminal output and therefore retains its original absolute witness
paths.

## Reproduce the principal scans

From the extracted archive root, install Python 3.10+ dependencies:

```powershell
python -m pip install -r code/requirements-partition-scan.txt
```

Then run the complete three-address orbit scan:

```powershell
python code/partition_query_scan.py --boolean-inputs 3 --orbit-reduce --show-all --csv data/results-m3-orbits.csv --witness-dir witnesses-m3
```

The four-address scan is larger and uses the numerical SCS test for the
unsettled two-query lower bounds:

```powershell
python code/partition_query_scan.py --boolean-inputs 4 --orbit-reduce --solver SCS --tolerance 1e-8 --csv data/results-m4-orbits.csv --witness-dir witnesses-m4
```

No run is required for the author to use this archive: the supplied CSV files
and witnesses are the outputs used for the manuscript.  Running the commands
is useful only as an independent local verification, and solver versions may
change floating-point statuses.

## Reproduce the Lean checks

The `lean/` directory is a standalone Lean 4 project pinned to Lean `4.30.0`
and mathlib `v4.30.0`. From the extracted archive root, run:

```powershell
cd lean
lake update
lake build
```

The formalization checks the answer-fiber and pure-state block-orthogonality
results, the Deutsch and response-spectrum calculations, Boolean one-query
weight obstructions, the complete normalized three-address census, the
four-address task/mask equivalence, the complete deterministic and restricted
certificate-tree histograms for all 6,435 normalized four-address tasks, and
the finite combinatorial core of the Bernstein--Vazirani example.

The census audits use Lean's `native_decide`, so those closed computations
additionally trust Lean's compiler and native evaluator. More importantly,
the bit/pair-parity trees are a formally checked certificate model; the
project does not yet formalize the general quantum-query semantics theorem
that identifies every such certificate depth with unrestricted exact quantum
query complexity. It also does not turn the 6,040 SDP-dependent cases into
theorems. See `lean/README.md` and `lean/FINDINGS.md` for the precise claim and
trust boundaries.

## Interpretation warning

The three-address results are exact.  The four-address result is exact for 395
partitions; the remaining 43 orbit rows, covering 6,040 partitions, depend on
numerical SDP infeasibility and are explicitly labelled
`numerical_candidate`.  They should not be quoted as formal theorems without
exact dual infeasibility certificates.  The file
`data/m4-mjm-crosscheck.csv` records the independent published numerical
cross-check; agreement between floating-point calculations is robustness
evidence, not an exact lower bound.
