import Mathlib

/-!
# The balanced three-bit census

This file gives an executable, exact census for the three-bit Boolean part of
the paper.  A normalized task is a balanced Boolean function whose value at
`000` is false; this chooses one of the two complementary answer labels.

Two finite query-tree models are deliberately kept separate:

* `deterministicDepth` permits ordinary single-bit queries;
* `certificateDepth` permits either a single-bit query or the parity of a
  pair of bits.  A pair-parity node represents the one-query Deutsch
  subroutine.  Thus these trees are exact *certificates* in that restricted
  model, not a definition or characterization of arbitrary quantum query
  algorithms.

The closed census propositions below are discharged with `native_decide`.
Consequently no external enumeration script is trusted, but this is not pure
kernel reduction: the trusted path includes Lean's native compiler and
evaluator.  The symbolic weighted-distance impossibility proofs at the end of
the file use ordinary kernel-checked rewriting and linear arithmetic instead.
-/

namespace AnswerPartitions.CensusThree

/-- A coordinate of a three-bit string. -/
abbrev Coord := Fin 3

/-- A three-bit Boolean oracle instance. -/
abbrev Input := Coord → Bool

/-- A binary task on three-bit inputs. -/
abbrev ThreeTask := Input → Bool

/-- The all-zero oracle instance. -/
def zeroInput : Input := ![false, false, false]

/-- Inputs on which a task has answer `true`. -/
def trueCell (f : ThreeTask) : Finset Input :=
  Finset.univ.filter fun x => f x = true

/-- A balanced three-bit task has four inputs in either answer cell. -/
def IsBalanced (f : ThreeTask) : Prop :=
  (trueCell f).card = 4

/-- Normalization quotients answer exchange by requiring `f(000) = false`. -/
def IsNormalized (f : ThreeTask) : Prop :=
  f zeroInput = false

instance (f : ThreeTask) : Decidable (IsBalanced f) := by
  unfold IsBalanced
  infer_instance

instance (f : ThreeTask) : Decidable (IsNormalized f) := by
  unfold IsNormalized
  infer_instance

/-- All unlabeled balanced three-bit answer partitions, in normalized form. -/
def normalizedBalancedTasks : Finset ThreeTask :=
  Finset.univ.filter fun f => IsBalanced f ∧ IsNormalized f

/-! ## Executable exact query-tree depth -/

/-- The three allowed ordinary point queries. -/
inductive BitQuery where
  | q0 | q1 | q2
  deriving DecidableEq, Fintype, Repr

/-- Evaluation of an ordinary point query. -/
def BitQuery.eval : BitQuery → Input → Bool
  | .q0, x => x 0
  | .q1, x => x 1
  | .q2, x => x 2

/--
The six atomic certificates used in the paper: a bit, or the parity of one
of the three distinct pairs.  Pair parity is counted as one certificate node.
-/
inductive CertificateQuery where
  | q0 | q1 | q2 | parity01 | parity02 | parity12
  deriving DecidableEq, Fintype, Repr

/-- Evaluation of a bit-or-pair-parity certificate query. -/
def CertificateQuery.eval : CertificateQuery → Input → Bool
  | .q0, x => x 0
  | .q1, x => x 1
  | .q2, x => x 2
  | .parity01, x => Bool.xor (x 0) (x 1)
  | .parity02, x => Bool.xor (x 0) (x 2)
  | .parity12, x => Bool.xor (x 1) (x 2)

/-- Whether `f` is constant on the current information cell `s`. -/
def constantOn (f : ThreeTask) (s : Finset Input) : Bool :=
  let numberTrue := (s.filter fun x => f x = true).card
  numberTrue == 0 || numberTrue == s.card

/--
Exact finite recursion for the existence of a binary query tree of depth at
most `d` on information cell `s`.  A leaf is legal precisely when `f` is
constant on `s`; otherwise a query is chosen and both branches must work.
-/
def canSolveWithin {Q : Type} [Fintype Q] [DecidableEq Q]
    (query : Q → Input → Bool) (f : ThreeTask) (s : Finset Input) : Nat → Bool
  | 0 => constantOn f s
  | d + 1 =>
      constantOn f s ||
        decide (((Finset.univ : Finset Q).filter fun q =>
          canSolveWithin query f (s.filter fun x => query q x = false) d = true ∧
          canSolveWithin query f (s.filter fun x => query q x = true) d = true).card ≠ 0)

/-- Feasibility with at most `d` ordinary bit queries. -/
def bitSolvableWithin (f : ThreeTask) (d : Nat) : Bool :=
  canSolveWithin BitQuery.eval f Finset.univ d

/-- Feasibility with at most `d` bit-or-pair-parity certificate nodes. -/
def certificateSolvableWithin (f : ThreeTask) (d : Nat) : Bool :=
  canSolveWithin CertificateQuery.eval f Finset.univ d

/-- Least ordinary decision-tree depth (all three-bit tasks are solved by 3). -/
def deterministicDepth (f : ThreeTask) : Nat :=
  if bitSolvableWithin f 0 then 0
  else if bitSolvableWithin f 1 then 1
  else if bitSolvableWithin f 2 then 2
  else 3

/--
Least depth in the restricted bit-or-pair-parity certificate-tree model.
This is intentionally not named `quantumDepth`.
-/
def certificateDepth (f : ThreeTask) : Nat :=
  if certificateSolvableWithin f 0 then 0
  else if certificateSolvableWithin f 1 then 1
  else if certificateSolvableWithin f 2 then 2
  else 3

/-- Histogram `(depth, number of normalized balanced tasks)` for a depth map. -/
def depthHistogram (depth : ThreeTask → Nat) : List (Nat × Nat) :=
  [0, 1, 2, 3].map fun d =>
    (d, (normalizedBalancedTasks.filter fun f => depth f = d).card)

/-- One native computation auditing all depth-census claims at once. -/
theorem depth_census_audit :
    normalizedBalancedTasks.card = 35 ∧
    (normalizedBalancedTasks.filter fun f => bitSolvableWithin f 3 = true).card =
      normalizedBalancedTasks.card ∧
    (normalizedBalancedTasks.filter fun f =>
      bitSolvableWithin f (deterministicDepth f) = true ∧
        ((Finset.range (deterministicDepth f)).filter fun d =>
          bitSolvableWithin f d = true).card = 0).card =
      normalizedBalancedTasks.card ∧
    (normalizedBalancedTasks.filter fun f =>
      certificateSolvableWithin f 2 = true).card = normalizedBalancedTasks.card ∧
    (normalizedBalancedTasks.filter fun f =>
      certificateSolvableWithin f (certificateDepth f) = true ∧
        ((Finset.range (certificateDepth f)).filter fun d =>
          certificateSolvableWithin f d = true).card = 0).card =
      normalizedBalancedTasks.card ∧
    depthHistogram deterministicDepth = [(0, 0), (1, 3), (2, 15), (3, 17)] ∧
    depthHistogram certificateDepth = [(0, 0), (1, 6), (2, 29), (3, 0)] ∧
    (normalizedBalancedTasks.filter fun f =>
      certificateDepth f < deterministicDepth f).card = 20 := by
  native_decide

/-- There are exactly `binom(8,4)/2 = 35` balanced unlabeled tasks. -/
theorem normalized_balanced_task_count : normalizedBalancedTasks.card = 35 :=
  depth_census_audit.1

/-- Reading all three bits gives a depth-three tree throughout the census. -/
theorem census_tasks_solvable_in_three :
    (normalizedBalancedTasks.filter fun f => bitSolvableWithin f 3 = true).card =
      normalizedBalancedTasks.card :=
  depth_census_audit.2.1

/-- On the census, the computed ordinary depth is feasible and minimal. -/
theorem deterministicDepth_is_exact :
    (normalizedBalancedTasks.filter fun f =>
      bitSolvableWithin f (deterministicDepth f) = true ∧
        ((Finset.range (deterministicDepth f)).filter fun d =>
          bitSolvableWithin f d = true).card = 0).card =
      normalizedBalancedTasks.card :=
  depth_census_audit.2.2.1

/-- Every normalized balanced task has a depth-two pair-parity certificate. -/
theorem census_tasks_certificate_solvable_in_two :
    (normalizedBalancedTasks.filter fun f =>
      certificateSolvableWithin f 2 = true).card = normalizedBalancedTasks.card :=
  depth_census_audit.2.2.2.1

/-- On the census, the computed certificate depth is feasible and minimal. -/
theorem certificateDepth_is_exact :
    (normalizedBalancedTasks.filter fun f =>
      certificateSolvableWithin f (certificateDepth f) = true ∧
        ((Finset.range (certificateDepth f)).filter fun d =>
          certificateSolvableWithin f d = true).card = 0).card =
      normalizedBalancedTasks.card :=
  depth_census_audit.2.2.2.2.1

/-- Exact deterministic census: 3 tasks at depth 1, 15 at 2, and 17 at 3. -/
theorem deterministic_depth_histogram :
    depthHistogram deterministicDepth = [(0, 0), (1, 3), (2, 15), (3, 17)] :=
  depth_census_audit.2.2.2.2.2.1

/-- Exact restricted-certificate census: 6 tasks at depth 1 and 29 at 2. -/
theorem certificate_depth_histogram :
    depthHistogram certificateDepth = [(0, 0), (1, 6), (2, 29), (3, 0)] :=
  depth_census_audit.2.2.2.2.2.2.1

/-- Exactly 20 of the 35 tasks have a smaller certificate depth than `D`. -/
theorem strict_certificate_advantage_count :
    (normalizedBalancedTasks.filter fun f =>
      certificateDepth f < deterministicDepth f).card = 20 :=
  depth_census_audit.2.2.2.2.2.2.2

/-! ## Six symmetry orbits -/

/-- Representative `x₁` (Lean coordinate 0). -/
def projection : ThreeTask := fun x => x 0

/-- Representative `x₁ xor x₂`. -/
def pairParity : ThreeTask := fun x => Bool.xor (x 0) (x 1)

/-- Representative `Par₃`. -/
def parityThree : ThreeTask := fun x =>
  Bool.xor (Bool.xor (x 0) (x 1)) (x 2)

/-- Representative `Maj₃`. -/
def majorityThree : ThreeTask := fun x =>
  ((x 0 && x 1) || (x 0 && x 2)) || (x 1 && x 2)

/-- Representative `x₁ xor (x₂ x₃)`. -/
def xorAnd : ThreeTask := fun x =>
  Bool.xor (x 0) (x 1 && x 2)

/-- Representative `Sel(x₁,x₂,x₃)`, selecting `x₂` or `x₃`. -/
def selector : ThreeTask := fun x =>
  if x 0 then x 2 else x 1

/-- Choose the answer label for which the value at `000` is false. -/
def normalizeTask (f : ThreeTask) : ThreeTask :=
  if f zeroInput = true then (fun x => !f x) else f

/-- Coordinate permutation followed by independent input complements. -/
def transformInput (p : Equiv.Perm Coord) (mask x : Input) : Input :=
  fun i => Bool.xor (x (p i)) (mask i)

/-- Transform a task and then quotient answer exchange by normalization. -/
def symmetryTransform (f : ThreeTask) (p : Equiv.Perm Coord)
    (mask : Input) : ThreeTask :=
  normalizeTask fun x => f (transformInput p mask x)

/-- Orbit under coordinate permutations, input complements, and answer exchange. -/
def symmetryOrbit (f : ThreeTask) : Finset ThreeTask :=
  (Finset.univ : Finset (Equiv.Perm Coord)).biUnion fun p =>
    (Finset.univ : Finset Input).image fun mask => symmetryTransform f p mask

/-- The representatives in the order used by the paper's table. -/
def orbitRepresentatives : List ThreeTask :=
  [projection, pairParity, parityThree, majorityThree, xorAnd, selector]

/-- Their explicitly generated normalized orbits. -/
def representativeOrbits : List (Finset ThreeTask) :=
  orbitRepresentatives.map symmetryOrbit

/-- The union of the six generated orbits. -/
def representativeOrbitUnion : Finset ThreeTask :=
  representativeOrbits.foldl (fun acc o => acc ∪ o) ∅

/-- Boolean pairwise-disjointness test for a list of finite sets. -/
def pairwiseDisjointFinsets {α : Type} [DecidableEq α] :
    List (Finset α) → Bool
  | [] => true
  | a :: rest =>
      rest.all (fun b => (a ∩ b).card == 0) && pairwiseDisjointFinsets rest

/-- `(orbit size, D, certificate depth)` for the paper's six rows. -/
def representativeRows : List (Nat × Nat × Nat) :=
  orbitRepresentatives.map fun f =>
    ((symmetryOrbit f).card, deterministicDepth f, certificateDepth f)

/--
For each representative, retain every member of its generated orbit whose two
computed depths agree with the representative's.  Equality with
`representativeOrbits` therefore audits the depths of all 35 orbit members,
not merely the six displayed representatives.
-/
def representativeOrbitDepthUniformParts : List (Finset ThreeTask) :=
  orbitRepresentatives.map fun f =>
    (symmetryOrbit f).filter fun g =>
      deterministicDepth g = deterministicDepth f ∧
        certificateDepth g = certificateDepth f

/-- One native computation auditing all six-orbit claims at once. -/
theorem orbit_census_audit :
    representativeOrbits.map Finset.card = [3, 3, 1, 4, 12, 12] ∧
    pairwiseDisjointFinsets representativeOrbits = true ∧
    representativeOrbitUnion = normalizedBalancedTasks ∧
    representativeRows =
      [(3, 1, 1), (3, 2, 1), (1, 3, 2),
       (4, 3, 2), (12, 3, 2), (12, 2, 2)] ∧
    representativeOrbitDepthUniformParts = representativeOrbits := by
  native_decide

/-- Orbit sizes are `3,3,1,4,12,12`, summing to 35. -/
theorem representative_orbit_sizes :
    representativeOrbits.map Finset.card = [3, 3, 1, 4, 12, 12] :=
  orbit_census_audit.1

/-- The six displayed orbits are pairwise disjoint. -/
theorem representative_orbits_pairwise_disjoint :
    pairwiseDisjointFinsets representativeOrbits = true :=
  orbit_census_audit.2.1

/-- The six orbits exhaust all normalized balanced tasks. -/
theorem six_orbits_cover_census :
    representativeOrbitUnion = normalizedBalancedTasks :=
  orbit_census_audit.2.2.1

/-- Exact reconstruction of the six three-bit rows in the paper. -/
theorem representative_rows_exact :
    representativeRows =
      [(3, 1, 1), (3, 2, 1), (1, 3, 2),
       (4, 3, 2), (12, 3, 2), (12, 2, 2)] :=
  orbit_census_audit.2.2.2.1

/--
Every member of each action-generated representative orbit has the same
ordinary and restricted-certificate depth as its representative.  Together
with `six_orbits_cover_census`, this is an exhaustive uniformity audit over
the normalized 35-task census.
-/
theorem representative_orbit_depths_uniform :
    representativeOrbitDepthUniformParts = representativeOrbits :=
  orbit_census_audit.2.2.2.2

/-! ## Boolean one-query weighted-distance criterion -/

/-- Rational weight assigned to each point-query address. -/
abbrev RationalWeights := Coord → ℚ

/-- A convenient constructor for concrete three-bit witnesses. -/
def bits (a b c : Bool) : Input := ![a, b, c]

/-- Weighted Hamming distance of two oracle instances. -/
def weightedDistance (w : RationalWeights) (x y : Input) : ℚ :=
  ∑ i : Coord, if x i = y i then 0 else w i

/-- Probe constraints: phase-sensitive weights are nonnegative and total at most 1. -/
def AdmissibleWeights (w : RationalWeights) : Prop :=
  (∀ i, 0 ≤ w i) ∧ (∑ i : Coord, w i) ≤ 1

/--
The one-query weighted-distance criterion for the standard Boolean XOR point
oracle, instantiated here over rational weights: every pair in different
answer cells must have weighted distance `1/2`.  Equivalence with unrestricted
real/complex probes is not proved in this module.
-/
def HasBooleanOneQueryWeights (f : ThreeTask) : Prop :=
  ∃ w : RationalWeights, AdmissibleWeights w ∧
    ∀ x y : Input, f x ≠ f y → weightedDistance w x y = (1 / 2 : ℚ)

/-- `x₁` satisfies the criterion with weight `(1/2,0,0)`. -/
theorem projection_has_one_query_weights : HasBooleanOneQueryWeights projection := by
  refine ⟨![1 / 2, 0, 0], ?_, ?_⟩
  · constructor
    · intro i
      fin_cases i <;> norm_num
    · norm_num [Fin.sum_univ_succ]
  · intro x y h
    simpa [weightedDistance, projection, Fin.sum_univ_succ] using h

/-- `x₁ xor x₂` satisfies the criterion with weights `(1/2,1/2,0)`. -/
theorem pairParity_has_one_query_weights : HasBooleanOneQueryWeights pairParity := by
  refine ⟨![1 / 2, 1 / 2, 0], ?_, ?_⟩
  · constructor
    · intro i
      fin_cases i <;> norm_num
    · norm_num [Fin.sum_univ_succ]
  · intro x y h
    cases hx0 : x 0 <;> cases hx1 : x 1 <;>
      cases hy0 : y 0 <;> cases hy1 : y 1 <;>
      simp_all [pairParity, weightedDistance, Fin.sum_univ_succ]

/-- Three-bit parity violates the one-query weighted-distance equations. -/
theorem parityThree_has_no_one_query_weights :
    ¬ HasBooleanOneQueryWeights parityThree := by
  rintro ⟨w, _hadm, hcross⟩
  have h0 := hcross (bits false false false) (bits true false false) (by decide)
  have h1 := hcross (bits false false false) (bits false true false) (by decide)
  have h2 := hcross (bits false false false) (bits false false true) (by decide)
  have h012 := hcross (bits false false false) (bits true true true) (by decide)
  norm_num [weightedDistance, bits, Fin.sum_univ_succ] at h0 h1 h2 h012
  linarith

/-- Three-bit majority violates the one-query weighted-distance equations. -/
theorem majorityThree_has_no_one_query_weights :
    ¬ HasBooleanOneQueryWeights majorityThree := by
  rintro ⟨w, _hadm, hcross⟩
  have h0 := hcross (bits false true false) (bits true true false) (by decide)
  have h1 := hcross (bits true false false) (bits true true false) (by decide)
  have h01 := hcross (bits false false false) (bits true true false) (by decide)
  norm_num [weightedDistance, bits, Fin.sum_univ_succ] at h0 h1 h01
  linarith

/-- `x₁ xor (x₂ x₃)` violates the one-query weighted-distance equations. -/
theorem xorAnd_has_no_one_query_weights : ¬ HasBooleanOneQueryWeights xorAnd := by
  rintro ⟨w, _hadm, hcross⟩
  have h0 := hcross (bits false false false) (bits true false false) (by decide)
  have h1 := hcross (bits false false true) (bits false true true) (by decide)
  have h01 := hcross (bits false false false) (bits true true false) (by decide)
  norm_num [weightedDistance, bits, Fin.sum_univ_succ] at h0 h1 h01
  linarith

/-- The selector violates the one-query weighted-distance equations. -/
theorem selector_has_no_one_query_weights : ¬ HasBooleanOneQueryWeights selector := by
  rintro ⟨w, _hadm, hcross⟩
  have h0 := hcross (bits false false true) (bits true false true) (by decide)
  have h1 := hcross (bits false false false) (bits false true false) (by decide)
  have h01 := hcross (bits false false true) (bits true true true) (by decide)
  norm_num [weightedDistance, bits, Fin.sum_univ_succ] at h0 h1 h01
  linarith

end AnswerPartitions.CensusThree
