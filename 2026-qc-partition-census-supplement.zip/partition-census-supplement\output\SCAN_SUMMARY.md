# Stored scan output

The principal stored outputs are the CSV files in `data/` and the witness
directories at the archive root.  Their headline classifications are:

## Three Boolean query addresses

All 35 balanced partitions are exact:

| `(D_exact,Q_exact)` | partitions |
|---|---:|
| `(1,1)` | 3 |
| `(2,1)` | 3 |
| `(2,2)` | 12 |
| `(3,2)` | 17 |

The exact speedup count is 20/35.

## Four Boolean query addresses

The exact subset contains 395 partitions:

| `(D_exact,Q_exact)` | exact partitions |
|---|---:|
| `(1,1)` | 4 |
| `(2,1)` | 6 |
| `(2,2)` | 48 |
| `(3,2)` | 248 |
| `(4,2)` | 89 |

The remaining 6,040 partitions have a three-query constructive upper bound.
Their two-query lower tests were numerically infeasible with SCS at the stored
requested tolerances; therefore their `(3,3)` and `(4,3)` counts are labelled
`numerical_candidate`, not exact theorems.

The `witness_file` fields in the archived CSVs are portable relative paths.
