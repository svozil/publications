import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Algebra.Order.BigOperators.Group.Finset
import Mathlib.Data.Real.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Order

/-!
# Boolean one-query weights and the parity obstruction

For a standard reversible Boolean point oracle, Fourier-diagonalizing the
response qubit reduces a one-query probe (including arbitrary reference
systems) to nonnegative address weights `pᵢ` with total at most one.  The
cross-cell output overlap for inputs `b,c` is

`1 - 2 * ∑_{i : bᵢ ≠ cᵢ} pᵢ`.

The paper's exact one-query criterion is recorded as
`BooleanOneQueryWeightCertificate`.  The analytic reduction from arbitrary
Hilbert-space probes to these weights is described in the findings report;
all deductions from the finite weight criterion below are fully checked.
-/

namespace AnswerPartitions

open scoped BigOperators

/-- Boolean strings queried pointwise. -/
abbrev BitString (n : ℕ) := Fin n → Bool

/-- Total probe weight on coordinates where two strings differ. -/
def differingWeight {n : ℕ} (p : Fin n → ℝ) (b c : BitString n) : ℝ :=
  ∑ i, if b i = c i then 0 else p i

/-- The standard one-query overlap after response-mode diagonalization. -/
def booleanPhaseOverlap {n : ℕ} (p : Fin n → ℝ) (b c : BitString n) : ℝ :=
  1 - 2 * differingWeight p b c

theorem booleanPhaseOverlap_eq_zero_iff {n : ℕ} (p : Fin n → ℝ)
    (b c : BitString n) :
    booleanPhaseOverlap p b c = 0 ↔ differingWeight p b c = 1 / 2 := by
  unfold booleanPhaseOverlap
  constructor <;> intro h <;> linarith

/-- Exact rational/real one-query feasibility criterion for a Boolean point
oracle and answer map `g`. -/
structure BooleanOneQueryWeightCertificate {n : ℕ} {J : Type*}
    (g : BitString n → J) where
  weight : Fin n → ℝ
  nonnegative : ∀ i, 0 ≤ weight i
  total_le_one : ∑ i, weight i ≤ 1
  cross_half : ∀ ⦃b c⦄, g b ≠ g c → differingWeight weight b c = 1 / 2

/-- Flip one queried coordinate. -/
def flipBit {n : ℕ} (b : BitString n) (i : Fin n) : BitString n :=
  fun j => if j = i then !b j else b j

/-- Coordinate `i` is essential when flipping only it can change the answer. -/
def EssentialCoordinate {n : ℕ} {J : Type*}
    (g : BitString n → J) (i : Fin n) : Prop :=
  ∃ b, g b ≠ g (flipBit b i)

theorem differingWeight_flipBit {n : ℕ} (p : Fin n → ℝ)
    (b : BitString n) (i : Fin n) :
    differingWeight p b (flipBit b i) = p i := by
  classical
  simp [differingWeight, flipBit]

/-- Every essential coordinate consumes weight `1/2`. -/
theorem essentialCoordinate_weight_eq_half {n : ℕ} {J : Type*}
    {g : BitString n → J} (cert : BooleanOneQueryWeightCertificate g)
    {i : Fin n} (hi : EssentialCoordinate g i) : cert.weight i = 1 / 2 := by
  obtain ⟨b, hb⟩ := hi
  simpa [differingWeight_flipBit] using cert.cross_half hb

/-- A one-query Boolean weight certificate can involve at most two essential
input coordinates.  This gives a compact lower-bound certificate for many
small total Boolean functions, independently of polynomial degree. -/
theorem oneQuery_essentialCoordinates_card_le_two {n : ℕ} {J : Type*}
    {g : BitString n → J} (cert : BooleanOneQueryWeightCertificate g)
    (s : Finset (Fin n)) (hs : ∀ i ∈ s, EssentialCoordinate g i) :
    s.card ≤ 2 := by
  have hsum_s : (∑ i ∈ s, cert.weight i) = (s.card : ℝ) / 2 := by
    calc
      (∑ i ∈ s, cert.weight i) = ∑ i ∈ s, (1 / 2 : ℝ) := by
        apply Finset.sum_congr rfl
        intro i hi
        exact essentialCoordinate_weight_eq_half cert (hs i hi)
      _ = (s.card : ℝ) / 2 := by simp [div_eq_mul_inv]
  have hsub : (∑ i ∈ s, cert.weight i) ≤ ∑ i, cert.weight i :=
    Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ s)
      (fun i _ _ => cert.nonnegative i)
  have hreal : (s.card : ℝ) ≤ 2 := by
    rw [hsum_s] at hsub
    linarith [cert.total_le_one]
  exact_mod_cast hreal

/-- The all-zero string. -/
def zeroBits (n : ℕ) : BitString n :=
  fun _ => false

/-- The string supported on one coordinate. -/
def unitBit {n : ℕ} (i : Fin n) : BitString n :=
  fun j => decide (j = i)

@[simp] theorem unitBit_same {n : ℕ} (i : Fin n) : unitBit i i = true := by
  simp [unitBit]

@[simp] theorem unitBit_ne {n : ℕ} (i j : Fin n) (h : j ≠ i) :
    unitBit i j = false := by
  simp [unitBit, h]

/-- Parity as a value in the field `𝔽₂`. -/
def parityAnswer {n : ℕ} (b : BitString n) : ZMod 2 :=
  ∑ i, if b i then 1 else 0

@[simp] theorem parityAnswer_zeroBits (n : ℕ) : parityAnswer (zeroBits n) = 0 := by
  simp [parityAnswer, zeroBits]

@[simp] theorem parityAnswer_unitBit {n : ℕ} (i : Fin n) :
    parityAnswer (unitBit i) = 1 := by
  classical
  simp [parityAnswer, unitBit]

/-- Only coordinate `i` differs between `0ⁿ` and `eᵢ`. -/
theorem differingWeight_zero_unit {n : ℕ} (p : Fin n → ℝ) (i : Fin n) :
    differingWeight p (zeroBits n) (unitBit i) = p i := by
  classical
  simp [differingWeight, zeroBits, unitBit]

/-- The overlap equations for `0ⁿ` versus every odd unit vector force every
address weight to be exactly one half. -/
theorem parity_certificate_weight_eq_half {n : ℕ}
    (cert : BooleanOneQueryWeightCertificate (@parityAnswer n)) (i : Fin n) :
    cert.weight i = 1 / 2 := by
  have hanswer : parityAnswer (zeroBits n) ≠ parityAnswer (unitBit i) := by
    norm_num
  simpa [differingWeight_zero_unit] using
    cert.cross_half hanswer

/-- Paper, Eq. (parity-overlap): exact one-query parity is possible only for
at most two queried bits. -/
theorem parity_oneQuery_weightCriterion_implies_le_two {n : ℕ}
    (cert : BooleanOneQueryWeightCertificate (@parityAnswer n)) : n ≤ 2 := by
  have hsum : (∑ i, cert.weight i) = (n : ℝ) / 2 := by
    simp_rw [parity_certificate_weight_eq_half cert]
    simp [div_eq_mul_inv]
  have hnreal : (n : ℝ) ≤ 2 := by
    have hle := cert.total_le_one
    rw [hsum] at hle
    linarith
  exact_mod_cast hnreal

/-- Hence a weight certificate for three-bit parity is impossible. -/
theorem parity_three_no_oneQuery_weightCertificate :
    ¬ Nonempty (BooleanOneQueryWeightCertificate (@parityAnswer 3)) := by
  rintro ⟨cert⟩
  have := parity_oneQuery_weightCriterion_implies_le_two cert
  omega

end AnswerPartitions
