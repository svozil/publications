import AnswerPartitions.Deutsch
import Mathlib.Analysis.InnerProductSpace.ProdL2

/-!
# Controlled response oracles for Deutsch's problem

This module supplies the constructive (sufficiency) half of the response-spectrum
argument.  The response space may be any complex inner-product space.  The two
address sectors are represented by the Hilbertian `L²` product
`WithLp 2 (H × H)`.

It also isolates the equality case used in the necessity argument: a linear
isometry whose expectation at `x` is the negative of the norm square must send
`x` to `-x`.
-/

namespace AnswerPartitions

open scoped ComplexConjugate

universe u

variable {H : Type u} [NormedAddCommGroup H] [InnerProductSpace ℂ H]

private theorem inner_smul_both_eq_zero
    (c : ℂ) {x y : H} (h : inner ℂ x y = 0) :
    inner ℂ (c • x) (c • y) = 0 := by
  rw [inner_smul_left, inner_smul_right, h]
  simp

/-! ## Equality in the unitary expectation bound -/

/-- Equality at the negative endpoint of the isometry expectation bound forces
the vector to be a `-1` eigenvector.  Surjectivity is not needed. -/
theorem LinearIsometry.map_eq_neg_of_inner_eq_neg_self
    (U : H →ₗᵢ[ℂ] H) (x : H)
    (h : inner ℂ x (U x) = -inner ℂ x x) :
    U x = -x := by
  have hsq : ‖x + U x‖ ^ 2 = 0 := by
    rw [norm_add_sq (𝕜 := ℂ), U.norm_map, h]
    simp only [map_neg]
    rw [← norm_sq_eq_re_inner (𝕜 := ℂ) x]
    ring
  have hnorm : ‖x + U x‖ = 0 := by
    nlinarith [norm_nonneg (x + U x)]
  have hzero : x + U x = 0 := norm_eq_zero.mp hnorm
  exact eq_neg_of_add_eq_zero_right hzero

/-! ## The two address blocks and their controlled action -/

/-- Two response-space blocks, one for each Deutsch address.  `WithLp 2`
equips the underlying pair `H × H` with its Hilbert-space norm. -/
abbrev TwoAddressBlocks (H : Type u) := WithLp 2 (H × H)

/-- Apply the response isometry when the Boolean control is true, and do
nothing when it is false. -/
def booleanResponse (V : H →ₗᵢ[ℂ] H) (b : Bool) (x : H) : H :=
  if b then V x else x

/-- The controlled-response oracle
`|i⟩ |φᵢ⟩ ↦ |i⟩ V^(bᵢ) |φᵢ⟩`, written in its two address blocks. -/
def controlledResponse (V : H →ₗᵢ[ℂ] H) (b : DeutschTable)
    (ψ : TwoAddressBlocks H) : TwoAddressBlocks H :=
  WithLp.toLp 2
    (booleanResponse V b.1 (WithLp.ofLp ψ).1,
      booleanResponse V b.2 (WithLp.ofLp ψ).2)

@[simp] theorem controlledResponse_fst
    (V : H →ₗᵢ[ℂ] H) (b : DeutschTable) (ψ : TwoAddressBlocks H) :
    (WithLp.ofLp (controlledResponse V b ψ)).1 =
      booleanResponse V b.1 (WithLp.ofLp ψ).1 :=
  rfl

@[simp] theorem controlledResponse_snd
    (V : H →ₗᵢ[ℂ] H) (b : DeutschTable) (ψ : TwoAddressBlocks H) :
    (WithLp.ofLp (controlledResponse V b ψ)).2 =
      booleanResponse V b.2 (WithLp.ofLp ψ).2 :=
  rfl

/-- The controlled-response action is homogeneous in the probe. -/
@[simp] theorem controlledResponse_smul
    (V : H →ₗᵢ[ℂ] H) (b : DeutschTable) (c : ℂ)
    (ψ : TwoAddressBlocks H) :
    controlledResponse V b (c • ψ) = c • controlledResponse V b ψ := by
  rcases b with ⟨b₀, b₁⟩
  cases b₀ <;> cases b₁ <;>
    apply WithLp.ofLp_injective <;>
    ext <;> simp [controlledResponse, booleanResponse]

/-- The unnormalized equal superposition of the two address blocks with a
common response vector. -/
def equalAddressProbe (x : H) : TwoAddressBlocks H :=
  WithLp.toLp 2 (x, x)

/-- A `-1` response eigenvector turns the controlled response into the usual
Deutsch signs on the two address blocks. -/
theorem controlledResponse_equalAddressProbe_of_map_eq_neg
    (V : H →ₗᵢ[ℂ] H) (x : H) (hx : V x = -x) (b : DeutschTable) :
    controlledResponse V b (equalAddressProbe x) =
      WithLp.toLp 2 (phaseSign b.1 • x, phaseSign b.2 • x) := by
  rcases b with ⟨b₀, b₁⟩
  cases b₀ <;> cases b₁ <;>
    apply WithLp.ofLp_injective <;>
    ext <;> simp [controlledResponse, equalAddressProbe, booleanResponse,
      phaseSign, hx]

/-- A common `-1` response eigenvector makes all constant--balanced output
Gram entries vanish.  The vector need not yet be normalized. -/
theorem controlledResponse_blockOrthogonal_of_map_eq_neg
    (V : H →ₗᵢ[ℂ] H) (x : H) (hx : V x = -x) :
    BlockOrthogonal deutschAnswer
      (fun b => controlledResponse V b (equalAddressProbe x)) := by
  rintro ⟨b₀, b₁⟩ ⟨c₀, c₁⟩ hbc
  cases b₀ <;> cases b₁ <;> cases c₀ <;> cases c₁ <;>
    simp_all [gram, deutschAnswer,
      controlledResponse_equalAddressProbe_of_map_eq_neg,
      WithLp.prod_inner_apply, phaseSign]

/-- A nonzero `-1` eigenvector supplies a normalized one-query probe resolving
the Deutsch constant--balanced partition. -/
theorem controlledResponse_pureOneQueryResolves_of_negOneEigenvector
    (V : H →ₗᵢ[ℂ] H) (x : H) (hx : x ≠ 0) (hVx : V x = -x) :
    PureOneQueryResolves deutschAnswer (controlledResponse V) := by
  let q : TwoAddressBlocks H := equalAddressProbe x
  have hq : q ≠ 0 := by
    intro hq0
    apply hx
    have hfst := congrArg (fun y : TwoAddressBlocks H => (WithLp.ofLp y).1) hq0
    simpa [q, equalAddressProbe] using hfst
  let probe : TwoAddressBlocks H := (‖q‖⁻¹ : ℂ) • q
  refine ⟨probe, ?_, ?_⟩
  · exact norm_smul_inv_norm hq
  · intro b c hbc
    have hblock := controlledResponse_blockOrthogonal_of_map_eq_neg V x hVx hbc
    change inner ℂ (controlledResponse V b (equalAddressProbe x))
      (controlledResponse V c (equalAddressProbe x)) = 0 at hblock
    change inner ℂ (controlledResponse V b probe)
      (controlledResponse V c probe) = 0
    dsimp [probe, q]
    rw [controlledResponse_smul, controlledResponse_smul]
    exact inner_smul_both_eq_zero (H := TwoAddressBlocks H)
      (‖equalAddressProbe x‖⁻¹ : ℂ) hblock

end AnswerPartitions
