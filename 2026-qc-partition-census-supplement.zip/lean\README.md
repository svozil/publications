# Lean companion formalization

This directory contains the Lean 4 companion to *Answer Partitions and Oracle
Access Determine Quantum Query Complexity*. It is self-contained apart from
its pinned mathlib dependency.

## Build

The project was checked with Lean `4.30.0` and mathlib `v4.30.0`.

```powershell
lake update
lake build
```

`lake update` obtains the pinned mathlib release and writes the local package
manifest. The archive deliberately omits build products, dependency caches,
and the machine-specific offline build file used during the original audit.

## Checked scope

The ordinary kernel-checked modules formalize answer fibers, pure-state
block discrimination, the Deutsch Gram pattern, controlled-response
sufficiency, the cyclic-shift `-1` eigenvalue criterion, Boolean one-query
weight obstructions, four-bit mask/task equivalences, and finite
Bernstein--Vazirani combinatorics.

Executable census theorems additionally check:

- all 35 normalized balanced three-bit tasks, with deterministic-depth
  histogram `(1: 3, 2: 15, 3: 17)`, certificate-depth histogram
  `(1: 6, 2: 29)`, and 20 strict certificate advantages;
- all 6,435 normalized balanced four-bit tasks, with deterministic-depth
  histogram `(1: 4, 2: 54, 3: 1784, 4: 4593)` and restricted
  bit/pair-parity certificate-depth histogram
  `(1: 10, 2: 385, 3: 6040)`;
- the exact certificate-model rows `(D,C)=(1,1):4`, `(2,1):6`,
  `(2,2):48`, `(3,2):248`, and `(4,2):89` for the 395 low-depth cases.

Here `C` is the encoded certificate depth, not a separately formalized
unrestricted quantum-query complexity.

The finite audits are `depth_census_audit`, `orbit_census_audit`, and
`CensusFourExact.census_audit`. They use `native_decide`, so they trust Lean's
compiler/native evaluator in addition to the kernel. The source contains no
handwritten `sorry`, `admit`, or project-declared axiom.

## Interpretation boundary

The certificate evaluator permits a single bit query or pair-parity query at
each node. The project proves the finite search and one-query weight
obstructions for that model, but does not yet define general quantum-query
semantics or prove the bridge from these executable certificates to
unrestricted `Q_E`. Pair parity as one Deutsch query and coherent composition
therefore remain paper-level mathematical arguments.

The 43 four-bit orbit representatives covering 6,040 tasks rely on numerical
two-query SDP infeasibility in the Python study. Lean records their restricted
certificate depth but deliberately proves no unrestricted quantum lower bound
for them. Full coverage and suggested next proof work are in `FINDINGS.md`.
