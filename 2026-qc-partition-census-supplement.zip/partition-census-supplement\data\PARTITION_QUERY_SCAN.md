# Balanced-partition query scan

`partition_query_scan.py` enumerates balanced binary decision partitions of a
finite oracle-instance set and compares deterministic exact classical query
depth with exact or candidate exact quantum query counts under one specified
reversible oracle interface.

## Oracle and decision model

An oracle family is a matrix `f[a,x]`.  Row `a` is a possible oracle
instance, column `x` is a query address, and the response is an element of
`Z_d`.  The quantum oracle is

```text
O_a |x,y> = |x, y + f[a,x] (mod d)>.
```

For an even number `n=2k` of rows, the program considers unlabeled balanced
two-cell partitions.  Their number is

```text
binomial(2k,k)/2.
```

The program fixes row zero in the first cell, thereby counting a partition
and the partition obtained by exchanging its cells only once.

For every analyzed partition it reports:

- `D_exact`, the optimal worst-case depth of a deterministic adaptive
  classical value-query tree;
- `Q_exact_candidate`, the smallest quantum query count established or
  suggested by the available exact constructions and Gram-matrix SDP tests;
- `Q_lower_bound`, the next query count not excluded by the completed lower
  search;
- `Q_constructive_upper_bound`, the depth of the best stored classical or
  value/pair-parity construction, including when a capped search stops before
  determining the minimum;
- `certification`, which states whether the reported quantum count is exact,
  a numerical candidate, or unresolved; and
- the corresponding candidate factor `D_exact/Q_exact_candidate`.

The word *candidate* is important.  A feasible floating-point SDP is strong
numerical evidence for an upper bound, but it is not by itself a formal exact
certificate.  A reported quantum count is certified as exact only when an
exact construction attains that count and every smaller query count has been
excluded exactly.  If any required exclusion is based only on floating-point
infeasibility, the result remains a numerical candidate.

## Gram-matrix SDP

The response register is Fourier diagonalized internally.  If `q=(x,s)` is a
query address and nontrivial response Fourier mode, define

```text
v_q(a) = exp(2*pi*i*s*f[a,x]/d),
Delta_q(a,b) = conjugate(v_q(a))*v_q(b).
```

An additional idle mode is included.  For `T` queries the SDP uses positive
semidefinite matrices `M[t,q]` and imposes

```text
sum_q M[0,q] = J,
sum_q M[t+1,q] = sum_q Delta_q .* M[t,q],
G_final = sum_q Delta_q .* M[T-1,q],
G_final[a,b] = 0 whenever a and b lie in different answer cells.
```

The final condition says exactly that output states belonging to different
answers have orthogonal spans.  The idle mode permits unused query amplitude
and makes feasibility monotone in `T`.

This is the Gram-evolution formulation of Barnum, Saks, and Szegedy,
*Quantum query complexity and semi-definite programming*, Proceedings of the
18th IEEE Conference on Computational Complexity (2003), pp. 179--193,
<https://doi.org/10.1109/CCC.2003.1214419>, specialized to a cyclic-addition
response oracle.

For a Boolean response (`d=2`) and `T=1`, feasibility reduces to a rational
linear problem.  The program solves it with `fractions.Fraction`; both a
feasible solution and infeasibility are therefore exact rather than
floating-point classifications.

## Exact constructive upper certificates

The ordinary optimal classical decision tree is also a constructive quantum
upper bound, because a quantum protocol can make the same basis-state value
queries.

There is a stronger exact upper certificate when every table entry is `0` or
`1` and the response alphabet has even size.  The cyclic response shift then
has the order-two Fourier character `s=d/2`.  Preparing that response mode
allows one Deutsch query to determine

```text
f[a,x_i] xor f[a,x_j]
```

for any two addresses.  The program computes an optimal adaptive decision
tree whose tests are either one-bit values or two-bit parities.  Each node
costs one oracle call, so the resulting tree is an exact quantum upper-bound
certificate.  Intermediate measurements can equivalently be deferred.

This certificate proves `Q <= T`; it does not by itself prove `Q = T`.
Equality is reported as exact only if all query counts below `T` are excluded
exactly.  If, for example, a smaller count is excluded only by a numerical
SDP status, the tree still supplies an exact upper bound but the displayed
minimum remains a numerical candidate.

For an odd response alphabet there is no order-two Fourier character, so the
pair-parity construction is not used.

## Orbit reduction for Boolean cubes

With `--boolean-inputs M`, the instances are all strings in `{0,1}^M`.  The
option

```text
--orbit-reduce
```

analyzes one representative from each orbit under:

- permutations of the `M` query coordinates;
- independent complementation of any query coordinate; and
- exchange of the two unlabeled answer cells.

These are oracle-preserving transformations: they only relabel query
addresses and apply known response relabelings.  General linear mixtures of
coordinates are not used, because they would turn one coordinate query into
a parity query and need not preserve query cost.

Orbit reduction is available only with `--boolean-inputs`; it is rejected for
a table loaded through `--table`.  It is also incompatible with `--sample`.
Sampling partitions and then identifying their orbits would bias the sample
toward large orbits, whereas uniformly sampling orbit representatives would
answer a different statistical question.

Known enumeration checks are:

| Boolean addresses | Instances | Balanced partitions | Orbit representatives |
|---:|---:|---:|---:|
| 3 | 8 | 35 | 6 |
| 4 | 16 | 6,435 | 58 |

In orbit mode each CSV row represents one orbit and includes its
`orbit_size`.  Summaries distinguish the number of representatives actually
analyzed from the orbit-weighted number of partitions covered.  Thus the six
three-address rows cover all 35 balanced partitions, and the 58 four-address
rows cover all 6,435.

Orbit reduction still has to enumerate the unreduced partition population in
order to form its orbits.  The large-enumeration guard therefore applies to
the full balanced-partition count, not merely to the number of representatives.

## Solver provenance and witnesses

The CSV keeps computational conclusions separate from raw solver output:

- `quantum_status` is a human-readable explanation of the query-count result;
- `solver` names the selected exact or numerical backend;
- `solver_status` preserves the raw backend status, such as `optimal`,
  `optimal_inaccurate`, `infeasible`, or an exact rational-LP status;
- `certification` records whether the conclusion is `exact`, a
  `numerical_candidate`, or unresolved; and
- `max_residual` is the largest audited primal violation for a returned SDP
  witness.  It is empty when no primal witness was returned.

The raw solver status must not be read as a mathematical certificate.
In particular, floating-point `infeasible` is a numerical lower-bound result,
and an audited `optimal` or `optimal_inaccurate` solution remains numerical
unless it is subsequently converted into an exact certificate.

Use

```text
--witness-dir PATH
```

to retain constructive witnesses.  Exact Boolean one-query results store
rational Fourier-mode weights; pair-parity upper bounds store the complete
value/parity decision tree; and feasible numerical SDPs store their audited
Gram-decomposition matrices together with mode names, solver metadata,
status, tolerance, and residual.  Witness files are associated with the CSV
row representing the partition or orbit.  In orbit-reduced scans the witness
is stored only for the canonical representative; the reported `orbit_size`
states how many equivalent partitions it covers.

## Installation

Use Python 3.10 or later:

```powershell
python -m pip install -r requirements-partition-scan.txt
```

## Examples

### Deutsch benchmark

Analyze all three balanced partitions of the four Boolean truth tables:

```powershell
python partition_query_scan.py --boolean-inputs 2 --show-all
```

The expected exact result is:

- two coordinate partitions with `(D_exact,Q_exact)=(1,1)`;
- the constant-versus-balanced partition with `(2,1)`.

Store its exact construction witnesses and CSV output:

```powershell
python partition_query_scan.py --boolean-inputs 2 --show-all `
  --csv results-deutsch.csv --witness-dir witnesses-deutsch
```

Compare the same classical Boolean table with qutrit and four-level cyclic
responses:

```powershell
python partition_query_scan.py --table examples/deutsch_truth_tables.csv `
  --alphabet-size 3 --show-all --csv results-deutsch-d3.csv

python partition_query_scan.py --table examples/deutsch_truth_tables.csv `
  --alphabet-size 4 --show-all --csv results-deutsch-d4.csv `
  --witness-dir witnesses-deutsch-d4
```

The qutrit run numerically places the Deutsch partition at `(D,Q)=(2,2)`
unless one-query impossibility is supplied by a separate exact argument.  For
`d=4`, the exact pair-parity construction attains one query; because a
nontrivial decision needs at least one query, this gives `(2,1)` exactly.

### Complete orbit-reduced Boolean scans

Analyze the six representatives covering all 35 balanced partitions for
three query addresses:

```powershell
python partition_query_scan.py --boolean-inputs 3 --orbit-reduce `
  --show-all --csv results-m3-orbits.csv --witness-dir witnesses-m3
```

Analyze the 58 representatives covering all 6,435 balanced partitions for
four query addresses:

```powershell
python partition_query_scan.py --boolean-inputs 4 --orbit-reduce `
  --csv results-m4-orbits.csv --witness-dir witnesses-m4
```

The checked three- and four-address histograms, their certification levels,
and a manuscript-ready interpretation are recorded in
`SCAN_FINDINGS_FOR_MANUSCRIPT.md`.

For a faster one-query screen, cap the lower-bound search:

```powershell
python partition_query_scan.py --boolean-inputs 4 --orbit-reduce `
  --max-quantum-queries 1 --csv results-m4-one-query.csv
```

Rows not settled within the cap are marked unresolved rather than counted as
negative cases.

### Uniform sampling

For larger Boolean cubes, sample partitions without orbit reduction:

```powershell
python partition_query_scan.py --boolean-inputs 5 --sample 500 --seed 17 `
  --max-quantum-queries 1 --csv sample-m5.csv
```

When every sampled row is classified, the summary reports a 95% Wilson
interval for the fraction of partitions showing a candidate exact quantum
advantage.  If any rows are unresolved, it reports bounds instead.  Do not
combine this command with `--orbit-reduce`.

## Custom oracle tables

A CSV row may contain only values,

```csv
0,0
0,1
1,0
1,1
```

or an instance name followed by its values:

```csv
f00,0,0
f01,0,1
f10,1,0
f11,1,1
```

JSON may be a matrix or use named instances:

```json
{
  "alphabet_size": 2,
  "instances": [
    {"name": "f00", "values": [0, 0]},
    {"name": "f01", "values": [0, 1]},
    {"name": "f10", "values": [1, 0]},
    {"name": "f11", "values": [1, 1]}
  ]
}
```

Orbit reduction is intentionally unavailable for custom tables because no
automorphism group is inferred from their contents.

## Scaling and interpretation

The number of unlabeled balanced partitions is 3 for `n=4`, 35 for `n=8`,
6,435 for `n=16`, and 300,540,195 for `n=32`.  SDP size also grows with the
number of instances, response modes, and tested query count.  Orbit reduction
substantially lowers the number of SDPs for the built-in three- and four-
address Boolean cubes, but it does not make the 300-million-partition
five-address enumeration inexpensive.

The scan concerns exact, zero-error query complexity.  It does not include
gate cost, oracle-construction cost, bounded-error algorithms, or asymptotic
complexity.  Numerical SDP results are evidence, not formal proofs.  Important
cases should be checked with independent solvers and, where an exact claim is
needed, converted into symbolic algorithms or exact primal/dual certificates.
