"""Round numerical dual solutions to exact rational certificates and verify them.
A certificate (Y1,Y2,Y3,lambda) with all entries integers over 2^PREC proves
   optimal worst-case 2-query success <= 1^T Y1 1  (< 1  =>  Q_E >= 3)."""
import sys, json, numpy as np
from fractions import Fraction
sys.path.insert(0,'.')
from sdp_dual2 import build
PREC=40; EPS_SHIFT=2**-20
def to_int_matrix(Y): return [[int(round(v*2**PREC)) for v in row] for row in Y]
def certify(rep,y,N=4):
    M=2**N; f=[1 if x in rep else 0 for x in range(M)]
    P=build(f,N); K=P['K']; E=P['E']
    Y1=np.tensordot(y[:K],E,1); Y2=np.tensordot(y[K:2*K],E,1); Y3=np.tensordot(y[2*K:3*K],E,1)
    lam=np.array(y[3*K:])
    I=np.eye(M)
    Y3=Y3+EPS_SHIFT*I; Y2=Y2+2*EPS_SHIFT*I; Y1=Y1+3*EPS_SHIFT*I
    Y1i,Y2i,Y3i=to_int_matrix((Y1+Y1.T)/2),to_int_matrix((Y2+Y2.T)/2),to_int_matrix((Y3+Y3.T)/2)
    li=[int(round(v*2**PREC)) for v in lam[:-1]]; li.append(2**PREC-sum(li))
    return dict(N=N,rep=list(rep),f=f,prec=PREC,Y1=Y1i,Y2=Y2i,Y3=Y3i,lam=li)
