import numpy as np
def sym_basis(n):
    idx=[(p,q) for p in range(n) for q in range(p,n)]
    E=np.zeros((len(idx),n,n))
    for k,(p,q) in enumerate(idx):
        E[k,p,q]=1; E[k,q,p]=1
    return E,idx
def build(fvals,N):
    M=2**N
    s=np.array([[(-1)**((b>>i)&1) for b in range(M)] for i in range(N)],float)
    Ds=[np.ones(M)]+[s[i] for i in range(N)]
    E,idx=sym_basis(M); K=len(E); m=3*K+M
    blocks=[]  # (vars index array, A_sub (len(vars),M,M))
    r1=np.arange(0,K); r2=np.arange(K,2*K); r3=np.arange(2*K,3*K); rl=np.arange(3*K,3*K+M)
    for d in Ds:
        DD=np.outer(d,d)
        blocks.append((np.concatenate([r1,r2]),np.concatenate([E,-E*DD[None]])))
    for d in Ds:
        DD=np.outer(d,d)
        blocks.append((np.concatenate([r2,r3]),np.concatenate([E,-E*DD[None]])))
    for j in (0,1):
        L=np.zeros((M,M,M))
        sel=[b for b in range(M) if fvals[b]==j]
        for b in sel: L[b,b,b]=-1
        blocks.append((np.concatenate([r3,rl[sel]]),np.concatenate([E,L[sel]])))
    ones=np.ones(M); c=np.zeros(m); c[:K]=[ones@E[k]@ones for k in range(K)]
    Aeq=np.zeros(m); Aeq[3*K:]=1
    return dict(blocks=blocks,c=c,Aeq=Aeq,K=K,M=M,m=m,E=E,idx=idx,Ds=Ds)
def init(P):
    K,M=P['K'],P['M']; E,idx=P['E'],P['idx']
    def vv(Y): return np.array([Y[p,q]/2 if p==q else Y[p,q] for p,q in idx])
    return np.concatenate([vv(4*np.eye(M)),vv(3*np.eye(M)),vv(2*np.eye(M)),np.ones(M)/M])
def Smat(y,blk): v,A=blk; return np.tensordot(y[v],A,1)
def solve(fvals,N,mu_final=1e-8,stop_obj=None,verbose=False):
    P=build(fvals,N); M,K,m=P['M'],P['K'],P['m']; c=P['c']; Aeq=P['Aeq']
    blocks=[(v,A,A.reshape(len(v),-1)) for v,A in P['blocks']]
    y=init(P)
    def feas(y):
        if np.any(y[3*K:]<=0): return False
        for v,A,_ in blocks:
            try: np.linalg.cholesky(np.tensordot(y[v],A,1))
            except np.linalg.LinAlgError: return False
        return True
    def phi(y,mu):
        val=c@y/mu-np.sum(np.log(y[3*K:]))
        for v,A,_ in blocks: val-=np.linalg.slogdet(np.tensordot(y[v],A,1))[1]
        return val
    mu=1.0
    while True:
        for it in range(100):
            g=c/mu; H=np.zeros((m,m)); lam=y[3*K:]
            g[3*K:]-=1/lam; H[3*K:,3*K:]+=np.diag(1/lam**2)
            for v,A,Af in blocks:
                S=np.tensordot(y[v],A,1); W=np.linalg.inv(S); W=(W+W.T)/2
                g[v]-=Af@W.ravel()
                B=Af@np.kron(W,W)
                H[np.ix_(v,v)]+=B@Af.T
            KKT=np.zeros((m+1,m+1)); KKT[:m,:m]=H; KKT[:m,m]=Aeq; KKT[m,:m]=Aeq
            d=np.linalg.solve(KKT,np.concatenate([-g,[0.0]]))[:m]
            dec=-g@d
            if dec/2<1e-9: break
            t=1.0; f0=phi(y,mu)
            while t>1e-14:
                yn=y+t*d
                if feas(yn) and phi(yn,mu)<=f0-0.25*t*dec: break
                t*=0.5
            y=yn
        obj=c@y
        if verbose: print(f"  mu={mu:.1e} obj={obj:.9f}",flush=True)
        if stop_obj is not None and obj<stop_obj: break
        if mu<mu_final: break
        mu*=0.2
    return y,P,obj
