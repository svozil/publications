"""Map the 43 dual certificates onto the archive's own orbit representatives
(partition numbers, index convention int(name,2)) and re-verify exactly."""
import json, csv, itertools, sys
sys.path.insert(0, sys.argv[1])            # dir with verify_cert.py
from verify_cert import check
arch=sys.argv[2]; out=sys.argv[3]
certs=json.load(open(sys.argv[4]))
N=4; M=16; full=frozenset(range(M))
perms=list(itertools.permutations(range(N)))
def act(x,pi,c):
    y=0
    for i in range(N):
        if (x>>i)&1: y|=1<<pi[i]
    return y^c
def canon(S):
    best=None
    for pi in perms:
        for c in range(M):
            T=frozenset(act(x,pi,c) for x in S); U=full-T
            k=min(tuple(sorted(T)),tuple(sorted(U)))
            if best is None or k<best: best=k
    return best
bykey={tuple(c['rep']):c for c in certs}
rows=list(csv.DictReader(open(f'{arch}/data/results-m4-orbits.csv')))
newcerts=[]
for r in rows:
    if r['certification']!='numerical_candidate': continue
    w=json.load(open(f"{arch}/{r['witness_file']}"))
    Z=frozenset(w['cell_zero_indices']); labels=w['labels']
    assert all((labels[k]==0)==(k in Z) for k in range(M))
    c=bykey[canon(Z)]; R=frozenset(c['rep'])
    sigma=None
    for pi in perms:
        for cc in range(M):
            img=frozenset(act(x,pi,cc) for x in R)
            if img==Z or img==full-Z: sigma=[act(x,pi,cc) for x in range(M)]; break
        if sigma: break
    assert sigma
    def tr(Y):
        Z2=[[0]*M for _ in range(M)]
        for p in range(M):
            for q in range(M): Z2[sigma[p]][sigma[q]]=Y[p][q]
        return Z2
    lam=[0]*M
    for p in range(M): lam[sigma[p]]=c['lam'][p]
    nc=dict(schema='dual-certificate-v1', partition_number=int(r['partition']),
            canonical_mask=r['canonical_mask'], orbit_size=int(r['orbit_size']),
            D_exact=int(r['D_exact']), cell_zero_names=w['cell_zero_names'],
            N=N, f=labels, prec=c['prec'], Y1=tr(c['Y1']), Y2=tr(c['Y2']), Y3=tr(c['Y3']), lam=lam)
    b=check(nc); assert b is not None and b<1, r['partition']
    nc['two_query_success_upper_bound']=f"{b.numerator}/{b.denominator}"
    nc['two_query_success_upper_bound_decimal']=float(b)
    newcerts.append(nc)
json.dump(newcerts,open(out,'w'))
print(len(newcerts),"certificates mapped and re-verified; bounds",
      min(c['two_query_success_upper_bound_decimal'] for c in newcerts),
      max(c['two_query_success_upper_bound_decimal'] for c in newcerts))
