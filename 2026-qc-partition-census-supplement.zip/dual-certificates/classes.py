import itertools, functools, collections, json
N=4; pts=list(range(16)); full=frozenset(pts)
perms=list(itertools.permutations(range(N)))
bit=lambda x,i:(x>>i)&1
def act(x,pi,c):
    y=0
    for i in range(N):
        if bit(x,i): y|=1<<pi[i]
    return y^c
def canon(S):
    best=None
    for pi in perms:
        for c in range(16):
            T=frozenset(act(x,pi,c) for x in S); U=full-T
            k=min(tuple(sorted(T)),tuple(sorted(U)))
            if best is None or k<best: best=k
    return best
orb=collections.Counter()
for S in itertools.combinations(pts,8):
    if 0 not in S: continue
    orb[canon(frozenset(S))]+=1
def fvals(rep): return {x:(1 if x in rep else 0) for x in pts}
def Dd(f):
    @functools.lru_cache(None)
    def d(mask,val):
        if len({f[x] for x in pts if (x&mask)==val})<=1: return 0
        return min(1+max(d(mask|1<<i,val),d(mask|1<<i,val|1<<i)) for i in range(N) if not mask>>i&1)
    return d(0,0)
lin=[1<<i for i in range(N)]+[(1<<i)|(1<<j) for i in range(N) for j in range(i+1,N)]
par=lambda x,m: bin(x&m).count('1')&1
def Pd(f):
    @functools.lru_cache(None)
    def d(A):
        if len({f[x] for x in A})<=1: return 0
        best=99
        for m in lin:
            A0=frozenset(x for x in A if par(x,m)==0); A1=A-A0
            if A0 and A1: best=min(best,1+max(d(A0),d(A1)))
        return best
    return d(frozenset(pts))
info={}
for r in orb:
    f=fvals(r); info[r]=(Dd(f),Pd(f))
cls=collections.defaultdict(lambda:[0,0])
for r,s in orb.items():
    cls[info[r]][0]+=1; cls[info[r]][1]+=s
for k in sorted(cls): print("(D,2-parity depth)",k,"orbits",cls[k][0],"partitions",cls[k][1])
# candidate formulas b1..b4 = bits 0..3
cands={
 'b1':lambda b:b[0],'b1^b2':lambda b:b[0]^b[1],'Sel(b1,b2,b3)':lambda b:b[1] if b[0]==0 else b[2],
 'Maj(b1,b2,b3)':lambda b:int(b[0]+b[1]+b[2]>=2),'b1^b2b3':lambda b:b[0]^(b[1]&b[2]),
 'Par4':lambda b:b[0]^b[1]^b[2]^b[3],'b1^b2^b3b4':lambda b:b[0]^b[1]^(b[2]&b[3]),
 'b1^Maj(b2,b3,b4)':lambda b:b[0]^int(b[1]+b[2]+b[3]>=2),'b1^b2b3b4':lambda b:b[0]^(b[1]&b[2]&b[3]),
 'Sel(b1,b2,b3^b4)':lambda b:b[1] if b[0]==0 else b[2]^b[3],'Sel(b1,b2^b3,b2^b4)':lambda b:(b[1]^b[2]) if b[0]==0 else (b[1]^b[3]),
 'b1^Sel(b2,b3,b4)':lambda b:b[0]^(b[2] if b[1]==0 else b[3]),'Sel(b1,b2,b3)^b4':lambda b:(b[1] if b[0]==0 else b[2])^b[3],
 'b1^b2^b3b4 ':lambda b:b[0]^b[1]^(b[2]&b[3]),'b1b2^b3b4^b1':lambda b:(b[0]&b[1])^(b[2]&b[3])^b[0],
 'Maj(b1,b2,b3)^b4':lambda b:int(b[0]+b[1]+b[2]>=2)^b[3],'b1^b2b3^b3b4':lambda b:b[0]^(b[1]&b[2])^(b[2]&b[3]),
 'b1^b2b3^b2b4^b3b4':lambda b:b[0]^(b[1]&b[2])^(b[1]&b[3])^(b[2]&b[3]),
 'Sel(b1,Maj... )':lambda b:(b[1]&b[2]) if b[0]==0 else (b[1]|b[2]),
 'Sel(b1,b2b3,b2|b4)':lambda b:(b[1]&b[2]) if b[0]==0 else (b[1]|b[3]),
 'b1^b2(b3|b4)':lambda b:b[0]^(b[1]&(b[2]|b[3])),
 'Sel(b1,b2,b3b4)?':lambda b:b[1] if b[0]==0 else (b[2]&b[3]),
 'b1b2^b3b4^b1b3':lambda b:(b[0]&b[1])^(b[2]&b[3])^(b[0]&b[2]),
 'thr2of4?':lambda b:int(sum(b)>=3) ^ (sum(b)==2 and b[0]),
 'Sel(b1,b2,b3)^b2b4':lambda b:(b[1] if b[0]==0 else b[2])^(b[1]&b[3]),
 'b1^b2b3^b4(b2^b3)':lambda b:b[0]^(b[1]&b[2])^(b[3]&(b[1]^b[2])),
 'Sel(b1,b2^b3,b4)':lambda b:(b[1]^b[2]) if b[0]==0 else b[3],
 'Sel(b1,b2^b3,b2b4)?':lambda b:(b[1]^b[2]) if b[0]==0 else (b[1]&b[3]),
 'Sel(b1,b2^b3,Maj)':lambda b:(b[1]^b[2]) if b[0]==0 else int(b[1]+b[2]+b[3]>=2),
 'Sel(b1,b2^b3,b2^b3b4)':lambda b:(b[1]^b[2]) if b[0]==0 else (b[1]^(b[2]&b[3])),
}
rep_by_class=collections.defaultdict(list)
for name,fn in cands.items():
    S=frozenset(x for x in pts if fn([bit(x,i) for i in range(N)]))
    if len(S)!=8: print("  not balanced:",name); continue
    r=canon(S); rep_by_class[info[r]].append((name,list(r),orb[r]))
for k in sorted(rep_by_class): print(k, rep_by_class[k])
json.dump({str(list(r)):dict(size=orb[r],D=info[r][0],P=info[r][1]) for r in orb},open('classes_N4.json','w'))
