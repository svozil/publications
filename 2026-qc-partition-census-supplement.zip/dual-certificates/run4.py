import sys, json, pickle, itertools, collections, time
sys.path.insert(0,'.')
from sdp_dual2 import solve
N=4
pts=list(range(16)); full=frozenset(pts)
perms=list(itertools.permutations(range(N)))
def act(x,pi,c):
    y=0
    for i in range(N):
        if (x>>i)&1: y|=1<<pi[i]
    return y^c
def canon(S):
    best=None
    for pi in perms:
        for c in range(16):
            T=frozenset(act(x,pi,c) for x in S); U=full-T
            k=min(tuple(sorted(T)),tuple(sorted(U)))
            if best is None or k<best: best=k
    return best
orb=collections.Counter()
for S in itertools.combinations(pts,8):
    if 0 not in S: continue
    orb[canon(frozenset(S))]+=1
reps=sorted(orb)
print(len(reps),"orbits",sum(orb.values()),flush=True)
res={}
for r in reps:
    t0=time.time()
    f=[1 if x in r else 0 for x in pts]
    y,P,obj=solve(f,N,mu_final=2e-8)
    res[str(list(r))]=dict(size=orb[r],obj=float(obj),y=y.tolist())
    print(list(r),orb[r],f"{obj:.7f}",f"{time.time()-t0:.0f}s",flush=True)
    json.dump(res,open('dual_N4.json','w'))
print("DONE")
