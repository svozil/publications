"""Deutsch's problem with cyclic response X_d (d odd): one-query worst-case success.
(1) Probe of Proposition 5 (equal weight on the two eigenvalues adjacent to -1):
    worst-case success (3 + cos(pi/d))/4.
(2) For d = 3, random search over all probes (the Gram matrix depends only on the
    weights q[x, lambda] because all U_b^dagger U_b' are diagonal in the eigenbasis);
    for each probe the worst case is min over priors of the Helstrom value."""
import numpy as np
from scipy.optimize import minimize
rng=np.random.default_rng(5)
inst=[(0,0),(1,1),(0,1),(1,0)]; sgn=np.array([1,1,-1,-1])
def worst_success(q,d):
    lam=np.exp(2j*np.pi*np.arange(d)/d); q=np.array(q,float).reshape(2,d)
    V=np.array([np.concatenate([np.sqrt(q[x])*lam**b[x] for x in range(2)]) for b in inst])
    P=np.einsum('ai,aj->aij',V,V.conj())
    def h(z):
        w=np.exp(z); w/=w.sum()
        return 0.5*(1+np.abs(np.linalg.eigvalsh(np.tensordot(w*sgn,P,1))).sum())
    return min(minimize(h,rng.normal(size=4)*0.3,method='Nelder-Mead',
               options={'maxiter':2000,'fatol':1e-13,'xatol':1e-10}).fun for _ in range(8))
if __name__=='__main__':
    for d in [3,5,7,9]:
        k=(d-1)//2; q=np.zeros((2,d)); q[:,k]=0.25; q[:,k+1]=0.25
        print(d, round(worst_success(q.ravel(),d),6), round((3+np.cos(np.pi/d))/4,6))
    best=0
    for t in range(150):
        f=lambda z: -worst_success(np.exp(z)/np.exp(z).sum(),3)
        r=minimize(f,rng.normal(size=6),method='Nelder-Mead',options={'maxiter':300})
        best=max(best,-r.fun)
    print("d=3 best found over probes:",round(best,6))
