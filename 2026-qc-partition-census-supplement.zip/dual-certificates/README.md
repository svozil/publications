# Exact two-query lower bounds: rational dual certificates

This folder settles the 43 four-address orbits (6,040 balanced partitions)
that the July 2026 version of this archive labelled `numerical_candidate`.
Each has an exact rational certificate proving that no two-query quantum
algorithm computes the partition exactly; with the three-query trees in
`witnesses-m4/` this gives Q_E = 3.

## What a certificate states

`certificates_N4.json` holds one entry per orbit, keyed by the archive's
`partition_number` and `canonical_mask` (the same numbering as
`data/results-m4-orbits.csv`). The field `f` is the label list of that row
(index k = int(name, 2), label 0 on `cell_zero_names`). All matrix entries and
the weights `lam` are integers over the common denominator 2^prec (prec = 40).

With the phase point oracle |i> -> (-1)^{b_i}|i>, i = 0..4, b_0 = 0, and
D_0 = I, D_i = diag((-1)^{b_i}), a certificate is valid if

    Y1 - D_i Y2 D_i  > 0      (i = 0..4)
    Y2 - D_i Y3 D_i  > 0      (i = 0..4)
    Y3 - diag(lam_b [f(b) = j]) > 0   (j = 0, 1)
    lam >= 0,  sum(lam) = 1.

Weak duality for the two-query semidefinite program of Barnum, Saks, and
Szegedy then bounds the worst-case success of every two-query algorithm by
1^T Y1 1 (the field `two_query_success_upper_bound`, an exact fraction). A
value below 1 proves Q_E >= 3. The one-line proof of weak duality is given in
Sec. IV of the manuscript and in Sec. 9 of `supplementary_partition_census.pdf`.

## Checking

    python3 verify_cert.py certificates_N4.json

The verifier uses only the Python standard library (integers and
`fractions`); positive definiteness is checked by Gaussian elimination with
exact positive pivots. It takes a few seconds. Result: all 43 certificates
are valid, with bounds between 0.90005 and 0.98611.

## How the certificates were found

The scripts here document the search; the validity of a certificate does not
depend on them.

- `sdp_dual2.py`: barrier-method solver (numpy) for the dual program.
- `classes.py`, `run4.py`: orbit enumeration and dual solutions for all 58
  orbit representatives (the 15 orbits settled by trees give dual value 1, as
  they must).
- `make_cert.py`, `finalize.py`: add 3e, 2e, and e times the identity to
  Y1, Y2, Y3 (e = 2^-20), which raises every constraint matrix by e*I; round
  every entry to a multiple of 2^-40; and verify exactly.
- `convert_to_archive.py`: maps each certificate onto the archive's own
  representative by the coordinate permutation and complement that relates
  the two representatives, then re-verifies it exactly.
- `deutsch_odd_d.py`: the bounded-error computation for odd cyclic responses
  (manuscript Prop. 5).

The numerical optimal values, 0.9000-0.9861, agree with the two-query values
of Montanaro, Jozsa, and Mitchison, Algorithmica 71, 775 (2015), Appendix A.
