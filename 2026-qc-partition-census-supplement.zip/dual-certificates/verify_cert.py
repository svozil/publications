"""Standalone exact verifier (integers/fractions only, no floating point).
Checks, for a balanced f on N bits, a dual certificate of the two-query
Barnum-Saks-Szegedy SDP with phase oracle O_b|i> = (-1)^{b_i}|i>, i=0..N, b_0=0:
   S1_i = Y1 - D_i Y2 D_i  > 0,  S2_i = Y2 - D_i Y3 D_i > 0   (i=0..N)
   S3_j = Y3 - diag(lam_b [f(b)=j]) > 0   (j=0,1),  lam >= 0, sum lam = 1.
Then every two-query algorithm has worst-case success <= 1^T Y1 1."""
import json, sys
from fractions import Fraction
def is_pd(A):
    n=len(A); A=[[Fraction(x) for x in row] for row in A]
    for k in range(n):
        if A[k][k]<=0: return False
        for i in range(k+1,n):
            if A[i][k]!=0:
                r=A[i][k]/A[k][k]
                for j in range(k,n): A[i][j]-=r*A[k][j]
    return True
def check(c):
    N=c['N']; M=2**N; den=2**c['prec']; f=c['f']
    assert sorted(f).count(1)==M//2
    Y1,Y2,Y3,lam=c['Y1'],c['Y2'],c['Y3'],c['lam']
    for Y in (Y1,Y2,Y3):
        assert all(Y[p][q]==Y[q][p] for p in range(M) for q in range(M))
    assert all(l>=0 for l in lam) and sum(lam)==den
    D=[[1]*M]+[[(-1)**((b>>i)&1) for b in range(M)] for i in range(N)]
    for d in D:
        if not is_pd([[Y1[p][q]-d[p]*d[q]*Y2[p][q] for q in range(M)] for p in range(M)]): return None
        if not is_pd([[Y2[p][q]-d[p]*d[q]*Y3[p][q] for q in range(M)] for p in range(M)]): return None
    for j in (0,1):
        if not is_pd([[Y3[p][q]-(lam[p] if (p==q and f[p]==j) else 0) for q in range(M)] for p in range(M)]): return None
    return Fraction(sum(sum(row) for row in Y1),den)
if __name__=='__main__':
    certs=json.load(open(sys.argv[1]))
    ok=0
    for c in certs:
        bound=check(c)
        status = 'INVALID' if bound is None else ('Q_E>=3' if bound<1 else 'bound>=1')
        label = f"partition-{c['partition_number']:04d}" if 'partition_number' in c else str(c.get('rep'))
        print(label, status, None if bound is None else f"{float(bound):.6f}")
        ok += (bound is not None and bound<1)
    print(f"{ok} of {len(certs)} certificates prove Q_E >= 3")
