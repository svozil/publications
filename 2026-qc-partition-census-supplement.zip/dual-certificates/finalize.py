import json, sys, numpy as np
sys.path.insert(0,'.')
from make_cert import certify
from verify_cert import check
res=json.load(open('dual_N4.json')); cls=json.load(open('classes_N4.json'))
certs=[]; bounds=[]; nums=[]; others=[]
for k,v in res.items():
    rep=json.loads(k); c=cls[k]
    if c['P']==3:
        cert=certify(rep,np.array(v['y'])); b=check(cert)
        assert b is not None and b<1, (rep,b)
        cert['D']=c['D']; cert['orbit_size']=c['size']; cert['bound_float']=float(b)
        certs.append(cert); bounds.append(float(b)); nums.append(v['obj'])
    else:
        others.append((rep,c['D'],c['P'],v['obj']))
print("certified",len(certs),"orbits covering",sum(c['orbit_size'] for c in certs),"partitions")
print("certified bound max",max(bounds),"min",min(bounds))
print("numerical optimum range",min(nums),max(nums))
print("tree-settled orbits: min SDP value",min(o[3] for o in others),"count",len(others))
json.dump(certs,open('certificates_N4.json','w'))
