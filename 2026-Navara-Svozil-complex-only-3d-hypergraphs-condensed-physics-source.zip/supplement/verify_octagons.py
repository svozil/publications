#!/usr/bin/env python3
"""Exact certificates for the Navara--Svozil 20- and 21-ray octagons.

Python 3.10+; standard library only. Run: python verify_octagons.py
Writes all-pairs.csv and verification-results.json beside this script.

Arithmetic is rational polynomial reduction in explicitly specified radicals.
No floating-point arithmetic or numerical tolerance is used. Nonzero real
expressions are additionally certified by rational enclosing intervals, so
no unproved assumption of linear independence of the radical basis is needed.
The positive roots are selected by the interval enclosures. Realification
omits each positive factor 1/sqrt(1+t^2), which does not change rays.
"""
from collections import Counter
from fractions import Fraction as F
from functools import lru_cache
from itertools import combinations
from math import isqrt
from pathlib import Path
import csv
import json


def require(condition, message):
    if not condition:
        raise ArithmeticError(message)


def interval_add(a, b):
    return a[0] + b[0], a[1] + b[1]


def interval_mul(a, b):
    products = [x * y for x in a for y in b]
    return min(products), max(products)


def sqrt_enclosure(q, digits):
    require(q >= 0, "negative radicand")
    scale = 10 ** digits
    floor = isqrt(q.numerator * scale * scale // q.denominator)
    low = F(floor, scale)
    return low, low if low * low == q else F(floor + 1, scale)


class Algebra:
    """A tower z_k^2=d_k of quadratic relations; the last generator is i."""
    def __init__(self, radicands):
        self.radicands = tuple({m: F(c) for m, c in d.items()} for d in radicands)
        self.n = len(radicands)
        self.size = 1 << self.n
        self.imag_mask = 1 << (self.n - 1)
        self.products = {}
        for a in range(self.size):
            for b in range(self.size):
                exponents = tuple(((a >> k) & 1) + ((b >> k) & 1) for k in range(self.n))
                self.products[a, b] = self.reduce(exponents)

    @lru_cache(maxsize=None)
    def reduce(self, exponents):
        for k in reversed(range(self.n)):
            if exponents[k] >= 2:
                result = Counter()
                for mask, coefficient in self.radicands[k].items():
                    lower = list(exponents)
                    lower[k] -= 2
                    for j in range(self.n):
                        lower[j] += (mask >> j) & 1
                    for m, c in self.reduce(tuple(lower)):
                        result[m] += coefficient * c
                return tuple((m, c) for m, c in result.items() if c)
        mask = sum(e << k for k, e in enumerate(exponents))
        return ((mask, F(1)),)

    def element(self, coefficients):
        return Element(self, coefficients)

    def scalar(self, x):
        return self.element({0: F(x)})

    def generator(self, k):
        return self.element({1 << k: F(1)})

    @lru_cache(maxsize=None)
    def root_intervals(self, digits):
        roots = []
        for k in range(self.n - 1):
            low, high = self.element(self.radicands[k]).interval(roots)
            require(low > 0, "radical interval must be positive")
            roots.append((sqrt_enclosure(low, digits)[0], sqrt_enclosure(high, digits)[1]))
        return tuple(roots)


class Element:
    def __init__(self, algebra, coefficients):
        self.algebra = algebra
        self.c = {m: F(c) for m, c in coefficients.items() if c}

    def convert(self, x):
        if isinstance(x, Element):
            require(x.algebra is self.algebra, "mixed algebras")
            return x
        return self.algebra.scalar(x)

    def __add__(self, other):
        other = self.convert(other)
        result = dict(self.c)
        for m, c in other.c.items():
            result[m] = result.get(m, F(0)) + c
        return self.algebra.element(result)

    __radd__ = __add__

    def __neg__(self):
        return self.algebra.element({m: -c for m, c in self.c.items()})

    def __sub__(self, other):
        return self + -self.convert(other)

    def __rsub__(self, other):
        return self.convert(other) + -self

    def __mul__(self, other):
        other = self.convert(other)
        result = Counter()
        for a, x in self.c.items():
            for b, y in other.c.items():
                for m, c in self.algebra.products[a, b]:
                    result[m] += x * y * c
        return self.algebra.element(result)

    __rmul__ = __mul__

    def __truediv__(self, rational):
        return self * (F(1) / F(rational))

    def __eq__(self, other):
        return self.c == self.convert(other).c

    def conjugate(self):
        return self.algebra.element({m: -c if m & self.algebra.imag_mask else c for m, c in self.c.items()})

    def real_imag(self):
        mask = self.algebra.imag_mask
        return (self.algebra.element({m: c for m, c in self.c.items() if not m & mask}),
                self.algebra.element({m ^ mask: c for m, c in self.c.items() if m & mask}))

    def interval(self, roots):
        require(not any(m & self.algebra.imag_mask for m in self.c), "interval of complex expression")
        result = (F(0), F(0))
        for mask, coefficient in self.c.items():
            term = (coefficient, coefficient)
            for k in range(len(roots)):
                if mask & (1 << k):
                    term = interval_mul(term, roots[k])
            require(mask < (1 << len(roots)), "root not yet enclosed")
            result = interval_add(result, term)
        return result

    def certified_sign(self):
        if not self.c:
            return 0
        for digits in (12, 24, 48, 96):
            low, high = self.interval(self.algebra.root_intervals(digits))
            if low > 0:
                return 1
            if high < 0:
                return -1
        raise ArithmeticError("could not separate a nonzero expression from zero")


def inner(u, v):
    return sum(x.conjugate() * y for x, y in zip(u, v))


def cross(u, v):
    return tuple((u[(k + 1) % 3] * v[(k + 2) % 3] - u[(k + 2) % 3] * v[(k + 1) % 3]).conjugate() for k in range(3))


def contexts(augmented):
    result = {f"E{j}": (f"v{(j-1)%8}{j}", f"v{j}", f"v{j}{(j+1)%8}") for j in range(8)}
    result.update(D0=("v0", "a1", "v4"), D1=("v1", "b2", "v5"),
                  D2=("v2", "a2", "v6"), D3=("v3", "b1", "v7"))
    if augmented:
        result.update(Fa=("a1", "c", "a2"), Fb=("b1", "c", "b2"))
    return result


def h20():
    A = Algebra([{0: 69}, {0: F(49, 26), 1: F(-5, 26)},
                 {0: F(75, 26), 1: F(-5, 26)}, {0: -1}])
    root69, s, r, i = [A.generator(k) for k in range(4)]
    C = (49 - 5 * root69) / 26
    N = 1 + C
    eta = (5 + 12 * i) / 13
    zeta = (14 + 6 * root69 + i * (4 * root69 - 21)) / 65
    require(s * s == C and r * r == N, "H20 square roots")
    require(13*C*C - 49*C + 13 == 0, "H20 C polynomial")
    require(eta*eta.conjugate() == 1 and zeta*zeta.conjugate() == 1, "H20 phases")
    mu = (-1, eta, 1, -eta, -1, eta, 1, -eta)
    tau = (1, zeta, -i, -i*zeta, -1, -zeta, i, i*zeta)
    raw = {f"v{j}": (1, s*mu[j], r*tau[j]) for j in range(8)}
    raw.update(a1=(s, 1, 0), a2=(s, -1, 0), b1=(s, eta, 0), b2=(s, -eta, 0))
    rays = {name: tuple(x if isinstance(x, Element) else A.scalar(x) for x in v) for name, v in raw.items()}
    rays.update({f"v{j}{(j+1)%8}": cross(rays[f"v{j}"], rays[f"v{(j+1)%8}"]) for j in range(8)})
    phase = dict(v34=1, v45=1, v56=1, v67=2, v70=2)
    return rays, contexts(False), phase


def h21():
    A = Algebra([{0: 2}, {0: 7}, {0: -1}])
    root2, root7, i = [A.generator(k) for k in range(3)]
    p, q = (root2*root7 + root2)/4, (root2*root7 - root2)/4
    require(p*p + q*q == 2 and p*q == F(3,4) and p-q == root2/2, "H21 identities")
    raw = dict(c=(0,0,1), a1=(1,1,0), a2=(1,-1,0), b1=(1,i,0), b2=(1,-i,0),
               v0=(1,-1,root2), v1=(1,i,p+i*q), v2=(1,1,-i*root2), v3=(1,-i,q-i*p),
               v4=(1,-1,-root2), v5=(1,i,-p-i*q), v6=(1,1,i*root2), v7=(1,-i,-q+i*p),
               v01=(-p+i*(q+root2), root2-p+i*q, 1-i),
               v12=(root2-p+i*q, p-i*(q+root2), 1+i),
               v23=(q+root2+i*p, -q+i*(root2-p), -1+i),
               v34=(q+i*(p-root2), q+root2+i*p, -1-i),
               v45=(p-i*(q+root2), -root2+p-i*q, 1-i),
               v56=(-root2+p-i*q, -p+i*(q+root2), 1+i),
               v67=(-q-root2-i*p, q-i*(root2-p), -1+i),
               v70=(-q-i*(p-root2), -q-root2-i*p, -1-i))
    rays = {name: tuple(x if isinstance(x, Element) else A.scalar(x) for x in v) for name, v in raw.items()}
    for j in range(8):
        require(rays[f"v{j}{(j+1)%8}"] == cross(rays[f"v{j}"], rays[f"v{(j+1)%8}"]), "H21 explicit corner")
    phase = {name: 2 for name in ("v2", "v3", "v6", "v7", "v34", "v56", "v70")}
    phase.update(v45=1, v67=3)
    return rays, contexts(True), phase


EXPECTED = {
    "H20": {str(F(n,d)): count for n,d,count in (
        (1,25,2), (3,50,4), (7,75,8), (8,75,8), (7,50,8), (4,25,8), (1,5,16), (6,25,8),
        (3,10,8), (23,75,2), (26,75,8), (28,75,8), (32,75,4), (49,150,8),
        (7,15,8), (13,25,2), (8,15,8), (14,25,8), (16,25,2), (7,10,8), (59,75,2), (4,5,16))},
    "H21": {"1/4":84, "1/2":84},
}

# Mapping every color class to one Cartesian basis ray gives a real but
# nonfaithful realization. Each listed context has all three colors.
COLOR_CLASSES = (("v2", "v5", "v01", "v34", "v67", "a1", "b1"),
                 ("v0", "v1", "v6", "v7", "v23", "v45", "c"),
                 ("v3", "v4", "v12", "v56", "v70", "a2", "b2"))


def verify(name, rays, edges, phase):
    labels = sorted(rays)
    required = {frozenset(pair) for edge in edges.values() for pair in combinations(edge, 2)}
    norms = {v: inner(rays[v], rays[v]) for v in labels}
    for v in labels:
        require(norms[v].certified_sign() == 1, f"{name} nonzero vector {v}")
    real_rays = {}
    for v, coordinates in rays.items():
        parts = [z.real_imag() for z in coordinates]
        t = phase.get(v, 0)
        real_rays[v] = tuple(x-t*y for x,y in parts) + tuple(y+t*x for x,y in parts)
    real_norms = {v: inner(real_rays[v], real_rays[v]) for v in labels}
    histogram, rows = Counter(), []
    for u,v in combinations(labels, 2):
        product = inner(rays[u], rays[v])
        numerator = product * product.conjugate()
        denominator = norms[u] * norms[v]
        first = next(iter(denominator.c))
        Q = numerator.c.get(first, F(0)) / denominator.c[first]
        require(numerator == Q*denominator, f"{name} overlap not rational: {u},{v}")
        prescribed = frozenset((u,v)) in required
        require((Q == 0) == prescribed, f"{name} complex incidence: {u},{v}")
        require(0 <= Q < 1, f"{name} complex ray coincidence: {u},{v}")
        if Q:
            histogram[str(Q)] += 1
        rd = inner(real_rays[u], real_rays[v])
        sign = rd.certified_sign()
        require((sign == 0) == prescribed, f"{name} real incidence: {u},{v}")
        determinant = real_norms[u]*real_norms[v] - rd*rd
        require(determinant.certified_sign() == 1, f"{name} real ray coincidence: {u},{v}")
        rows.append(dict(graph=name, vertex_u=u, vertex_v=v, prescribed_orthogonality=int(prescribed),
                         complex_Q=str(Q), real_dot_sign=sign, real_rays_distinct=1))
    require(dict(histogram) == EXPECTED[name], f"{name} histogram mismatch: {dict(histogram)}")
    for j in range(8):
        x,y,z = (rays[f"v{k%8}"] for k in (j-1,j,j+1))
        require(inner(x,y)*inner(y,z) == inner(x,z)*inner(y,y), f"{name} closure {j}")
    # All four inner representatives have equal norm, so the denominators
    # cancel when checking the normalized projector-sum identity.
    require(all(norms[x] == norms['a1'] for x in ('a2','b1','b2')), "inner norms")
    for j in range(3):
        for k in range(3):
            total = sum(sign*rays[v][j]*rays[v][k].conjugate() for v,sign in [('a1',1),('a2',1),('b1',-1),('b2',-1)])
            require(total == 0, f"{name} projector-sum identity")
    colors = {v:k for k,group in enumerate(COLOR_CLASSES) for v in group if v in rays}
    require(set(colors) == set(rays), "coloring covers all vertices")
    require(all({colors[v] for v in edge} == {0,1,2} for edge in edges.values()), "three-coloring")
    return {"vertices":len(labels), "contexts":len(edges), "pairs":len(rows),
            "orthogonal_pairs":len(required), "nonorthogonal_pairs":len(rows)-len(required),
            "Q_histogram":dict(sorted(histogram.items(), key=lambda item:F(item[0]))),
            "realification_all_pairs_verified":True, "closure_equations_verified":8,
            "projector_sum_identity_verified":True,
            "nonfaithful_real_3d_coloring":colors}, rows


def main():
    results, rows = {}, []
    for name, factory in (("H20",h20), ("H21",h21)):
        results[name], new_rows = verify(name, *factory())
        rows.extend(new_rows)
        print(f"{name}: {results[name]['pairs']} exact complex/real pair checks passed.", flush=True)
    root = Path(__file__).resolve().parent
    with (root / "all-pairs.csv").open("w", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    (root / "verification-results.json").write_text(json.dumps(results, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(results, indent=2))


if __name__ == "__main__":
    main()
