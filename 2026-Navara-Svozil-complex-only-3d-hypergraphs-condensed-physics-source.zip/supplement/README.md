# Exact octagon certificates

Run `python verify_octagons.py` with Python 3.10 or later. No external packages
are needed. The script writes `all-pairs.csv` and `verification-results.json`
beside itself; the supplied copies contain the output of the checked run.

The script independently constructs the displayed H20 and H21 vectors and the
context lists. For each of the 190 and 210 unordered pairs, respectively, it
computes the complex squared normalized overlap and checks exact agreement
with the required orthogonality graph. It then compares the complete overlap
histograms with Appendix A. H21's eight expanded corner formulas are also
checked against their defining Hermitian cross products.

The same run checks all pairs of the phase-adjusted real rays in six dimensions,
including distinctness. It verifies the eight Gram closure equations for each
octagon and both inner projector-sum identities. A three-coloring included in
the JSON file gives explicit nonfaithful real three-dimensional models:
replace each color by one Cartesian basis ray.

## Arithmetic

All coefficients are Python `fractions.Fraction` values. For H20 the generators
are sqrt(69), sqrt(C), sqrt(1+C), and i, with C=(49-5 sqrt(69))/26. For H21 they
are sqrt(2), sqrt(7), and i. Products are reduced using the stated quadratic
relations. Complex conjugation changes the sign of i only.

Squared normalized overlaps are calculated by exact cross multiplication; no
floating-point arithmetic is used. To certify nonzero real dot products and
strictly positive two-vector Gram determinants, the script evaluates rational
interval enclosures of the radical expressions. Bounds for square roots are
obtained with integer square roots and increased in precision if necessary.
Failure to exclude zero causes an error rather than being treated as a pass.
Thus these nonzero conclusions do not rely on assuming that the formal radical
monomials are a linearly independent basis.

The real rays use (x-t*y, y+t*x) for psi=x+i*y. The omitted positive factor
1/sqrt(1+t*t) changes neither their directions nor the checked incidences.

## Expected results

- H20: 20 rays, 12 contexts, 190 pairs; 36 zero and 154 nonzero overlaps.
- H21: 21 rays, 14 contexts, 210 pairs; 42 zero overlaps, 84 overlaps of 1/4,
  and 84 overlaps of 1/2.
- Both realifications reproduce exactly the same zero/nonzero pattern and
  have no coincident rays.
- The script verifies the displayed constructions; the real-dimension-three
  nonexistence arguments remain the analytic proofs in the manuscript.

The CSV `real_dot_sign` column records the certified sign of each unnormalized
real dot product. It is not a claim that nonzero transition probabilities are
preserved by the rank-one realification.
